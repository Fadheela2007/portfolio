import React, { useState } from "react";
import NetworkMark from "./NetworkMark";
import "./Login.css";
import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

/* ══════════════════════════════════════════════════════════════════════
   DEUX VUES, ET RIEN D'AUTRE

   « connexion »   — on a déjà un compte.
   « inscription » — on n'en a pas. On remplit, on valide, on est dedans.

   PAS DE DEMANDE, PAS DE VALIDATION, PAS D'ATTENTE. L'inscription crée
   l'organisation, son premier site et son administrateur, puis ouvre la
   session dans la foulée.

   ── POURQUOI C'EST SÛR SUR UNE PLATEFORME QUI SERT UN INVENTAIRE RÉSEAU ──

   Parce que l'inscrit n'entre nulle part : il CRÉE son espace. Son
   organisation est neuve et vide — aucune machine, aucune alerte, aucun
   parc. Il déclare son réseau, lance son scan, et supervise ce qui lui
   appartient. La frontière d'organisation (middleware/porteeSite.js) fait
   le reste : aucune requête ne la franchit, quel que soit le rôle.

   ── IL N'Y A PLUS D'ÉCRAN D'AMORÇAGE ──

   Il servait à créer le tout premier administrateur d'une base vide.
   L'inscription couvre ce cas comme les autres : sur une installation
   neuve, la première personne qui s'inscrit crée son organisation. Deux
   chemins pour la même chose auraient surtout créé de la confusion.
   ══════════════════════════════════════════════════════════════════════ */

export default function Login({ onLogin }) {
  const [vue, setVue] = useState("connexion");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  /* Propres à l'inscription. */
  const [nom, setNom] = useState("");
  const [organisation, setOrganisation] = useState("");
  const [ville, setVille] = useState("");

  function changerDeVue(cible) {
    setVue(cible);
    setError(null);
  }

  async function connexion(e) {
    e.preventDefault();
    if (!email || !password) {
      setError("Renseignez votre e-mail et votre mot de passe.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const { data } = await axios.post(`${API_URL}/auth/login`, {
        email,
        mot_de_passe: password,
      });
      // La persistance de la session est gérée par App.handleLogin,
      // pour qu'un seul endroit écrive dans localStorage.
      onLogin(data.utilisateur, data.token);
    } catch (err) {
      setError(err.response?.data?.error || "Identifiants invalides");
    } finally {
      setLoading(false);
    }
  }

  async function inscription(e) {
    e.preventDefault();
    if (!nom || !organisation || !ville || !email || !password) {
      setError("Tous les champs sont nécessaires pour créer votre espace.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const { data } = await axios.post(`${API_URL}/auth/inscription`, {
        nom,
        organisation,
        ville,
        email,
        mot_de_passe: password,
      });
      // Entrée immédiate : on vient de saisir son mot de passe, le
      // redemander n'apporterait rien.
      onLogin(data.utilisateur, data.token);
    } catch (err) {
      setError(
        err.response?.data?.aide ||
          err.response?.data?.error ||
          "Inscription impossible pour le moment"
      );
      setLoading(false);
    }
  }

  const entete =
    vue === "connexion"
      ? { titre: "NetSecureManager", sous: "Supervision réseau multi-sites" }
      : {
          titre: "Créer votre espace",
          sous: "Quelques secondes, et vous supervisez votre réseau.",
        };

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-mark">
          <NetworkMark size={24} />
        </div>

        <h1 className="login-title">{entete.titre}</h1>
        <p className="login-subtitle">{entete.sous}</p>

        {/* ══ SE CONNECTER ══ */}
        {vue === "connexion" && (
          <form onSubmit={connexion} className="login-form">
            <label className="login-field">
              E-mail
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="prenom.nom@entreprise.com"
                autoComplete="username"
              />
            </label>

            <label className="login-field">
              <span className="login-field-ligne">
                Mot de passe
                {/* Pas un lien vers une réinitialisation qui n'existe pas :
                    aucune réinitialisation en libre-service n'est câblée. Le
                    vrai chemin est humain — un administrateur change le mot
                    de passe depuis la page Utilisateurs — donc c'est ce qui
                    est dit, en texte et non en lien cliquable. */}
                <span className="login-aide-inline">contactez votre administrateur</span>
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••"
                autoComplete="current-password"
              />
            </label>

            {error && <p className="login-error">{error}</p>}

            <button type="submit" className="login-submit" disabled={loading}>
              {loading ? "Connexion..." : "Se connecter"}
            </button>

            <p className="login-footnote">
              Pas encore de compte ?{" "}
              <button
                type="button"
                className="login-lien"
                onClick={() => changerDeVue("inscription")}
              >
                Créer votre espace
              </button>
            </p>
          </form>
        )}

        {/* ══ CRÉER UN COMPTE ══ */}
        {vue === "inscription" && (
          <form onSubmit={inscription} className="login-form">
            <label className="login-field">
              Votre nom
              <input
                type="text"
                value={nom}
                onChange={(e) => setNom(e.target.value)}
                placeholder="Prénom Nom"
                autoComplete="name"
              />
            </label>

            <label className="login-field">
              Votre entreprise
              <input
                type="text"
                value={organisation}
                onChange={(e) => setOrganisation(e.target.value)}
                placeholder="Cabinet Ngando"
                autoComplete="organization"
              />
            </label>

            <label className="login-field">
              <span className="login-field-ligne">
                Ville
                {/* Elle sert à créer le premier site tout de suite. Sans
                    site, tous les écrans afficheraient « aucun site
                    accessible » et la plateforme paraîtrait cassée dès la
                    première seconde. */}
                <span className="login-aide-inline">votre premier site</span>
              </span>
              <input
                type="text"
                value={ville}
                onChange={(e) => setVille(e.target.value)}
                placeholder="Douala"
                autoComplete="address-level2"
              />
            </label>

            <label className="login-field">
              E-mail
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="prenom.nom@entreprise.com"
                autoComplete="username"
              />
            </label>

            <label className="login-field">
              Mot de passe
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="au moins 8 caractères"
                autoComplete="new-password"
              />
            </label>

            {error && <p className="login-error">{error}</p>}

            <button type="submit" className="login-submit" disabled={loading}>
              {loading ? "Création..." : "Créer mon espace"}
            </button>

            {/* CE QUI VA SE PASSER, DIT AVANT DE CLIQUER. Personne ne doit
                se demander dans quoi il vient d'entrer. */}
            <p className="login-footnote">
              Votre espace est vide et n'appartient qu'à vous : vous déclarez
              votre réseau, vous lancez votre scan.{" "}
              <button
                type="button"
                className="login-lien"
                onClick={() => changerDeVue("connexion")}
              >
                J'ai déjà un compte
              </button>
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
