/**
 * tools/couverture-bande-passante.js
 * Combien d'appareils PEUVENT être mesurés, et par quelle source.
 *
 *   node tools\couverture-bande-passante.js
 *
 * ═══════════════════════════════════════════════════════════════════════
 * POURQUOI CET OUTIL EXISTE, ET POURQUOI IL PASSE AVANT LE CODE
 *
 * La page Bande passante n'affiche aujourd'hui que les appareils qui
 * répondent eux-mêmes en SNMP — en pratique des imprimantes. La suite
 * évidente serait de mesurer les autres par le PORT DU COMMUTATEUR sur
 * lequel ils sont branchés : le compteur du port EST la consommation de
 * la machine, même si la machine ne dit rien d'elle-même.
 *
 * Cette voie est déjà écrite dans la plateforme (voir l'attribution
 * MAC → port dans routes/scan.js, et le repli du classement). Reste une
 * question à laquelle seul le parc peut répondre : SUR COMBIEN
 * D'APPAREILS s'appliquerait-elle réellement ?
 *
 * Y répondre avant de coder évite de bâtir un écran sur une hypothèse.
 * Cet outil ne modifie RIEN : il compte, et il dit ce qui manque.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * LES QUATRE CATÉGORIES, ET CE QUI LES SÉPARE
 *
 *   1. MESURÉ EN DIRECT — l'appareil expose ses propres compteurs SNMP.
 *      La mesure la plus fiable : c'est sa carte réseau qui compte.
 *
 *   2. MESURABLE PAR LE PORT — l'appareil est seul sur un port d'un
 *      commutateur administrable (nb_mac_vues = 1). Le compteur du port
 *      lui appartient donc entièrement.
 *
 *   3. PORT PARTAGÉ — plusieurs adresses MAC vues sur le même port : il
 *      y a un commutateur non administrable, un répéteur ou une borne
 *      WiFi entre les deux. Le compteur du port existe, mais il mélange
 *      plusieurs machines : l'attribuer à l'une d'elles serait faux.
 *
 *   4. AUCUNE SOURCE — ni SNMP, ni port connu. WiFi, ou branché derrière
 *      du matériel qui ne déclare rien. Ces appareils ne doivent jamais
 *      apparaître avec un zéro : un zéro se lit « aucun trafic », alors
 *      que la vérité est « aucune mesure ».
 *
 * La catégorie 3 et la catégorie 4 ne se distinguent pas toujours : un
 * téléphone en WiFi et un PC derrière un switch de bureau se ressemblent
 * vus d'ici. L'outil ne tranche donc pas entre « WiFi » et « filaire non
 * supervisé » — il dit ce qu'il sait, et s'arrête là.
 */
require("dotenv").config({
  path: require("path").join(__dirname, "..", ".env"),
  quiet: true,
});
const db = require("../src/db");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

/** Colonne ou table absente : migration non passée, ce n'est pas une panne. */
function absente(err) {
  return /Unknown column|doesn't exist|ER_BAD_FIELD_ERROR|ER_NO_SUCH_TABLE/i.test(
    err.message
  );
}

async function compter(sql, params = []) {
  try {
    const [[ligne]] = await db.query(sql, params);
    return Number(ligne.n);
  } catch (err) {
    if (absente(err)) return null; // null = « on n'a pas pu regarder »
    throw err;
  }
}

function ligne(libelle, valeur, total, couleur) {
  if (valeur === null) {
    console.log(`  ${G}${libelle.padEnd(46)} non disponible (migration absente)${F}`);
    return;
  }
  const part = total > 0 ? Math.round((valeur / total) * 100) : 0;
  const barre = "█".repeat(Math.round(part / 4)).padEnd(25, "·");
  console.log(
    `  ${couleur}${libelle.padEnd(46)}${String(valeur).padStart(4)}  ${barre} ${String(
      part
    ).padStart(3)} %${F}`
  );
}

(async () => {
  console.log("\n═══════════════════════════════════════════════════════════════");
  console.log("  BANDE PASSANTE — QUI PEUT ÊTRE MESURÉ, ET PAR QUELLE SOURCE");
  console.log("═══════════════════════════════════════════════════════════════\n");

  const total = await compter("SELECT COUNT(*) AS n FROM EQUIPEMENT");
  if (!total) {
    console.log("  Aucun équipement en base. Lancez un scan d'abord.\n");
    await db.end();
    return;
  }

  /* ── 1. Mesuré en direct ──
     Un relevé de trafic dans les 24 h prouve que la chaîne complète a
     fonctionné pour cet appareil : compteur lu, différence calculée,
     ligne écrite. C'est un critère d'OBSERVATION, pas de capacité. */
  const direct = await compter(
    `SELECT COUNT(DISTINCT r.id_equipement) AS n
       FROM RELEVE r
      WHERE r.trafic_entrant_kbps IS NOT NULL
        AND r.date_releve >= NOW() - INTERVAL 24 HOUR`
  );

  /* Les appareils qui exposent SNMP, qu'ils aient été mesurés ou non :
     l'écart avec le précédent dit si la chaîne s'interrompt quelque
     part, plutôt que si le parc est muet. */
  const exposeSnmp = await compter(
    "SELECT COUNT(*) AS n FROM EQUIPEMENT WHERE sys_descr IS NOT NULL"
  );

  /* ── 2 et 3. Rattachement à un port de commutateur ── */
  const seulSurPort = await compter(
    `SELECT COUNT(DISTINCT i.id_equipement_connecte) AS n
       FROM INTERFACE_RESEAU i
      WHERE i.id_equipement_connecte IS NOT NULL AND i.nb_mac_vues = 1`
  );
  const portPartage = await compter(
    `SELECT COUNT(DISTINCT i.id_equipement_connecte) AS n
       FROM INTERFACE_RESEAU i
      WHERE i.id_equipement_connecte IS NOT NULL AND i.nb_mac_vues > 1`
  );
  const portAvecCompteur = await compter(
    `SELECT COUNT(*) AS n
       FROM INTERFACE_RESEAU i
      WHERE i.id_equipement_connecte IS NOT NULL
        AND i.nb_mac_vues = 1
        AND i.trafic_entrant_kbps IS NOT NULL`
  );

  /* ── Le prérequis de tout le reste : des commutateurs administrables ── */
  const switchesInventories = await compter(
    "SELECT COUNT(DISTINCT id_equipement) AS n FROM INTERFACE_RESEAU"
  );
  const switchesAvecTable = await compter(
    `SELECT COUNT(DISTINCT i.id_equipement) AS n
       FROM INTERFACE_RESEAU i
      WHERE i.id_equipement_connecte IS NOT NULL`
  );

  /* ── 4. Le reste ── */
  const mesurables =
    (direct || 0) + (seulSurPort || 0);
  const sansSource = Math.max(0, total - mesurables - (portPartage || 0));

  console.log(`  Parc : ${total} équipement(s)\n`);
  ligne("1. mesuré en direct (SNMP sur l'appareil)", direct, total, V);
  ligne("2. seul sur un port de commutateur supervisé", seulSurPort, total, V);
  ligne("3. port partagé (switch non admin., borne WiFi)", portPartage, total, J);
  ligne("4. aucune source de mesure connue", sansSource, total, R);

  console.log("\n───────────────────────────────────────────────────────────────");
  console.log("  LE PRÉREQUIS DE LA MESURE PAR PORT");
  console.log("───────────────────────────────────────────────────────────────\n");
  /* Le libellé compte autant que le chiffre. « Commutateurs dont les
     interfaces sont inventoriées » était FAUX : cette requête compte les
     équipements SNMP ayant des interfaces, et une imprimante en a. Lu de
     travers, il laissait croire à onze commutateurs sur un parc qui n'en
     déclare aucun — exactement le genre de chiffre juste sous une
     étiquette fausse qu'on passe la journée à traquer ailleurs. */
  console.log(
    `  Équipements SNMP ayant des interfaces (imprimantes comprises) : ${
      switchesInventories === null ? "—" : switchesInventories
    }`
  );
  console.log(
    `  Équipements ayant livré une table d'adresses MAC (= switch)   : ${
      switchesAvecTable === null ? "—" : switchesAvecTable
    }`
  );
  console.log(
    `  Ports attribués portant déjà un compteur de débit              : ${
      portAvecCompteur === null ? "—" : portAvecCompteur
    }`
  );
  console.log(
    `  ${G}Équipements exposant SNMP (mesurés ou non)                      : ${
      exposeSnmp === null ? "—" : exposeSnmp
    }${F}`
  );

  /* QUI SONT CES ÉQUIPEMENTS SNMP ? C'est la question qui suit
     immédiatement, et l'outil ne doit pas obliger à lancer un second
     diagnostic pour y répondre : un commutateur parmi eux change toute
     la conclusion, une liste d'imprimantes la confirme. */
  try {
    const [snmp] = await db.query(
      `SELECT e.adresse_ip,
              COALESCE(e.nom_personnalise, e.nom, '—') AS nom,
              COALESCE(t.libelle, 'non classé') AS type,
              LEFT(COALESCE(e.sys_descr, ''), 58) AS descr,
              (SELECT COUNT(*) FROM INTERFACE_RESEAU i
                WHERE i.id_equipement = e.id_equipement) AS interfaces
         FROM EQUIPEMENT e
         LEFT JOIN TYPE_EQUIPEMENT t ON t.id_type = e.id_type
        WHERE e.sys_descr IS NOT NULL
        ORDER BY interfaces DESC, e.adresse_ip
        LIMIT 30`
    );
    if (snmp.length > 0) {
      console.log("\n  Les équipements qui répondent en SNMP :\n");
      console.log(
        `  ${G}adresse          type            ports  description${F}`
      );
      for (const s of snmp) {
        console.log(
          `  ${String(s.adresse_ip).padEnd(16)} ${String(s.type).padEnd(15)} ` +
            `${String(s.interfaces).padStart(4)}   ${G}${s.descr}${F}`
        );
      }
    }
  } catch (err) {
    if (!absente(err)) throw err;
  }

  /* ── Qui sont les non mesurables ? Par type, pour donner une idée de
        ce qu'on gagnerait à ouvrir telle ou telle voie. ── */
  try {
    const [parType] = await db.query(
      `SELECT COALESCE(t.libelle, 'non classé') AS type, COUNT(*) AS n
         FROM EQUIPEMENT e
         LEFT JOIN TYPE_EQUIPEMENT t ON t.id_type = e.id_type
        WHERE e.id_equipement NOT IN (
                SELECT DISTINCT r.id_equipement FROM RELEVE r
                 WHERE r.trafic_entrant_kbps IS NOT NULL
                   AND r.date_releve >= NOW() - INTERVAL 24 HOUR)
        GROUP BY COALESCE(t.libelle, 'non classé')
        ORDER BY n DESC
        LIMIT 12`
    );
    if (parType.length > 0) {
      console.log("\n───────────────────────────────────────────────────────────────");
      console.log("  CE QUI N'EST PAS MESURÉ AUJOURD'HUI, PAR TYPE");
      console.log("───────────────────────────────────────────────────────────────\n");
      for (const r of parType) {
        console.log(`  ${String(r.n).padStart(4)}  ${r.type}`);
      }
    }
  } catch (err) {
    if (!absente(err)) throw err;
  }

  /* ── La conclusion, écrite pour être recopiée telle quelle ── */
  console.log("\n───────────────────────────────────────────────────────────────");
  console.log("  CE QU'ON PEUT ATTEINDRE");
  console.log("───────────────────────────────────────────────────────────────\n");

  if (switchesAvecTable === 0 || switchesAvecTable === null) {
    console.log(
      `  ${R}Aucun commutateur n'a livré sa table d'adresses MAC.${F}\n` +
        "  La mesure par port ne peut donc s'appliquer à AUCUN appareil sur\n" +
        "  ce parc : elle suppose un commutateur administrable interrogeable\n" +
        "  en SNMP. Coder cette voie plus avant n'ajouterait rien à l'écran\n" +
        "  tant qu'un tel commutateur n'est pas présent.\n"
    );
    console.log(
      `  ${J}Ce qui reste utile et réalisable tout de suite :${F} distinguer à\n` +
        "  l'écran les appareils mesurés de ceux qui ne PEUVENT pas l'être,\n" +
        "  avec la raison — au lieu de les omettre en silence.\n"
    );
  } else {
    const gain = seulSurPort || 0;
    console.log(
      `  ${V}${gain} appareil(s) deviendraient mesurables par le port de leur\n` +
        `  commutateur${F}, en plus des ${direct} déjà mesurés en direct —\n` +
        `  soit ${Math.round(((gain + direct) / total) * 100)} % du parc.\n`
    );
    if (portAvecCompteur === 0) {
      console.log(
        `  ${J}Attention : aucun port attribué ne porte encore de compteur.${F}\n` +
          "  Le débit se calcule entre deux relevés : laissez le cycle de\n" +
          "  supervision tourner au moins deux fois avant de conclure.\n"
      );
    }
  }

  console.log(
    `  ${G}Les appareils en WiFi ne sont pas distinguables d'ici : une borne ne\n` +
      `  déclare le trafic par client que sur du matériel d'entreprise, et il\n` +
      `  faudrait l'interroger elle-même pour le savoir.${F}`
  );

  console.log("───────────────────────────────────────────────────────────────\n");

  await db.end();
  process.exit(0);
})().catch((err) => {
  console.error("\nDiagnostic interrompu :", err.message, "\n");
  process.exit(1);
});
