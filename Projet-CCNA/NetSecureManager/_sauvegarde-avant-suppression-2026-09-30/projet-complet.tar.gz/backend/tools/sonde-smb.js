/**
 * tools/sonde-smb.js
 * La cinquième source de noms répond-elle sur ce parc ?
 *
 *   node tools\sonde-smb.js                    (12 machines sans nom, au hasard)
 *   node tools\sonde-smb.js 192.168.1.18 192.168.0.50
 *
 * ─────────────────────────────────────────────────────────────────────
 * POURQUOI CET OUTIL PLUTÔT QU'UN SCAN COMPLET
 *
 * La sonde SMB ne remplit la base QUE pendant un balayage. Pour savoir
 * si elle fonctionne, il faudrait donc lancer un scan entier — long, et
 * volontairement lent sur ce réseau puisque la concurrence est tenue à 3
 * pour rester discrète.
 *
 * Cet outil pose la question directement, sur quelques adresses, en
 * quelques secondes. Il n'écrit RIEN en base : il interroge et il
 * affiche. Si le nom sort ici, il sortira au prochain scan.
 *
 * Il teste aussi le port : une machine dont le 445 est fermé ne peut
 * pas répondre, et il faut le distinguer d'une machine qui refuse de
 * donner son nom — les deux se soignent différemment.
 * ─────────────────────────────────────────────────────────────────────
 */
require("dotenv").config({
  path: require("path").join(__dirname, "..", ".env"),
  quiet: true,
});
const net = require("net");
const db = require("../src/db");
const { nomSmb, nomNetbios } = require("../src/services/nomService");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

/** Le port 445 est-il ouvert ? Sans lui, rien n'est possible. */
function port445(ip) {
  return new Promise((resoudre) => {
    const socket = new net.Socket();
    let fini = false;
    const finir = (v) => {
      if (fini) return;
      fini = true;
      socket.destroy();
      resoudre(v);
    };
    socket.setTimeout(1200);
    socket.once("connect", () => finir(true));
    socket.once("timeout", () => finir(false));
    socket.once("error", () => finir(false));
    socket.connect(445, ip);
  });
}

/* ═══════════════════════════════════════════════════════════════════════
   MODE DÉTAILLÉ — QUAND LE PORT RÉPOND MAIS QUE LE NOM NE SORT PAS

   « Refusé » ne dit pas POURQUOI, et il y a quatre raisons possibles :
   aucun dialecte commun, la négociation rejetée, la session refusée
   d'emblée, ou une réponse sans jeton NTLM. Elles ne se corrigent pas
   de la même façon, et deviner laquelle coûte plus cher que la lire.

   Ce mode rejoue le même échange en affichant ce que la machine répond
   à chaque étape : le dialecte retenu, le code d'état de chaque réponse,
   la présence du jeton. Une seule adresse à la fois.

       node tools\sonde-smb.js 192.168.1.197 --details
   ═══════════════════════════════════════════════════════════════════════ */

const ETATS = {
  0x00000000: "SUCCÈS",
  0xc0000016: "MORE_PROCESSING_REQUIRED (attendu à cette étape)",
  0xc000000d: "INVALID_PARAMETER",
  0xc00000bb: "NOT_SUPPORTED — aucun dialecte commun",
  0xc0000022: "ACCESS_DENIED",
  0xc000006d: "LOGON_FAILURE",
  0xc0000203: "USER_SESSION_DELETED",
};

function nomEtat(code) {
  return ETATS[code >>> 0] || `0x${(code >>> 0).toString(16).padStart(8, "0")}`;
}

function detailler(ip) {
  const { requeteNegociation, requeteOuvertureSession, extraireNomSmb } =
    require("../src/services/nomService");

  return new Promise((resoudre) => {
    const socket = new net.Socket();
    let recu = Buffer.alloc(0);
    let etape = 0;
    let fini = false;

    const finir = () => {
      if (fini) return;
      fini = true;
      clearTimeout(minuterie);
      socket.destroy();
      resoudre();
    };
    const minuterie = setTimeout(() => {
      console.log(`  ${R}délai dépassé à l'étape ${etape}${F}`);
      finir();
    }, 4000);

    socket.on("error", (e) => {
      console.log(`  ${R}connexion : ${e.message}${F}`);
      finir();
    });
    socket.on("close", () => {
      if (!fini) console.log(`  ${J}la machine a fermé la connexion${F}`);
      finir();
    });

    socket.on("data", (morceau) => {
      recu = Buffer.concat([recu, morceau]);
      while (recu.length >= 4) {
        const longueur = recu.readUIntBE(1, 3);
        if (recu.length < 4 + longueur) return;
        const msg = recu.subarray(4, 4 + longueur);
        recu = recu.subarray(4 + longueur);

        if (msg.length < 68) {
          console.log(`  ${R}réponse trop courte (${msg.length} octets)${F}`);
          return finir();
        }

        const etat = msg.readUInt32LE(8);
        const commande = msg.readUInt16LE(12);

        if (etape === 0) {
          const dialecte = msg.readUInt16LE(68);
          console.log(`  1. NEGOTIATE   état ${nomEtat(etat)}`);
          console.log(
            `                 dialecte retenu : 0x${dialecte
              .toString(16)
              .padStart(4, "0")}${
              dialecte === 0x0311 ? `  ${J}(3.1.1 — non proposé par nous)${F}` : ""
            }`
          );
          if (etat !== 0) {
            console.log(`  ${R}La négociation a échoué : on s'arrête ici.${F}`);
            return finir();
          }
          etape = 1;
          socket.write(requeteOuvertureSession());
        } else {
          const tailleJeton = msg.length >= 76 ? msg.readUInt16LE(64 + 6) : 0;
          const aJeton = msg.indexOf("NTLMSSP\0", 0, "binary") >= 0;
          console.log(`  2. SESSION_SETUP  état ${nomEtat(etat)}`);
          console.log(`                    commande ${commande}, jeton de ${tailleJeton} octets`);
          console.log(
            `                    NTLMSSP présent : ${aJeton ? V + "oui" + F : R + "non" + F}`
          );
          if (aJeton) {
            const nom = extraireNomSmb(msg);
            console.log(
              `                    nom extrait : ${nom ? V + nom + F : R + "aucun" + F}`
            );
          }
          return finir();
        }
      }
    });

    console.log(`\n${G}Échange détaillé avec ${ip} :${F}\n`);
    socket.setTimeout(4000);
    socket.on("timeout", () => finir());
    socket.connect(445, ip, () => socket.write(requeteNegociation()));
  });
}

(async () => {
  let ips = process.argv.slice(2);

  const details = ips.includes("--details");
  ips = ips.filter((a) => a !== "--details");

  if (details) {
    if (ips.length !== 1) {
      console.error("\nLe mode détaillé prend UNE adresse :\n  node tools\\sonde-smb.js 192.168.1.197 --details\n");
      process.exit(1);
    }
    await detailler(ips[0]);
    console.log("");
    await db.end();
    process.exit(0);
  }

  if (ips.length === 0) {
    /* Les machines SANS NOM sont les seules qui nous intéressent : celles
       que NetBIOS nomme déjà ne gagneraient rien à répondre aussi en SMB.
       C'est l'apport PROPRE de la nouvelle source qu'on mesure. */
    const [lignes] = await db.query(
      `SELECT adresse_ip FROM EQUIPEMENT
        WHERE (nom IS NULL OR nom = '')
        ORDER BY RAND() LIMIT 12`
    );
    ips = lignes.map((l) => l.adresse_ip);
    if (ips.length === 0) {
      console.log("\nToutes les machines ont déjà un nom. Rien à sonder.\n");
      await db.end();
      process.exit(0);
    }
    console.log(`\n${G}12 machines du parc actuellement SANS NOM, au hasard.${F}`);
  }

  console.log("\n═══════════════════════════════════════════════════════════════");
  console.log("  SMB PEUT-IL NOMMER CE QUE LES AUTRES SOURCES N'ONT PAS NOMMÉ ?");
  console.log("═══════════════════════════════════════════════════════════════\n");
  console.log(`  ${G}adresse           445    NetBIOS           SMB${F}`);

  let ouverts = 0;
  let nommes = 0;

  for (const ip of ips) {
    const ouvert = await port445(ip);
    if (ouvert) ouverts++;

    const [parNetbios, parSmb] = await Promise.all([
      nomNetbios(ip).catch(() => null),
      ouvert ? nomSmb(ip).catch(() => null) : Promise.resolve(null),
    ]);
    if (parSmb) nommes++;

    console.log(
      `  ${ip.padEnd(17)} ${(ouvert ? `${V}ouvert${F}` : `${G}fermé ${F}`)} ` +
        `${(parNetbios ? V + parNetbios + F : G + "—" + F).padEnd(26)} ` +
        `${parSmb ? V + parSmb + F : ouvert ? R + "refusé" + F : G + "—" + F}`
    );
  }

  console.log("\n───────────────────────────────────────────────────────────────\n");
  console.log(`  Port 445 ouvert  : ${ouverts}/${ips.length}`);
  console.log(`  Nommées par SMB  : ${nommes}/${ips.length}`);

  if (ouverts === 0) {
    console.log(
      `\n  ${J}Aucun port 445 ouvert sur cet échantillon.${F} La sonde SMB ne\n` +
        "  peut rien apporter ici. Ce n'est pas un défaut du code : ces\n" +
        "  machines ne partagent rien sur le réseau."
    );
  } else if (nommes === 0) {
    console.log(
      `\n  ${R}Le port répond mais aucun nom n'en sort.${F} Le poste accepte la\n` +
        "  connexion et refuse la négociation — dialecte imposé, signature\n" +
        "  obligatoire, ou SMB restreint. À me signaler : c'est le seul cas\n" +
        "  qui demanderait une correction du code."
    );
  } else {
    console.log(
      `\n  ${V}La sonde fonctionne.${F} Ces noms apparaîtront en base au prochain\n` +
        "  scan — c'est le balayage qui écrit, pas cet outil."
    );
  }

  console.log("\n═══════════════════════════════════════════════════════════════\n");
  await db.end();
  process.exit(0);
})().catch((err) => {
  console.error("\nSonde interrompue :", err.message, "\n");
  process.exit(1);
});
