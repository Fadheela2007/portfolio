/**
 * tools/diagnostic-supervision.js
 *
 *   node tools\diagnostic-supervision.js
 *
 * ─────────────────────────────────────────────────────────────────────
 * POURQUOI CET OUTIL
 *
 * « Aucun relevé n'a jamais été enregistré » est un symptôme, pas une
 * cause. Il en existe cinq, indiscernables depuis l'interface :
 *
 *   1. le backend ne tourne pas ;
 *   2. il tourne, mais le cycle n'a pas encore atteint son intervalle ;
 *   3. le cycle tourne, mais TOUS les sites sont déclarés « supervisés
 *      par un agent local » — le serveur central ne regarde alors plus
 *      rien, et rien ne le signale à l'écran ;
 *   4. les sites sont supervisés mais ne contiennent aucun équipement ;
 *   5. le cycle échoue à chaque passage (colonne manquante, base
 *      inaccessible) — visible seulement dans le journal du serveur.
 *
 * Le cas 3 s'est déjà produit sur ce projet : 135 équipements plus
 * surveillés par personne pendant quatre jours, parce qu'un agent d'essai
 * avait tourné cinq minutes. C'est celui qu'on ne devine jamais.
 *
 * Cet outil tranche entre les cinq, en une commande, sans démarrer le
 * serveur.
 * ─────────────────────────────────────────────────────────────────────
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const db = require("../src/db");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

const ligne = (etat, texte, detail) => {
  const puce = etat === "ok" ? `${V}✓${F}` : etat === "ko" ? `${R}✗${F}` : `${J}!${F}`;
  console.log(`  ${puce} ${texte}`);
  if (detail) console.log(`      ${G}${detail}${F}`);
};

(async () => {
  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  POURQUOI LA SUPERVISION NE PRODUIT-ELLE RIEN ?");
  console.log("═══════════════════════════════════════════════════════\n");

  // ── 1. LES SITES ET LEUR MODE DE SUPERVISION ──
  //
  // Le cycle central ne regarde QUE les sites dont
  // `supervision_par_agent` vaut FALSE. C'est le filtre le plus
  // silencieux de la plateforme : un site mal déclaré disparaît de la
  // supervision sans qu'aucun écran ne l'indique.
  let sites;
  try {
    [sites] = await db.query(
      `SELECT s.id_site, s.nom, s.supervision_par_agent, s.dernier_push,
              (SELECT COUNT(*) FROM EQUIPEMENT e WHERE e.id_site = s.id_site) AS nb
       FROM SITE s ORDER BY s.id_site`
    );
  } catch (err) {
    ligne("ko", "Lecture des sites impossible", err.message);
    process.exit(2);
  }

  console.log("  SITES\n");
  let equipementsSupervises = 0;
  for (const s of sites) {
    const parAgent = s.supervision_par_agent === 1 || s.supervision_par_agent === true;
    const push = s.dernier_push
      ? `dernier envoi d'agent il y a ${Math.round((Date.now() - new Date(s.dernier_push).getTime()) / 60000)} min`
      : "aucun envoi d'agent";
    if (parAgent) {
      ligne("alerte", `Site ${s.id_site} « ${s.nom} » — ${s.nb} équipement(s) — AGENT LOCAL`,
        `le serveur central ne les supervise pas (${push})`);
    } else {
      equipementsSupervises += Number(s.nb);
      ligne("ok", `Site ${s.id_site} « ${s.nom} » — ${s.nb} équipement(s) — CYCLE CENTRAL`, push);
    }
  }

  console.log("");
  if (equipementsSupervises === 0) {
    ligne("ko", "Aucun équipement n'est supervisé par le serveur central",
      "tous les sites sont déclarés « agent local », ou n'ont aucun équipement — " +
      "corrigez depuis l'écran Sites, ou : UPDATE SITE SET supervision_par_agent = FALSE WHERE id_site = <n>;");
  } else {
    ligne("ok", `${equipementsSupervises} équipement(s) dans le périmètre du cycle central`);
  }

  // ── 2. L'INTERVALLE DU CYCLE ──
  //
  // Il vient de la table CONFIGURATION, PAS du fichier .env.
  // SCAN_INTERVAL_MINUTES dans .env est un réglage de l'AGENT distant :
  // le confondre avec celui du cycle central fait chercher au mauvais
  // endroit pendant une heure.
  try {
    const [[c]] = await db.query(
      "SELECT valeur FROM CONFIGURATION WHERE cle = 'intervalle_scan_minutes'"
    );
    const minutes = Number(c?.valeur);
    if (!c) {
      ligne("alerte", "Intervalle du cycle : réglage absent de CONFIGURATION",
        "le code retombe sur 1 minute — ce n'est pas bloquant");
    } else if (!Number.isFinite(minutes) || minutes <= 0) {
      ligne("ko", `Intervalle du cycle : valeur « ${c.valeur} » inexploitable`,
        "le cycle ne se déclenchera jamais correctement");
    } else {
      ligne("ok", `Intervalle du cycle : ${minutes} minute(s)`,
        minutes > 10 ? "long — patientez d'autant avant de conclure à une panne" : null);
    }
  } catch (err) {
    ligne("alerte", "Intervalle du cycle illisible", err.message);
  }

  // ── 3. LES RELEVÉS ──
  const [[r]] = await db.query(
    "SELECT COUNT(*) AS total, MAX(date_releve) AS dernier FROM RELEVE"
  );
  if (Number(r.total) === 0) {
    ligne("ko", "Aucun relevé dans la base",
      "si le périmètre ci-dessus est correct, la cause est que le backend ne tourne pas — " +
      "ou qu'il échoue à chaque cycle : lisez sa fenêtre");
  } else {
    const minutes = Math.round((Date.now() - new Date(r.dernier).getTime()) / 60000);
    ligne(minutes < 10 ? "ok" : "ko",
      `${r.total} relevé(s), le dernier il y a ${minutes} min`,
      minutes < 10 ? null : "le cycle ne tourne plus depuis ce moment-là");
  }

  // ── 4. CE QUE LES RELEVÉS CONTIENNENT ──
  //
  // Des relevés qui existent mais dont toutes les colonnes sont nulles
  // produisent exactement le même écran vide que pas de relevés du tout.
  if (Number(r.total) > 0) {
    const [[q]] = await db.query(
      `SELECT SUM(latence_ms IS NOT NULL) AS lat,
              SUM(cpu_pourcent IS NOT NULL) AS cpu,
              SUM(ram_pourcent IS NOT NULL) AS ram,
              SUM(trafic_entrant_kbps IS NOT NULL) AS trafic
       FROM RELEVE WHERE date_releve >= NOW() - INTERVAL 24 HOUR`
    );
    ligne(Number(q.lat) > 0 ? "ok" : "alerte",
      `Contenu sur 24 h — latence ${q.lat || 0}, processeur ${q.cpu || 0}, mémoire ${q.ram || 0}, trafic ${q.trafic || 0}`,
      Number(q.cpu) === 0
        ? "aucune mesure SNMP : normal si le parc n'expose pas SNMP, seuls les graphiques de latence se rempliront"
        : null);
  }

  console.log("");
  await db.end();
})().catch((err) => {
  console.error(`\n${R}Diagnostic interrompu :${F}`, err.message);
  process.exit(2);
});
