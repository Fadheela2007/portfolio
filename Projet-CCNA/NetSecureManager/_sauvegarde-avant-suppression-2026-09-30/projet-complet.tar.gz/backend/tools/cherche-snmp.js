/**
 * tools/cherche-snmp.js
 * Quels équipements répondent en SNMP, et avec quelle communauté ?
 *
 *   node tools\cherche-snmp.js 192.168.0.254 192.168.1.191 192.168.0.250
 *   node tools\cherche-snmp.js 192.168.0.254 -c public,private,cpsnmp
 *
 * ─────────────────────────────────────────────────────────────────────
 * POURQUOI CET OUTIL
 *
 * Le scan interroge en SNMP avec UNE seule communauté : « public », ou
 * celle configurée pour la plage. Quand un équipement ne répond pas, on
 * ne sait pas s'il n'a pas SNMP, ou s'il l'a avec une AUTRE communauté.
 * La différence décide de tout : dans le premier cas il n'y a rien à
 * faire, dans le second il suffit de renseigner la bonne communauté pour
 * débloquer la mesure de bande passante et la carte des raccordements.
 *
 * Cet outil essaie plusieurs communautés courantes, en v2c puis v1, et
 * dit exactement laquelle a ouvert la porte — et ce que l'équipement a
 * répondu. Il NE MODIFIE RIEN : il lit, il affiche.
 *
 * CE QU'IL LIT QUAND ÇA RÉPOND
 *
 *   sysDescr  la description que l'équipement donne de lui-même ;
 *   sysName   le nom qu'il porte ;
 *   ifNumber  son nombre d'interfaces — un chiffre élevé (24, 48) trahit
 *             un COMMUTATEUR, ce qui est précisément ce qu'on cherche.
 *
 * PRUDENCE. Essayer des communautés est une forme de devinette, et sur
 * un réseau qu'on ne possède pas, une devinette de trop ressemble à une
 * intrusion. La liste par défaut est COURTE et ne contient que des
 * valeurs d'usine publiques et bien connues, jamais de dictionnaire.
 * Restez-en là sur le réseau d'un tiers.
 * ─────────────────────────────────────────────────────────────────────
 */
const snmp = require("net-snmp");

// Communautés d'usine les plus répandues. Volontairement courte : voir
// la note de prudence ci-dessus.
const COMMUNAUTES_DEFAUT = ["public", "private"];

const OID = {
  sysDescr: "1.3.6.1.2.1.1.1.0",
  sysName: "1.3.6.1.2.1.1.5.0",
  ifNumber: "1.3.6.1.2.1.2.1.0",
};

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

// ── Analyse des arguments ────────────────────────────────────────────
const args = process.argv.slice(2);
const ips = [];
let communautes = COMMUNAUTES_DEFAUT;

for (let i = 0; i < args.length; i++) {
  if (args[i] === "-c" || args[i] === "--communautes") {
    communautes = (args[++i] || "").split(",").map((s) => s.trim()).filter(Boolean);
  } else if (/^\d+\.\d+\.\d+\.\d+$/.test(args[i])) {
    ips.push(args[i]);
  }
}

if (ips.length === 0) {
  console.error(
    "\nUsage : node tools\\cherche-snmp.js <ip> [<ip>...] [-c communaute1,communaute2]\n"
  );
  process.exit(1);
}

/** Lit un OID unique. Rend { valeur } ou { erreur } — ne lève jamais. */
function lire(ip, communaute, version, oid) {
  return new Promise((resolve) => {
    let session;
    try {
      session = snmp.createSession(ip, communaute, {
        timeout: 2000,
        retries: 0,
        version,
      });
    } catch (e) {
      return resolve({ erreur: e.message });
    }
    let repondu = false;
    const finir = (r) => {
      if (repondu) return;
      repondu = true;
      try { session.close(); } catch { /* déjà fermée */ }
      resolve(r);
    };
    session.on("error", (e) => finir({ erreur: e.message }));
    session.get([oid], (err, varbinds) => {
      if (err) return finir({ erreur: err.message });
      const vb = varbinds && varbinds[0];
      if (!vb || snmp.isVarbindError(vb)) return finir({ erreur: "pas de valeur" });
      finir({ valeur: vb.value });
    });
  });
}

const texte = (v) => (Buffer.isBuffer(v) ? v.toString("utf8") : String(v)).trim();

(async () => {
  console.log("\n═══════════════════════════════════════════════════════════════");
  console.log("  QUI RÉPOND EN SNMP, ET AVEC QUELLE COMMUNAUTÉ ?");
  console.log("═══════════════════════════════════════════════════════════════\n");
  console.log(`  ${G}Communautés essayées : ${communautes.join(", ")}${F}`);
  console.log(`  ${G}Versions : v2c puis v1. L'outil ne modifie rien.${F}\n`);

  const trouves = [];

  for (const ip of ips) {
    let ouvert = null;

    for (const communaute of communautes) {
      for (const [nomV, version] of [["v2c", snmp.Version2c], ["v1", snmp.Version1]]) {
        const r = await lire(ip, communaute, version, OID.sysDescr);
        if (!r.erreur) {
          ouvert = { communaute, nomV, sysDescr: texte(r.valeur) };
          break;
        }
      }
      if (ouvert) break;
    }

    if (!ouvert) {
      console.log(`  ${ip.padEnd(16)} ${R}muet — aucune communauté essayée n'a répondu${F}`);
      continue;
    }

    // On complète avec le nom et le nombre d'interfaces.
    const version = ouvert.nomV === "v2c" ? snmp.Version2c : snmp.Version1;
    const rNom = await lire(ip, ouvert.communaute, version, OID.sysName);
    const rIf = await lire(ip, ouvert.communaute, version, OID.ifNumber);
    const nbIf = rIf.erreur ? null : Number(texte(rIf.valeur));

    trouves.push({ ip, ...ouvert, nbIf });

    console.log(
      `  ${ip.padEnd(16)} ${V}RÉPOND${F}  communauté « ${ouvert.communaute} » (${ouvert.nomV})`
    );
    if (!rNom.erreur) console.log(`  ${" ".repeat(16)} ${G}nom : ${texte(rNom.valeur)}${F}`);
    if (ouvert.sysDescr) {
      console.log(`  ${" ".repeat(16)} ${G}${ouvert.sysDescr.slice(0, 90)}${F}`);
    }
    if (nbIf !== null) {
      const indice =
        nbIf >= 10
          ? `  ${J}← ${nbIf} interfaces : profil d'un COMMUTATEUR${F}`
          : `  ${G}(${nbIf} interface${nbIf > 1 ? "s" : ""})${F}`;
      console.log(`  ${" ".repeat(16)}${indice}`);
    }
    console.log("");
  }

  console.log("───────────────────────────────────────────────────────────────\n");
  if (trouves.length === 0) {
    console.log(
      `  ${J}Aucun de ces équipements ne répond aux communautés essayées.${F}\n` +
        "  Soit SNMP y est désactivé, soit la communauté est propre au parc.\n" +
        "  Une seule question au responsable tranche : « quelle est la\n" +
        "  communauté SNMP en lecture de cet équipement, ou peut-on activer\n" +
        "  SNMP en lecture seule ? »\n"
    );
  } else {
    console.log(`  ${V}${trouves.length} équipement(s) répondent en SNMP.${F}\n`);
    console.log(
      "  À faire pour les brancher à la plateforme : sur la page Plages\n" +
        "  réseau, renseigner la communauté trouvée pour la plage concernée,\n" +
        "  puis relancer un scan. La bande passante et les interfaces\n" +
        "  remonteront alors pour ces équipements.\n"
    );
    const commutateurs = trouves.filter((t) => t.nbIf !== null && t.nbIf >= 10);
    if (commutateurs.length > 0) {
      console.log(
        `  ${J}${commutateurs.length} d'entre eux ont le profil d'un commutateur\n` +
          "  (beaucoup d'interfaces). Si c'en est un et qu'il est administrable,\n" +
          "  la mesure de bande passante PAR PORT et la carte des raccordements\n" +
          `  physiques redeviennent possibles sur ce parc.${F}\n`
      );
    }
  }
  console.log("═══════════════════════════════════════════════════════════════\n");
  process.exit(0);
})().catch((err) => {
  console.error("\nSonde interrompue :", err.message, "\n");
  process.exit(1);
});
