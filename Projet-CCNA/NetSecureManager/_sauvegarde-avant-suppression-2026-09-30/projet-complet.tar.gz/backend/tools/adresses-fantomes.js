/**
 * tools/adresses-fantomes.js — VÉRIFICATION SEULE. Ne supprime plus rien.
 *
 *   node tools\adresses-fantomes.js
 *
 * ─────────────────────────────────────────────────────────────────────
 * L'option `--supprimer` a été retirée, et c'est le sujet même de cet
 * outil.
 *
 * Une adresse IP n'est pas un équipement. Retirer celles qui ne
 * répondent à rien n'est pas une opération de maintenance à lancer de
 * temps en temps : c'est une RÈGLE du produit, et le produit la tient
 * lui-même — à la fin de chaque scan et à chaque cycle de supervision
 * (src/services/inventaireService.js).
 *
 * Un logiciel qui connaît la règle et demande quand même à l'exploitant
 * de lancer une commande n'est pas fini.
 *
 * Cet outil ne sert donc plus qu'à VÉRIFIER que le nettoyage automatique
 * fait son travail. Le résultat normal est : aucune ligne.
 * ─────────────────────────────────────────────────────────────────────
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const db = require("../src/db");

const V = "\x1b[32m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

(async () => {
  const [[{ total }]] = await db.query("SELECT COUNT(*) AS total FROM EQUIPEMENT");

  // Même critère que inventaireService, sans la colonne `preuve_existence`
  // pour rester lisible si la migration n'est pas passée.
  const [restants] = await db.query(`
    SELECT e.id_equipement, e.adresse_ip, e.fabricant, e.statut, e.date_ajout
    FROM EQUIPEMENT e
    WHERE NOT EXISTS (SELECT 1 FROM RELEVE r WHERE r.id_equipement = e.id_equipement)
      AND NOT EXISTS (SELECT 1 FROM SERVICE_DETECTE s WHERE s.id_equipement = e.id_equipement)
      AND e.sys_descr IS NULL
      AND e.os_detecte IS NULL
    ORDER BY INET_ATON(e.adresse_ip)`);

  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  INVENTAIRE — VÉRIFICATION");
  console.log("═══════════════════════════════════════════════════════\n");

  if (restants.length === 0) {
    console.log(`  ${V}Rien à signaler.${F} Les ${total} équipements de l'inventaire`);
    console.log("  ont tous donné au moins un signe de vie.\n");
    console.log(`  ${G}Le nettoyage est automatique : aucune commande à lancer.${F}\n`);
    await db.end();
    return;
  }

  console.log(`  ${G}adresse            marque                statut     découverte${F}`);
  for (const r of restants) {
    console.log(
      `  ${r.adresse_ip.padEnd(17)} ${String(r.fabricant || "—").slice(0, 20).padEnd(21)} ` +
        `${String(r.statut).padEnd(10)} ${new Date(r.date_ajout).toLocaleString("fr-FR")}`
    );
  }

  const encoreUp = restants.filter((r) => r.statut === "up").length;
  const recentes = restants.filter(
    (r) => Date.now() - new Date(r.date_ajout).getTime() < 2 * 60 * 1000
  ).length;

  console.log(`\n  ${restants.length} ligne(s) sans aucun signe de vie sur ${total}.\n`);
  console.log(`  ${J}Ce n'est pas une action à faire : c'est un état transitoire.${F}`);
  if (encoreUp > 0) {
    console.log(
      `  ${encoreUp} sont encore marquées « up » par un ancien scan. Le premier\n` +
        "  cycle de supervision les passera en « inconnu », le nettoyage du\n" +
        "  même cycle les retirera. Compter une à deux minutes."
    );
  }
  if (recentes > 0) {
    console.log(`  ${recentes} viennent d'être découvertes : le nettoyage attend deux minutes.`);
  }
  console.log(
    `\n  ${G}Si ces lignes sont toujours là dans cinq minutes, le backend n'est\n` +
      `  pas démarré, ou le cycle de supervision ne tourne pas :\n` +
      `      node tools\\diagnostic-supervision.js${F}\n`
  );

  await db.end();
})().catch((e) => {
  console.error("Erreur:", e.message);
  process.exitCode = 1;
});
