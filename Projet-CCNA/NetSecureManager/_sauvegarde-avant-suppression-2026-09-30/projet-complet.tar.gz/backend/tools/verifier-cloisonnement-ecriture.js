/**
 * tools/verifier-cloisonnement-ecriture.js
 * Un administrateur rattaché à un site peut-il ÉCRIRE ailleurs ?
 *
 *   node tools\verifier-cloisonnement-ecriture.js admin-du-site@exemple.fr
 *
 * Le mot de passe est demandé ensuite, sans être affiché.
 *
 * ─────────────────────────────────────────────────────────────────────
 * POURQUOI CET OUTIL EXISTE
 *
 * `verifier-cloisonnement.js` vérifie la LECTURE : le compte restreint
 * ne reçoit rien qui appartienne à un autre site. C'est la moitié de la
 * question.
 *
 * L'audit du 8 septembre 2026 a trouvé l'autre moitié ouverte. Trois
 * routes du contrôle d'accès web recevaient un identifiant de POLITIQUE
 * ou de RÈGLE — jamais un identifiant de site — et ne vérifiaient à qui
 * cet objet appartenait. Un administrateur du site 2 changeait un nombre
 * dans l'URL et débloquait une catégorie chez un autre client. La
 * lecture, elle, était parfaitement cloisonnée : aucun écran, aucun test
 * de lecture n'aurait montré quoi que ce soit.
 *
 * La leçon tient en une phrase : le cloisonnement était appliqué partout
 * où le paramètre s'appelait `id_site`, et nulle part ailleurs. Cet outil
 * teste précisément les routes où il ne s'appelle pas comme ça.
 *
 * CE QUI EST ÉCRIT PENDANT LE TEST — ET CE QUI EST NETTOYÉ
 *
 * Une tentative de suppression ne peut pas se tester sur une vraie règle :
 * si la protection était absente, le test détruirait une règle de
 * production. L'outil pose donc lui-même une règle-appât sur la politique
 * étrangère, tente de la supprimer par l'API, puis la retire de la base
 * quoi qu'il arrive. Rien de réel n'est mis en jeu, et le bilan indique
 * explicitement l'état de l'appât à la fin.
 * ─────────────────────────────────────────────────────────────────────
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const readline = require("readline");
const db = require("../src/db");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";
const BASE = process.env.URL_API_LOCALE || "http://localhost:5000/api";

const MARQUEUR = `cloisonnement-${Date.now()}.invalid`;

function demanderMotDePasse(invite) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const ecrire = rl._writeToOutput;
    rl._writeToOutput = function (chaine) {
      if (chaine.includes(invite)) ecrire.call(rl, chaine);
    };
    rl.question(invite, (r) => {
      rl.close();
      process.stdout.write("\n");
      resolve(r);
    });
  });
}

async function appeler(chemin, { methode = "GET", corps, jeton } = {}) {
  const r = await fetch(`${BASE}${chemin}`, {
    method: methode,
    headers: {
      ...(corps ? { "Content-Type": "application/json" } : {}),
      ...(jeton ? { Authorization: `Bearer ${jeton}` } : {}),
    },
    body: corps ? JSON.stringify(corps) : undefined,
  });
  const texte = await r.text();
  let data = null;
  try {
    data = JSON.parse(texte);
  } catch {
    /* réponse non JSON */
  }
  return { statut: r.status, data, texte };
}

/**
 * Un contrôle réussit quand le serveur REFUSE avec un code d'accès.
 *
 * Comme dans verifier-protections.js, « refusé pour la mauvaise raison »
 * n'est pas un succès : un 400 dû à un corps malformé ne prouve rien sur
 * le cloisonnement. Les codes acceptés sont donc uniquement 403 et 404.
 */
let echecs = 0;
function juger(nom, resultat, explication) {
  const ok = [403, 404].includes(resultat.statut);
  const detail = resultat.data?.error || String(resultat.texte || "").slice(0, 60) || "(vide)";
  console.log(
    `  ${ok ? V + "✓" : R + "✗"}${F} ${nom.padEnd(50)} HTTP ${resultat.statut} ${G}${detail}${F}`
  );
  if (!ok) {
    console.log(`      ${R}${explication}${F}`);
    echecs++;
  }
  return ok;
}

(async () => {
  const [, , email, motDePasseArgument] = process.argv;
  if (!email) {
    console.error(`
Usage :
  node tools\\verifier-cloisonnement-ecriture.js <email d'un ADMIN rattaché à un site>

Le compte doit avoir le rôle « admin » ET être rattaché à un site précis.
C'est le seul profil qui peut révéler cette faille : un lecteur est
arrêté plus tôt par le contrôle de rôle, un admin global a le droit de
tout faire.
`);
    process.exit(1);
  }

  const motDePasse =
    motDePasseArgument ||
    (await demanderMotDePasse("Mot de passe (rien ne s'affiche pendant la saisie) : "));

  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  CLOISONNEMENT EN ÉCRITURE");
  console.log("═══════════════════════════════════════════════════════\n");

  /* ── 1. Connexion, et vérification du profil ─────────────────────── */
  const connexion = await appeler("/auth/login", {
    methode: "POST",
    corps: { email, mot_de_passe: motDePasse },
  });
  if (connexion.statut !== 200 || !connexion.data?.token) {
    console.log(`  ${R}Connexion refusée (HTTP ${connexion.statut}).${F}`);
    console.log(`  ${G}${connexion.data?.error || connexion.texte}${F}\n`);
    process.exit(1);
  }
  const jeton = connexion.data.token;
  const moi = connexion.data.utilisateur;

  console.log(`  Compte : ${moi.nom} — rôle ${moi.role}, site ${moi.id_site ?? "(global)"}\n`);

  // LE TEST N'A DE SENS QUE POUR CE PROFIL. Le lancer avec un admin
  // global renverrait « tout est autorisé » — ce qui est correct, et
  // ressemblerait pourtant à un échec massif. On refuse plutôt que de
  // produire un résultat trompeur.
  if (moi.role !== "admin" || moi.id_site === null || moi.id_site === undefined) {
    console.log(`  ${J}Ce compte n'est pas un administrateur rattaché à un site.${F}`);
    console.log(`  ${G}Rôle attendu : admin. Site attendu : un identifiant, pas « global ».`);
    console.log(`  Créez un tel compte depuis l'écran Utilisateurs, puis relancez.${F}\n`);
    process.exit(1);
  }
  const monSite = Number(moi.id_site);

  /* ── 2. Ce qui existe ailleurs, vu de la base ────────────────────── */
  const [politiques] = await db.query(
    "SELECT id_politique, id_site, nom FROM POLITIQUE_WEB ORDER BY id_site IS NULL, id_site"
  );
  const parDefaut = politiques.find((p) => p.id_site === null);
  const etrangere = politiques.find((p) => p.id_site !== null && Number(p.id_site) !== monSite);
  const [autresSites] = await db.query("SELECT id_site, nom FROM SITE WHERE id_site <> ?", [
    monSite,
  ]);

  console.log(`  ${G}Cibles disponibles pour le test${F}`);
  console.log(
    `    politique par défaut  : ${parDefaut ? "#" + parDefaut.id_politique : `${J}aucune${F}`}`
  );
  console.log(
    `    politique d'un autre site : ${
      etrangere ? `#${etrangere.id_politique} (site ${etrangere.id_site})` : `${J}aucune${F}`
    }`
  );
  console.log(
    `    autres sites : ${autresSites.length > 0 ? autresSites.map((s) => s.id_site).join(", ") : `${J}aucun${F}`}\n`
  );

  if (!parDefaut && !etrangere && autresSites.length === 0) {
    console.log(`  ${J}Rien à tester : cette base ne contient qu'un site et aucune politique.${F}`);
    console.log(`  ${G}Créez un second site et une politique de blocage, puis relancez.${F}\n`);
    process.exit(0);
  }

  /* ── 3. La politique par défaut s'applique à TOUS les sites ──────── */
  console.log(`  ${G}Politique par défaut (elle vaut pour tous les sites)${F}`);

  juger(
    "PUT /acces-web/politique sans id_site",
    await appeler("/acces-web/politique", {
      methode: "PUT",
      jeton,
      corps: { nom: "Tentative depuis un site", active: false, categories: [] },
    }),
    "ACCEPTÉ : un administrateur de site réécrit la politique de TOUTE la plateforme. " +
      "C'est le défaut principal de l'audit du 8 septembre — `id_site` vaut null par " +
      "défaut dans cette route, et l'ancien test ne se déclenchait donc jamais."
  );

  if (parDefaut) {
    juger(
      `POST /acces-web/politique/${parDefaut.id_politique}/domaine (par défaut)`,
      await appeler(`/acces-web/politique/${parDefaut.id_politique}/domaine`, {
        methode: "POST",
        jeton,
        corps: { domaine: MARQUEUR, action: "bloquer", commentaire: "test de cloisonnement" },
      }),
      "ACCEPTÉ : une règle de blocage vient d'être posée sur la politique de tous les sites."
    );
  }

  /* ── 4. La politique d'un autre site ─────────────────────────────── */
  if (etrangere) {
    console.log(`\n  ${G}Politique du site ${etrangere.id_site} (« ${etrangere.nom} »)${F}`);

    juger(
      `PUT /acces-web/politique id_site=${etrangere.id_site}`,
      await appeler("/acces-web/politique", {
        methode: "PUT",
        jeton,
        corps: {
          id_site: etrangere.id_site,
          nom: "Tentative croisée",
          active: false,
          categories: [],
        },
      }),
      "ACCEPTÉ : la politique d'un autre client vient d'être désactivée."
    );

    juger(
      `POST /acces-web/politique/${etrangere.id_politique}/domaine`,
      await appeler(`/acces-web/politique/${etrangere.id_politique}/domaine`, {
        methode: "POST",
        jeton,
        corps: { domaine: MARQUEUR, action: "bloquer", commentaire: "test de cloisonnement" },
      }),
      "ACCEPTÉ : ajout d'une règle de blocage sur le réseau d'un autre client."
    );

    /* ── 5. Suppression : on teste sur un appât, jamais sur du réel ── */
    //
    // Si la protection manquait, ce test détruirait une règle de
    // production. On pose donc notre propre règle en base, on tente de la
    // supprimer par l'API, et on la retire ensuite quoi qu'il arrive.
    const [pose] = await db.query(
      `INSERT INTO POLITIQUE_DOMAINE (id_politique, domaine, action, commentaire)
       VALUES (?, ?, 'bloquer', 'appât du test de cloisonnement — supprimable')`,
      [etrangere.id_politique, `appat-${MARQUEUR}`]
    );

    juger(
      `DELETE /acces-web/domaine/${pose.insertId} (appât)`,
      await appeler(`/acces-web/domaine/${pose.insertId}`, { methode: "DELETE", jeton }),
      "ACCEPTÉ : suppression d'une règle appartenant à un autre site — " +
        "un blocage web peut être levé chez un client par l'administrateur d'un autre."
    );

    const [reste] = await db.query(
      "SELECT id_regle FROM POLITIQUE_DOMAINE WHERE id_regle = ?",
      [pose.insertId]
    );
    if (reste.length > 0) {
      await db.query("DELETE FROM POLITIQUE_DOMAINE WHERE id_regle = ?", [pose.insertId]);
      console.log(`      ${G}appât retiré de la base${F}`);
    } else {
      console.log(`      ${R}l'appât a été supprimé PAR L'API : la protection est absente${F}`);
    }
  }

  /* ── 6. Contrôles de référence : ceux-ci étaient déjà en place ───── */
  if (autresSites.length > 0) {
    const autre = autresSites[0].id_site;
    console.log(`\n  ${G}Routes déjà protégées (contrôle de référence)${F}`);

    juger(
      `POST /scan sur le site ${autre}`,
      await appeler("/scan", {
        methode: "POST",
        jeton,
        corps: { id_site: autre, cidr: "192.0.2.0/30" },
      }),
      "ACCEPTÉ : scan d'un réseau qui n'est pas le vôtre."
    );

    juger(
      `PATCH /sites/${autre}/supervision`,
      await appeler(`/sites/${autre}/supervision`, {
        methode: "PATCH",
        jeton,
        corps: { supervision_par_agent: true },
      }),
      "ACCEPTÉ : la supervision d'un autre site vient d'être coupée."
    );

    juger(
      `GET /sites/${autre}/agent (jeton d'agent)`,
      await appeler(`/sites/${autre}/agent`, { jeton }),
      "ACCEPTÉ : le jeton d'agent d'un autre site est lisible — il permet d'y injecter de faux équipements."
    );
  }

  /* ── 7. Rien n'a-t-il été écrit ? ────────────────────────────────── */
  const [traces] = await db.query(
    "SELECT id_regle, id_politique, domaine FROM POLITIQUE_DOMAINE WHERE domaine LIKE ?",
    [`%${MARQUEUR}`]
  );

  console.log("\n───────────────────────────────────────────────────────");
  if (traces.length > 0) {
    console.log(`  ${R}${traces.length} règle(s) ont RÉELLEMENT été écrites :${F}`);
    for (const t of traces) {
      console.log(`    politique #${t.id_politique} — ${t.domaine}`);
    }
    await db.query("DELETE FROM POLITIQUE_DOMAINE WHERE domaine LIKE ?", [`%${MARQUEUR}`]);
    console.log(`  ${G}Elles viennent d'être retirées. La faille, elle, reste à corriger.${F}`);
  }

  if (echecs === 0) {
    console.log(`  ${V}Le cloisonnement tient aussi en écriture.${F}`);
    console.log(`  ${G}Aucune des tentatives n'a abouti, et rien n'a été modifié.${F}`);
  } else {
    console.log(`  ${R}${echecs} écriture(s) autorisée(s) hors du périmètre.${F}`);
    console.log("  Un acheteur multi-sites ne signera pas tant qu'une seule subsiste.");
  }
  console.log("───────────────────────────────────────────────────────\n");

  await db.end();
  process.exitCode = echecs > 0 ? 1 : 0;
})().catch(async (err) => {
  console.error(`\n${R}Erreur :${F} ${err.message}`);
  console.error(`${J}Le backend est-il démarré, et la base joignable ?${F}\n`);
  await db.end().catch(() => {});
  process.exitCode = 2;
});
