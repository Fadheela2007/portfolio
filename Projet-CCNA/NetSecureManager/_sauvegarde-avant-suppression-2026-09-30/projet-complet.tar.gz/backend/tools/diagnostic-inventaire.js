/**
 * tools/diagnostic-inventaire.js
 *
 *   node tools\diagnostic-inventaire.js
 *
 * POURQUOI « INTÉRIEUR DE LA MACHINE » RESTE VIDE.
 *
 * Quatre causes donnent exactement le même écran, et rien ne les
 * distingue à l'affichage :
 *
 *   1. la migration du 10 septembre n'est pas passée — les tables qui
 *      rangent les programmes n'existent pas ;
 *   2. le backend n'a pas été redémarré depuis l'ajout de la lecture
 *      SNMP — il tourne encore sur l'ancien code ;
 *   3. aucun scan n'a eu lieu depuis ;
 *   4. les machines répondent bien en SNMP, mais leur agent SNMP
 *      n'expose pas la branche des programmes en cours.
 *
 * Les trois premières se réparent en une minute. La quatrième est une
 * limite du parc, pas un défaut du produit — et elle appelle une autre
 * porte d'entrée (WMI sur les postes Windows, ou l'agent de poste).
 *
 * Cet outil les sépare. Il interroge RÉELLEMENT le réseau, sur un
 * échantillon de machines, et dit ce que chacune a répondu.
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const db = require("../src/db");
const { snmpInventaireLogiciel } = require("../src/services/discoveryService");
const { cidrSubnet } = require("../src/services/adressesIp");

const V = "\x1b[32m", J = "\x1b[33m", R = "\x1b[31m", G = "\x1b[90m", F = "\x1b[0m";

/** Combien de machines on sonde réellement. Au-delà, c'est long pour rien. */
const ECHANTILLON = 12;

/** La table existe-t-elle ? */
async function tableExiste(nom) {
  try {
    await db.query(`SELECT 1 FROM ${nom} LIMIT 1`);
    return true;
  } catch (err) {
    if (/doesn't exist/i.test(err.message)) return false;
    throw err;
  }
}

/** La colonne existe-t-elle ? */
async function colonneExiste(table, colonne) {
  try {
    await db.query(`SELECT ${colonne} FROM ${table} LIMIT 1`);
    return true;
  } catch (err) {
    if (/Unknown column|doesn't exist/i.test(err.message)) return false;
    throw err;
  }
}

/**
 * Communauté SNMP à utiliser pour une adresse : celle de la plage
 * déclarée qui la contient, sinon « public ».
 *
 * On ne prend PAS « la première plage du site » : un site a souvent
 * plusieurs VLAN avec des communautés différentes, et se tromper de
 * communauté fait conclure « cette machine ne répond pas » alors qu'on
 * lui a parlé dans une langue qu'elle ne comprend pas.
 */
function communautePour(ip, plages) {
  for (const p of plages) {
    try {
      if (cidrSubnet(p.cidr).contains(ip)) return p.snmp_community || "public";
    } catch {
      /* plage illisible : on passe à la suivante */
    }
  }
  return "public";
}

(async () => {
  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  POURQUOI « INTÉRIEUR DE LA MACHINE » EST VIDE");
  console.log("═══════════════════════════════════════════════════════\n");

  /* ── 1. LA BASE EST-ELLE PRÊTE ? ── */
  const logiciels = await tableExiste("LOGICIEL_INSTALLE");
  const processus = await tableExiste("PROCESSUS_OBSERVE");
  const colonneDate = await colonneExiste("EQUIPEMENT", "dernier_inventaire_poste");
  const colonneVersion = await colonneExiste("EQUIPEMENT", "agent_poste_version");

  console.log("  1. LA BASE");
  console.log(`     LOGICIEL_INSTALLE            ${logiciels ? V + "présente" : R + "ABSENTE"}${F}`);
  console.log(`     PROCESSUS_OBSERVE            ${processus ? V + "présente" : R + "ABSENTE"}${F}`);
  console.log(`     EQUIPEMENT.dernier_inventaire_poste  ${colonneDate ? V + "présente" : R + "ABSENTE"}${F}`);
  console.log(`     EQUIPEMENT.agent_poste_version       ${colonneVersion ? V + "présente" : R + "ABSENTE"}${F}\n`);

  if (!logiciels || !processus || !colonneDate || !colonneVersion) {
    console.log(`  ${R}→ CAUSE TROUVÉE : la migration du 10 septembre n'est pas passée.${F}`);
    console.log(`  ${G}  Rien ne peut être enregistré, quoi que les machines répondent.`);
    console.log(`    Pour corriger :  node tools\\appliquer-migrations.js`);
    console.log(`    puis relancez un scan, puis ce diagnostic.${F}\n`);
    await db.end();
    return;
  }

  /* ── 2. CE QUI EST DÉJÀ RANGÉ ── */
  const [[stock]] = await db.query(
    `SELECT
       (SELECT COUNT(*) FROM PROCESSUS_OBSERVE) AS nb_processus,
       (SELECT COUNT(DISTINCT id_equipement) FROM PROCESSUS_OBSERVE) AS machines_processus,
       (SELECT COUNT(*) FROM LOGICIEL_INSTALLE) AS nb_logiciels,
       (SELECT COUNT(*) FROM EQUIPEMENT WHERE dernier_inventaire_poste IS NOT NULL) AS machines_inventoriees,
       (SELECT COUNT(*) FROM EQUIPEMENT WHERE agent_poste_version = 'snmp') AS par_snmp,
       (SELECT COUNT(*) FROM EQUIPEMENT
          WHERE agent_poste_version IS NOT NULL AND agent_poste_version <> 'snmp') AS par_agent`
  );

  console.log("  2. CE QUI EST DÉJÀ EN BASE");
  console.log(`     Machines avec un inventaire  ${stock.machines_inventoriees}`);
  console.log(`       dont relevées par SNMP     ${stock.par_snmp}`);
  console.log(`       dont relevées par un agent ${stock.par_agent}`);
  console.log(`     Programmes enregistrés       ${stock.nb_processus} (sur ${stock.machines_processus} machine(s))`);
  console.log(`     Logiciels enregistrés        ${stock.nb_logiciels}\n`);

  /* ── 3. LE PARC RÉPOND-IL EN SNMP ? ── */
  const [[parc]] = await db.query(
    "SELECT COUNT(*) AS total, SUM(sys_descr IS NOT NULL) AS snmp FROM EQUIPEMENT"
  );
  console.log("  3. LE PARC");
  console.log(`     Équipements                  ${parc.total}`);
  console.log(`     Répondent en SNMP            ${parc.snmp || 0}\n`);

  if (Number(parc.snmp || 0) === 0) {
    console.log(`  ${J}→ CAUSE TROUVÉE : aucune machine du parc n'expose SNMP.${F}`);
    console.log(`  ${G}  La lecture des programmes passe par SNMP : sans lui, elle n'a rien`);
    console.log(`    à interroger. Ce n'est pas un défaut du produit, c'est la couverture`);
    console.log(`    réelle de ce réseau. Les autres portes sont WMI (postes Windows, avec`);
    console.log(`    un compte du domaine) et l'agent de poste.${F}\n`);
    await db.end();
    return;
  }

  /* ── 4. ON DEMANDE VRAIMENT AUX MACHINES ── */
  const [candidats] = await db.query(
    `SELECT e.id_equipement, e.adresse_ip, COALESCE(e.nom_personnalise, e.nom) AS nom,
            e.id_site, t.libelle AS type
     FROM EQUIPEMENT e
     LEFT JOIN TYPE_EQUIPEMENT t ON t.id_type = e.id_type
     WHERE e.sys_descr IS NOT NULL AND e.statut = 'up'
     ORDER BY e.adresse_ip
     LIMIT ?`,
    [ECHANTILLON]
  );

  const [plages] = await db.query(
    "SELECT cidr, snmp_community FROM PLAGE_SCAN WHERE actif = TRUE"
  );

  console.log(`  4. INTERROGATION RÉELLE — ${candidats.length} machine(s), quelques secondes\n`);

  let repondent = 0;
  for (const eq of candidats) {
    const communaute = communautePour(eq.adresse_ip, plages);
    const releve = await snmpInventaireLogiciel(eq.adresse_ip, communaute).catch(() => null);

    const nbProcessus = releve?.processus ? releve.processus.length : 0;
    const nbLogiciels = releve?.logiciels ? releve.logiciels.length : 0;
    const etiquette = `${eq.adresse_ip} ${G}${(eq.nom || eq.type || "").slice(0, 22)}${F}`;

    if (nbProcessus > 0 || nbLogiciels > 0) {
      repondent++;
      console.log(
        `     ${V}✓${F} ${etiquette}` +
          `  ${nbProcessus} programme(s), ${nbLogiciels} logiciel(s)`
      );
      // Les trois plus gros : de quoi vérifier d'un coup d'œil que ce
      // qui remonte a du sens, au lieu de croire un compteur sur parole.
      if (nbProcessus > 0) {
        const apercu = releve.processus.slice(0, 3).map((p) => p.nom).join(", ");
        console.log(`       ${G}${apercu}${F}`);
      }
    } else {
      console.log(`     ${G}·${F} ${etiquette}  ${G}silencieuse sur cette branche${F}`);
    }
  }

  /* ── 5. LE VERDICT ── */
  console.log("\n═══════════════════════════════════════════════════════\n");

  if (repondent === 0) {
    console.log(`  ${J}→ CAUSE TROUVÉE : ces machines parlent SNMP, mais aucune n'expose`);
    console.log(`     la branche des programmes en cours (HOST-RESOURCES-MIB, 1.3.6.1.2.1.25.4).${F}`);
    console.log(`  ${G}  C'est fréquent : beaucoup d'imprimantes et d'équipements réseau`);
    console.log(`    publient leur mémoire et leur processeur sans publier leurs`);
    console.log(`    programmes. Deux causes possibles, et elles se corrigent différemment :`);
    console.log(`      • la communauté SNMP est restreinte à une vue qui exclut cette`);
    console.log(`        branche — c'est un réglage sur l'équipement, pas chez nous ;`);
    console.log(`      • l'agent SNMP ne l'implémente pas du tout — rien à faire de ce`);
    console.log(`        côté, il faut une autre porte (WMI ou agent de poste).${F}\n`);
  } else if (Number(stock.machines_inventoriees) === 0) {
    console.log(`  ${J}→ CAUSE TROUVÉE : ${repondent} machine(s) répondent, mais rien n'est en base.${F}`);
    console.log(`  ${G}  Le réseau répond, la base est prête : c'est donc que le scan n'a`);
    console.log(`    pas tourné avec le nouveau code. Deux gestes, dans cet ordre :`);
    console.log(`      1. arrêtez le backend et redémarrez-le (npm start)`);
    console.log(`      2. relancez un scan depuis le tableau de bord`);
    console.log(`    Pendant le scan, la console doit afficher une ligne`);
    console.log(`    « intérieur relevé par SNMP sur N machine(s) ».${F}\n`);
  } else {
    console.log(`  ${V}→ Tout fonctionne : ${repondent}/${candidats.length} machine(s) sondée(s) répondent,`);
    console.log(`     et ${stock.machines_inventoriees} machine(s) ont déjà un inventaire en base.${F}`);
    console.log(`  ${G}  Si une fiche précise reste vide, c'est que CETTE machine-là est`);
    console.log(`    silencieuse — pas que la fonction est en panne.`);
    console.log(`    Pensez aussi à recompiler l'interface : l'affichage a changé.${F}\n`);
  }

  await db.end();
})().catch((err) => {
  console.error(`\n${R}Erreur :${F}`, err.message);
  console.error(`${G}Si le message parle d'une table ou d'une colonne inconnue,`);
  console.error(`la migration du 10 septembre n'est pas passée :`);
  console.error(`  node tools\\appliquer-migrations.js${F}\n`);
  process.exit(2);
});
