/**
 * tools/mesurer-phases-scan.js
 * Où part le temps d'un scan, phase par phase.
 *
 *   node tools\mesurer-phases-scan.js 192.168.0.239 192.168.0.1 192.168.0.50
 *
 * Sans argument, l'outil prend cinq équipements au hasard dans la base.
 *
 * ─────────────────────────────────────────────────────────────────────
 * POURQUOI CET OUTIL
 *
 * « Le scan est lent » est un symptôme, pas une cause. Un scan enchaîne
 * quatre opérations de coûts très différents, et optimiser la mauvaise
 * ne change rien :
 *
 *   ping            ~1 s d'attente si la machine est éteinte
 *   SNMP            1,5 s d'attente si elle ne répond pas — le cas de
 *                   neuf machines sur dix
 *   nmap            jusqu'à 15 s, et c'est le suspect principal
 *   scan de ports   19 ports en parallèle, 400 ms chacun
 *
 * L'outil chronomètre chaque phase sur de VRAIES machines de votre
 * réseau, puis compare la commande nmap actuelle à une version réglée.
 *
 * CE QUE LA COMPARAISON DOIT MONTRER
 *
 * La commande actuelle est `nmap -O --osscan-guess`. Cinq réglages y
 * manquent :
 *
 *   -T4               nmap attend par défaut comme s'il traversait
 *                     Internet. Sur un réseau local, c'est du temps mort.
 *   --host-timeout    sans lui, c'est Node qui TUE nmap au bout de 15 s —
 *                     on paie l'attente ET on repart les mains vides.
 *                     Avec, nmap rend ce qu'il a trouvé.
 *   -F                `-O` scanne 1 000 ports pour déduire le système.
 *                     Nous scannons déjà NOS 19 ports juste après : le
 *                     travail est fait deux fois.
 *   -n                nmap résout le nom inverse de chaque cible. Nous le
 *                     faisons déjà nous-mêmes, à quatre sources.
 *   --max-retries 2   la valeur par défaut est 10. Sur un réseau local,
 *                     une machine qui n'a pas répondu deux fois ne
 *                     répondra pas la dixième.
 *
 * On ne les applique PAS avant d'avoir mesuré. Il est possible que le
 * gain vienne d'un seul d'entre eux, ou qu'une option dégrade la
 * détection — auquel cas gagner du temps coûterait de la justesse.
 * ─────────────────────────────────────────────────────────────────────
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const { exec } = require("child_process");
const ping = require("ping");
const db = require("../src/db");
const { snmpProbe, scanPorts } = require("../src/services/discoveryService");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

/** Chronomètre une promesse. Renvoie { ms, valeur, erreur }. */
async function chrono(promesse) {
  const debut = Date.now();
  try {
    const valeur = await promesse;
    return { ms: Date.now() - debut, valeur, erreur: null };
  } catch (err) {
    return { ms: Date.now() - debut, valeur: null, erreur: err.message };
  }
}

/** Lance une commande nmap et rend ce qu'elle a trouvé. */
function lancerNmap(commande, timeoutMs) {
  return new Promise((resolve) => {
    exec(commande, { timeout: timeoutMs }, (error, stdout) => {
      if (!stdout) return resolve({ os: null, tue: !!error });
      const m =
        stdout.match(/OS details: (.+)/) || stdout.match(/Aggressive OS guesses: (.+)/);
      resolve({
        os: m ? m[1].split(",")[0].trim().slice(0, 45) : null,
        // `error` sur un timeout signifie que Node a TUÉ nmap : on n'a rien.
        tue: !!error && /timed?out|ETIMEDOUT/i.test(String(error.message || "")),
      });
    });
  });
}

const ACTUELLE = (ip) => `nmap -O --osscan-guess ${ip}`;
const REGLEE = (ip) =>
  `nmap -O --osscan-guess -T4 -F -n --max-retries 2 --host-timeout 12s ${ip}`;

(async () => {
  let cibles = process.argv.slice(2);

  if (cibles.length === 0) {
    const [rows] = await db
      .query(
        `SELECT adresse_ip FROM EQUIPEMENT
         WHERE statut = 'up' ORDER BY RAND() LIMIT 5`
      )
      .catch(() => [[]]);
    cibles = rows.map((r) => r.adresse_ip);
  }

  if (cibles.length === 0) {
    console.error("\nAucune cible. Passez des adresses en argument :");
    console.error("  node tools\\mesurer-phases-scan.js 192.168.0.239 192.168.0.1\n");
    await db.end().catch(() => {});
    process.exitCode = 1;
    return;
  }

  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  OÙ PART LE TEMPS D'UN SCAN");
  console.log("═══════════════════════════════════════════════════════\n");
  console.log(`  ${G}${cibles.length} machine(s) mesurée(s), une phase après l'autre.${F}`);
  console.log(`  ${G}Comptez environ 30 secondes par machine.${F}\n`);

  const totaux = { ping: 0, snmp: 0, nmapActuel: 0, nmapRegle: 0, ports: 0 };
  let nmapTue = 0;
  let perteDetection = 0;

  for (const ip of cibles) {
    console.log(`  ${J}${ip}${F}`);

    const p = await chrono(ping.promise.probe(ip, { timeout: 1 }));
    totaux.ping += p.ms;
    console.log(`    ping                  ${String(p.ms).padStart(6)} ms   ${G}${p.valeur?.alive ? "répond" : "muet"}${F}`);

    const s = await chrono(snmpProbe(ip, process.env.SNMP_COMMUNITY || "public"));
    totaux.snmp += s.ms;
    console.log(
      `    SNMP                  ${String(s.ms).padStart(6)} ms   ${G}${s.valeur ? "répond" : "muet"}${F}`
    );

    // nmap n'est appelé dans le vrai scan QUE si SNMP n'a pas conclu.
    // On le mesure quand même sur toutes les cibles : c'est la comparaison
    // des deux commandes qui nous intéresse ici.
    const a = await chrono(lancerNmap(ACTUELLE(ip), 20000));
    totaux.nmapActuel += a.ms;
    if (a.valeur?.tue) nmapTue++;
    console.log(
      `    nmap actuel           ${String(a.ms).padStart(6)} ms   ` +
        `${a.valeur?.os ? V + a.valeur.os : (a.valeur?.tue ? R + "TUÉ par le délai, rien obtenu" : G + "aucun résultat")}${F}`
    );

    const b = await chrono(lancerNmap(REGLEE(ip), 20000));
    totaux.nmapRegle += b.ms;
    console.log(
      `    nmap réglé            ${String(b.ms).padStart(6)} ms   ` +
        `${b.valeur?.os ? V + b.valeur.os : G + "aucun résultat"}${F}`
    );

    // Le point qui déciderait de NE PAS appliquer le réglage : gagner du
    // temps en perdant la détection.
    if (a.valeur?.os && !b.valeur?.os) {
      perteDetection++;
      console.log(`    ${R}→ la version réglée a PERDU la détection sur cette machine${F}`);
    }

    const q = await chrono(scanPorts(ip));
    totaux.ports += q.ms;
    console.log(
      `    scan de ports         ${String(q.ms).padStart(6)} ms   ${G}${(q.valeur || []).length} port(s) ouvert(s)${F}\n`
    );
  }

  /* ── Synthèse ────────────────────────────────────────────────────── */
  const n = cibles.length;
  const moy = (t) => Math.round(t / n);

  console.log("───────────────────────────────────────────────────────");
  console.log(`  ${G}Moyenne par machine${F}`);
  console.log(`    ping                  ${String(moy(totaux.ping)).padStart(6)} ms`);
  console.log(`    SNMP                  ${String(moy(totaux.snmp)).padStart(6)} ms`);
  console.log(`    scan de ports         ${String(moy(totaux.ports)).padStart(6)} ms`);
  console.log(`    ${J}nmap actuel           ${String(moy(totaux.nmapActuel)).padStart(6)} ms${F}`);
  console.log(`    ${V}nmap réglé            ${String(moy(totaux.nmapRegle)).padStart(6)} ms${F}`);

  const gain = totaux.nmapActuel - totaux.nmapRegle;
  const pourcent = totaux.nmapActuel > 0 ? Math.round((gain / totaux.nmapActuel) * 100) : 0;

  console.log("\n───────────────────────────────────────────────────────");
  if (nmapTue > 0) {
    console.log(
      `  ${R}${nmapTue} machine(s) sur ${n} : nmap a été TUÉ par le délai de 15 s.${F}`
    );
    console.log("  On paie l'attente complète et on n'obtient rien. C'est le");
    console.log("  pire des cas, et il est évitable avec --host-timeout.");
  }

  if (perteDetection > 0) {
    console.log(
      `\n  ${R}ATTENTION : la version réglée perd la détection sur ` +
        `${perteDetection} machine(s).${F}`
    );
    console.log("  Gagner du temps en perdant de la justesse n'est pas un gain.");
    console.log("  Il faudrait alors retirer les options une à une pour trouver");
    console.log("  laquelle dégrade le résultat.");
  } else if (gain > 0) {
    console.log(
      `\n  ${V}La version réglée est ${pourcent} % plus rapide, sans rien perdre.${F}`
    );
    console.log(
      `  Sur un parc de 35 machines dont ~29 muettes en SNMP, l'économie`
    );
    console.log(
      `  approche ${Math.round((gain / n) * 29 / 1000)} secondes par scan, ` +
        `divisée par la concurrence (5 par défaut).`
    );
  } else {
    console.log(`\n  ${J}Aucun gain mesurable.${F} Le temps ne vient pas de là :`);
    console.log("  regardez la colonne SNMP et le nombre de machines muettes.");
  }
  console.log("───────────────────────────────────────────────────────\n");

  await db.end().catch(() => {});
})().catch(async (err) => {
  console.error(`\n${R}Erreur :${F} ${err.message}\n`);
  await db.end().catch(() => {});
  process.exitCode = 1;
});
