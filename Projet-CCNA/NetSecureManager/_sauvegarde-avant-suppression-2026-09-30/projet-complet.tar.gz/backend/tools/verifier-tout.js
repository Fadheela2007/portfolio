/**
 * tools/verifier-tout.js
 * Contrôle général de la plateforme, en une commande.
 *
 *   node tools\verifier-tout.js
 *
 * ─────────────────────────────────────────────────────────────────────
 * CE QU'IL VÉRIFIE, ET CE QU'IL NE PEUT PAS VÉRIFIER
 *
 * Il contrôle tout ce qui se lit depuis cette machine : configuration,
 * base de données, structure, cohérence des données, tests unitaires.
 *
 * Il ne remplace PAS le protocole de test manuel (TESTER-LA-PLATEFORME.md).
 * Aucun programme ne peut vérifier qu'un scan trouve les bonnes machines,
 * qu'une alerte part par e-mail, ou qu'un blocage DNS fonctionne : ces
 * choses-là dépendent du réseau, pas du code.
 *
 * Son rôle est d'éliminer en trente secondes tout ce qui n'a PAS besoin
 * d'être testé à la main — pour que le temps passé sur le protocole
 * manuel soit consacré aux vraies questions.
 * ─────────────────────────────────────────────────────────────────────
 */

require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const db = require("../src/db");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

const resultats = [];
function noter(categorie, libelle, etat, detail) {
  resultats.push({ categorie, libelle, etat, detail });
  const marque = { ok: `${V}✓${F}`, alerte: `${J}!${F}`, ko: `${R}✗${F}`, info: `${G}·${F}` }[etat];
  console.log(`  ${marque} ${libelle}`);
  if (detail) console.log(`      ${G}${detail}${F}`);
}

function titre(t) {
  console.log(`\n\x1b[1m${t}\x1b[0m`);
}

(async () => {
  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  CONTRÔLE GÉNÉRAL DE LA PLATEFORME");
  console.log("═══════════════════════════════════════════════════════");

  // ── 1. CONFIGURATION ───────────────────────────────────────────────
  titre("1. Configuration");

  const manquantes = db.configurationManquante();
  noter("config", "Variables de base de données", manquantes.length === 0 ? "ok" : "ko",
    manquantes.length ? `absentes : ${manquantes.join(", ")}` : null);

  noter("config", "JWT_SECRET défini", process.env.JWT_SECRET ? "ok" : "ko",
    process.env.JWT_SECRET ? null : "sans lui, le serveur refuse de démarrer");

  const smtp = ["SMTP_HOST", "SMTP_USER"].filter((c) => !process.env[c]);
  noter("config", "Envoi d'e-mails configuré", smtp.length === 0 ? "ok" : "alerte",
    smtp.length ? `${smtp.join(", ")} absent — les notifications ne partiront pas` : null);

  // ── 2. BASE DE DONNÉES ─────────────────────────────────────────────
  titre("2. Base de données");

  const [[ctx]] = await db.query("SELECT DATABASE() AS base, VERSION() AS version");
  noter("base", `Connexion à « ${ctx.base} »`, "ok", `MySQL ${ctx.version}`);

  const [tables] = await db.query(
    `SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()`
  );
  const attendues = [
    "SITE", "EQUIPEMENT", "TYPE_EQUIPEMENT", "UTILISATEUR", "ALERTE", "INCIDENT",
    "RELEVE", "INTERFACE_RESEAU", "SERVICE_DETECTE", "CONFIGURATION", "LOG_ACTIVITE",
    "NOTIFICATION", "PLAGE_SCAN", "VULNERABILITE_CONNUE", "OUI_FABRICANT",
    "CATEGORIE_WEB", "DOMAINE_CATEGORIE", "POLITIQUE_WEB", "POLITIQUE_CATEGORIE",
    "POLITIQUE_DOMAINE", "STAT_BLOCAGE",
  ];
  const presentes = new Set(tables.map((t) => t.TABLE_NAME.toUpperCase()));
  const absentes = attendues.filter((t) => !presentes.has(t));
  noter("base", `Tables (${presentes.size} présentes)`, absentes.length === 0 ? "ok" : "ko",
    absentes.length ? `manquantes : ${absentes.join(", ")}` : null);

  // Colonnes critiques — celles dont l'absence casse une fonction entière.
  const critiques = [
    ["SITE", "dernier_push", "LA SUPERVISION ENTIÈRE"],
    ["CONFIGURATION", "description", "l'écran Configuration"],
    ["ALERTE", "occurrences", "le dédoublonnage des alertes"],
    ["INTERFACE_RESEAU", "trafic_entrant_kbps", "la page Bande passante"],
    ["EQUIPEMENT", "type_source", "la traçabilité du typage"],
    ["NOTIFICATION", "destinataire", "l'historique des notifications"],
  ];
  const colonnesKo = [];
  for (const [table, colonne, casse] of critiques) {
    const [r] = await db.query(
      `SELECT COUNT(*) AS n FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
      [table, colonne]
    );
    if (Number(r[0].n) === 0) colonnesKo.push(`${table}.${colonne} (casse ${casse})`);
  }
  noter("base", "Colonnes critiques", colonnesKo.length === 0 ? "ok" : "ko",
    colonnesKo.length ? colonnesKo.join(" · ") : null);

  // ── 3. COHÉRENCE DES DONNÉES ───────────────────────────────────────
  titre("3. Cohérence des données");

  const [[{ nbTypes }]] = await db.query("SELECT COUNT(*) AS nbTypes FROM TYPE_EQUIPEMENT");
  noter("donnees", `Référentiel des types (${nbTypes})`, nbTypes >= 9 ? "ok" : "ko",
    nbTypes >= 9 ? null : "sans lui, tout équipement retombe sur « inconnu »");

  const [[{ nbAdmins }]] = await db.query(
    "SELECT COUNT(*) AS nbAdmins FROM UTILISATEUR WHERE role = 'admin'"
  );
  noter("donnees", `Comptes administrateurs (${nbAdmins})`, nbAdmins > 0 ? "ok" : "ko",
    nbAdmins > 0 ? null : "personne ne peut se connecter — node tools\\creer-admin.js");

  const [[{ nbEq }]] = await db.query("SELECT COUNT(*) AS nbEq FROM EQUIPEMENT");
  const [[{ nbSitesLocaux }]] = await db.query(
    "SELECT COUNT(*) AS nbSitesLocaux FROM SITE WHERE dernier_push IS NULL"
  );

  noter("donnees", `Parc (${nbEq} équipements)`, nbEq > 0 ? "ok" : "alerte",
    nbEq > 0 ? null : "aucun équipement — lancez un scan");

  // LE PIÈGE QUI A COÛTÉ UNE JOURNÉE : tous les sites marqués « agent »,
  // donc aucun supervisé par le cycle central, en silence.
  noter("donnees", "Sites supervisés par le cycle central", nbSitesLocaux > 0 ? "ok" : "ko",
    nbSitesLocaux > 0
      ? `${nbSitesLocaux} site(s) local(aux)`
      : "TOUS les sites sont marqués « pris en charge par un agent » : le cycle central ne supervise rien");

  const [[{ nbRecents }]] = await db.query(
    "SELECT COUNT(*) AS nbRecents FROM RELEVE WHERE date_releve >= NOW() - INTERVAL 15 MINUTE"
  );
  noter("donnees", `Relevés des 15 dernières minutes (${nbRecents})`,
    nbRecents > 0 ? "ok" : nbEq === 0 ? "info" : "alerte",
    nbRecents > 0 ? null : "le backend tourne-t-il ? la supervision produit un relevé par minute");

  const [[{ nbOui }]] = await db.query("SELECT COUNT(*) AS nbOui FROM OUI_FABRICANT");
  noter("donnees", `Registre des fabricants (${nbOui} préfixes)`,
    nbOui > 1000 ? "ok" : "alerte",
    nbOui > 1000 ? null : "peu de fabricants seront identifiés — node tools\\importer-oui.js");

  // ── 4. FICHIERS ────────────────────────────────────────────────────
  titre("4. Fichiers du projet");

  const racine = path.join(__dirname, "..");
  const essentiels = ["schema.sql", "src/server.js", "package.json"];
  const fichiersKo = essentiels.filter((f) => !fs.existsSync(path.join(racine, f)));
  noter("fichiers", "Fichiers essentiels", fichiersKo.length === 0 ? "ok" : "ko",
    fichiersKo.join(", ") || null);

  const nbMigrations = fs.existsSync(path.join(racine, "migrations"))
    ? fs.readdirSync(path.join(racine, "migrations")).filter((f) => f.endsWith(".sql")).length
    : 0;
  noter("fichiers", `Migrations disponibles (${nbMigrations})`, nbMigrations > 0 ? "ok" : "alerte");

  // ── 5. TESTS AUTOMATIQUES ──────────────────────────────────────────
  titre("5. Tests automatiques");

  // Fichiers énumérés explicitement (pas de glob "*.test.js" laissé à la
  // charge du shell) : sous PowerShell/cmd.exe, un programme externe reçoit
  // l'astérisk tel quel — c'est Node qui doit l'interpréter, et selon la
  // version installée ce n'est pas garanti. Le reporter est fixé à "tap"
  // explicitement, pour ne pas dépendre du choix par défaut (qui varie
  // selon que la sortie est un terminal ou non).
  const dossierTests = path.join(racine, "tests");
  const fichiersTest = fs.existsSync(dossierTests)
    ? fs.readdirSync(dossierTests).filter((f) => f.endsWith(".test.js"))
    : [];

  if (fichiersTest.length === 0) {
    noter("tests", "Tests unitaires", "ko", "aucun fichier tests/*.test.js trouvé");
  } else {
    try {
      const sortie = execSync(
        `node --test --test-reporter=tap --test-reporter-destination=stdout ${fichiersTest
          .map((f) => `"tests/${f}"`)
          .join(" ")}`,
        { cwd: racine, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: 180000 }
      );
      const pass = (sortie.match(/^# pass (\d+)/m) || [])[1];
      const fail = (sortie.match(/^# fail (\d+)/m) || [])[1];
      if (pass === undefined || fail === undefined) {
        noter("tests", "Tests unitaires — sortie inattendue", "alerte",
          "le résumé TAP n'a pas été reconnu ; lancez « npm test » pour lire le détail");
      } else {
        noter("tests", `Tests unitaires (${pass} réussis, ${fail} échoués)`,
          Number(fail) === 0 ? "ok" : "ko");
      }
    } catch (err) {
      const sortie = (err.stdout || "") + (err.stderr || "");
      const fail = (sortie.match(/^# fail (\d+)/m) || [])[1] || "?";
      noter("tests", `Tests unitaires — ${fail} échec(s)`, "ko", "lancez : npm test");
    }
  }

  // ── 6. CORRECTIONS DU 07-08/09 ─────────────────────────────────────
  //
  // Contrôle que les corrections de l'audit sont RÉELLEMENT en place, et
  // pas seulement écrites dans le code. Chacune a été un défaut constaté :
  // la vérifier une fois ne suffit pas, il faut pouvoir la revérifier en
  // une commande après chaque déploiement.
  titre("6. Corrections de l'audit");

  // 6.1 — Le mode de supervision est-il explicite ?
  try {
    const [[c]] = await db.query(
      `SELECT COUNT(*) AS n FROM information_schema.COLUMNS
       WHERE table_schema = DATABASE() AND table_name = 'SITE'
         AND column_name = 'supervision_par_agent'`
    );
    if (Number(c.n) === 0) {
      noter("audit", "Mode de supervision explicite", "ko",
        "migration 2026-09-08 non appliquée — un agent d'essai peut encore couper la supervision d'un site");
    } else {
      /* ON COMPTE LES ÉQUIPEMENTS, PAS LES SITES.

         La version précédente comparait le nombre de sites « agent
         local » au nombre total de sites, et se déclarait satisfaite dès
         qu'un seul site restait au central. Elle a donné un ✓ sur une
         installation où le site central était VIDE et où les 111
         équipements réels vivaient sur un site déclaré agent local, sans
         agent. Un contrôle qui valide l'état qu'il est censé détecter est
         pire que pas de contrôle.

         Ce qui compte n'est pas « reste-t-il un site au central », c'est
         « combien de machines sont réellement regardées par quelqu'un ». */
      const [[s2]] = await db.query(
        `SELECT COUNT(*) AS total,
                SUM(supervision_par_agent = TRUE) AS par_agent
         FROM SITE`
      );
      const [[eq]] = await db.query(
        `SELECT
           (SELECT COUNT(*) FROM EQUIPEMENT) AS total,
           (SELECT COUNT(*) FROM EQUIPEMENT e
              JOIN SITE s ON s.id_site = e.id_site
            WHERE s.supervision_par_agent = FALSE) AS au_central,
           (SELECT COUNT(*) FROM EQUIPEMENT e
              JOIN SITE s ON s.id_site = e.id_site
            WHERE s.supervision_par_agent = TRUE AND s.dernier_push IS NULL) AS orphelins`
      );
      const total = Number(s2.total || 0);
      const parAgent = Number(s2.par_agent || 0);
      const auCentral = Number(eq.au_central || 0);
      const orphelins = Number(eq.orphelins || 0);
      const totalEq = Number(eq.total || 0);

      if (orphelins > 0) {
        // Ni agent, ni central : le trou le plus silencieux du produit.
        noter("audit", "Équipements supervisés par personne", "ko",
          `${orphelins} équipement(s) sont sur un site déclaré « agent local » dont aucun agent n'a jamais transmis — ` +
          `installez l'agent, ou décochez le mode agent sur la page Sites`);
      } else if (totalEq > 0 && auCentral === 0 && parAgent === total) {
        noter("audit", "Supervision centrale", "ko",
          `les ${total} site(s) sont déclarés « agent local » : le cycle central ne supervise plus rien`);
      } else {
        noter("audit",
          `Supervision centrale (${auCentral}/${totalEq} équipement(s), ${total - parAgent}/${total} site(s))`,
          "ok");
      }
    }
  } catch (err) {
    noter("audit", "Mode de supervision", "alerte", err.message);
  }

  // 6.2 — Les services exposés à risque sont-ils peuplés ?
  try {
    const [[v]] = await db.query("SELECT COUNT(*) AS n FROM VULNERABILITE_CONNUE");
    noter("audit", `Services exposés à risque (${v.n} référence(s))`,
      Number(v.n) > 0 ? "ok" : "ko",
      Number(v.n) > 0 ? null : "table vide — l'écran ne peut rien afficher, appliquez la migration 2026-09-07");
  } catch {
    noter("audit", "Services exposés à risque", "ko", "table VULNERABILITE_CONNUE absente");
  }

  // 6.3 — Le temps réel est-il activé ?
  noter("audit", "Temps réel (WEBSOCKET_ORIGINE)",
    process.env.WEBSOCKET_ORIGINE ? "ok" : "alerte",
    process.env.WEBSOCKET_ORIGINE
      ? null
      : "absent du .env — l'interface ne se rafraîchira pas d'elle-même");

  // 6.4 — La supervision produit-elle réellement des relevés ?
  //
  // C'est le contrôle le plus utile du lot : tout le reste peut être
  // correct et la plateforme ne rien mesurer. Aucun relevé récent = pas
  // de graphique, pas d'alerte possible, rien.
  try {
    const [[r]] = await db.query(
      "SELECT MAX(date_releve) AS dernier FROM RELEVE"
    );
    if (!r.dernier) {
      noter("audit", "Relevés de supervision", "ko", "aucun relevé n'a jamais été enregistré");
    } else {
      const minutes = Math.round((Date.now() - new Date(r.dernier).getTime()) / 60000);
      noter("audit", `Relevés de supervision (dernier il y a ${minutes} min)`,
        minutes < 10 ? "ok" : "ko",
        minutes < 10 ? null : "le cycle ne tourne pas : aucun graphique ne s'affichera");
    }
  } catch (err) {
    noter("audit", "Relevés de supervision", "alerte", err.message);
  }

  // 6.5 — Des équipements sont-ils déclarés en panne alors qu'ils
  // répondent sur un port TCP ? C'était la cause des fausses alertes.
  try {
    const [[d]] = await db.query(
      "SELECT COUNT(*) AS n FROM EQUIPEMENT WHERE statut = 'down'"
    );
    noter("audit", `Équipements hors ligne (${d.n})`,
      "ok",
      Number(d.n) > 0
        ? "à recouper : depuis la correction, un équipement qui répond sur un port TCP n'est plus déclaré en panne"
        : null);
  } catch (err) {
    noter("audit", "Équipements hors ligne", "alerte", err.message);
  }

  /* ═══════════════════════════════════════════════════════════════════
     7. CORRECTIONS DU 8 SEPTEMBRE 2026

     Ces contrôles ne demandent ni base ni serveur démarré : ils lisent le
     code et exécutent une fonction pure. Ils répondent à une question
     précise — « les correctifs de l'audit sont-ils toujours en place ? » —
     parce qu'un correctif se perd à la première fusion de branche mal
     résolue, et que rien à l'écran ne le signale.
     ═══════════════════════════════════════════════════════════════════ */
  titre("7. Corrections du 8 septembre");

  const racineSrc = path.join(__dirname, "..", "src");

  /**
   * Retire commentaires et chaînes littérales avant toute recherche.
   *
   * SANS CELA, CES CONTRÔLES MENTENT. Les correctifs de l'audit sont
   * commentés en citant le code fautif d'origine — « express.json() sans
   * argument plafonne à 100 ko », « portait process.env.JWT_SECRET || ... ».
   * Une recherche naïve retrouve ces citations et déclare la faille
   * présente alors qu'elle est corrigée, ou l'inverse le jour où le
   * commentaire disparaît. Un contrôle qui se trompe est pire que pas de
   * contrôle : on cesse de le lire.
   */
  const sansCommentaires = (src) =>
    src
      .replace(/\/\*[\s\S]*?\*\//g, " ")
      .replace(/(^|[^:])\/\/.*$/gm, "$1")
      .replace(/"(?:[^"\\\n]|\\.)*"/g, '""')
      .replace(/'(?:[^'\\\n]|\\.)*'/g, "''");

  const lire = (relatif) => {
    try {
      return sansCommentaires(fs.readFileSync(path.join(racineSrc, relatif), "utf8"));
    } catch {
      return null;
    }
  };

  // 7.1 — Une plage trop large ne peut plus faire tomber le serveur.
  //
  // Contrôle par EXÉCUTION et non par lecture du code : c'est le
  // comportement qui compte, pas la présence d'une constante. La fonction
  // est pure — ni base, ni réseau.
  try {
    const { listHostsFromCidr } = require("../src/services/discoveryService");

    let refuseTropLarge = false;
    try {
      listHostsFromCidr("10.0.0.0/8");
    } catch (e) {
      refuseTropLarge = /trop large/.test(e.message);
    }

    let refuseInvalide = false;
    try {
      listHostsFromCidr("pas-un-cidr");
    } catch (e) {
      refuseInvalide = /illisible/.test(e.message);
    }

    const normal = listHostsFromCidr("192.168.1.0/24").length;

    if (!refuseTropLarge) {
      noter("corrections", "Plafond de taille de plage", "ko",
        "10.0.0.0/8 est accepté : une faute de frappe dans un masque fait tomber toute la supervision");
    } else if (!refuseInvalide) {
      noter("corrections", "Validation du format de plage", "ko",
        "une plage illisible n'est pas refusée proprement");
    } else if (normal !== 254) {
      noter("corrections", "Balayage d'un /24", "ko",
        `192.168.1.0/24 rend ${normal} hôtes au lieu de 254 : le plafond a cassé le cas normal`);
    } else {
      noter("corrections", "Plafond de taille de plage (/8 refusé, /24 intact)", "ok");
    }
  } catch (err) {
    noter("corrections", "Plafond de taille de plage", "alerte", err.message);
  }

  // 7.2 — Aucun secret de repli en dur dans le contrôle des jetons.
  {
    const src = lire("middleware/authMiddleware.js");
    if (src === null) {
      noter("corrections", "Secret JWT", "ko", "middleware/authMiddleware.js introuvable");
    } else if (/JWT_SECRET\s*\|\|/.test(src)) {
      noter("corrections", "Secret JWT sans repli en dur", "ko",
        "un secret de repli est réapparu : sans JWT_SECRET, n'importe qui fabrique un jeton d'administrateur");
    } else {
      noter("corrections", "Secret JWT sans repli en dur", "ok");
    }
  }

  // 7.3 — Le corps des requêtes d'agent n'est plus plafonné à 100 ko.
  {
    const src = lire("server.js");
    if (src === null) {
      noter("corrections", "Taille du corps des requêtes", "ko", "src/server.js introuvable");
    } else if (/express\.json\(\s*\)/.test(src)) {
      noter("corrections", "Taille du corps des requêtes", "ko",
        "express.json() sans limite retombe à 100 ko : les sites de plusieurs centaines de machines cesseront de remonter, sans message");
    } else if (/express\.json\(\s*\{[^}]*limit/.test(src)) {
      noter("corrections", "Taille du corps des requêtes (limite explicite)", "ok");
    } else {
      noter("corrections", "Taille du corps des requêtes", "alerte",
        "limite non reconnue — vérifiez src/server.js à la main");
    }
  }

  // 7.4 — Le courrier d'alerte ne peut plus partir en clair.
  {
    const src = lire("services/notificationService.js");
    if (src && /requireTLS:\s*true/.test(src)) {
      noter("corrections", "SMTP : TLS exigé", "ok");
    } else {
      noter("corrections", "SMTP : TLS exigé", "ko",
        "sans requireTLS, identifiants SMTP et alertes peuvent traverser le réseau en clair si le serveur n'annonce pas STARTTLS");
    }
  }

  // 7.5 — Le journal trace-t-il encore les actions sensibles ?
  //
  // On vérifie le CÂBLAGE, pas la présence du module : un journal
  // présent mais appelé nulle part est exactement l'état d'avant.
  {
    const attendus = {
      "routes/utilisateurs.js": "comptes",
      "routes/sites.js": "sites et jetons d'agent",
      "routes/plages.js": "plages de scan",
      "routes/configuration.js": "réglages",
      "routes/accesWeb.js": "politiques de blocage web",
    };
    const manquants = Object.entries(attendus)
      .filter(([fichier]) => {
        const src = lire(fichier);
        // `require("")` après effacement des chaînes : on vérifie la
        // présence de l'import ET d'au moins un appel réel.
        return !src || !/\{\s*tracer\s*\}\s*=\s*require\(/.test(src) || !/await tracer\(/.test(src);
      })
      .map(([, sujet]) => sujet);

    if (!fs.existsSync(path.join(racineSrc, "services", "journal.js"))) {
      noter("corrections", "Journal d'activité", "ko", "services/journal.js absent");
    } else if (manquants.length > 0) {
      noter("corrections", "Journal d'activité", "ko",
        `plus tracé : ${manquants.join(", ")} — l'écran Journal ne montrera pas ces actions`);
    } else {
      noter("corrections", "Journal d'activité (5 domaines tracés)", "ok");
    }
  }

  // 7.6 — Le cloisonnement du blocage web tient-il toujours ?
  {
    const src = lire("routes/accesWeb.js");
    // `await politiqueDansPortee(` et non `politiqueDansPortee(` : la
    // déclaration de la fonction contient elle aussi son propre nom suivi
    // de `(req`. La compter donnait 3 au lieu de 2 et rendait le seuil
    // toujours vrai — un contrôle qui ne peut pas échouer ne contrôle rien.
    const appels = src ? (src.match(/await politiqueDansPortee\(req/g) || []).length : 0;
    if (!src || !/async function politiqueDansPortee/.test(src)) {
      noter("corrections", "Cloisonnement du blocage web", "ko",
        "le contrôle de portée a disparu : un administrateur de site peut de nouveau modifier la politique d'un autre site");
    } else if (appels < 2) {
      noter("corrections", "Cloisonnement du blocage web", "ko",
        `le contrôle existe mais n'est appelé que ${appels} fois sur 2 (ajout et retrait de domaine)`);
    } else {
      noter("corrections", "Cloisonnement du blocage web", "ok",
        "vérification réelle : node tools\\verifier-cloisonnement-ecriture.js <admin-de-site>");
    }
  }

  // 7.7 — Cohérence de la licence, que tout acheteur regardera.
  {
    try {
      const pkg = JSON.parse(
        fs.readFileSync(path.join(__dirname, "..", "package.json"), "utf8")
      );
      if (pkg.license && pkg.license !== "UNLICENSED") {
        noter("corrections", "Licence déclarée", "ko",
          `backend/package.json déclare « ${pkg.license} » alors que LICENSE dit « tous droits réservés » — contradiction qu'un juriste d'acheteur relèvera`);
      } else {
        noter("corrections", "Licence déclarée", "ok");
      }
    } catch (err) {
      noter("corrections", "Licence déclarée", "alerte", err.message);
    }
  }

  // 7.8 — L'adresse de l'API est-elle documentée pour la compilation
  // du frontend ? Son absence produit une interface qui se charge et
  // ne montre rien, sans erreur lisible.
  {
    const exemple = path.join(__dirname, "..", "..", "frontend", ".env.example");
    noter("corrections", "frontend/.env.example (VITE_API_URL)",
      fs.existsSync(exemple) ? "ok" : "ko",
      fs.existsSync(exemple)
        ? null
        : "sans ce modèle, une interface compilée appellera http://localhost:5000 depuis le poste de chaque utilisateur");
  }

  // 7.9 — Le total de bande passante est-il un TOTAL ?
  //
  // Le défaut d'origine tenait en trois lettres : `AVG` là où il fallait
  // sommer. L'écran annonçait la consommation de la machine moyenne en
  // l'appelant « total » — soit, sur vingt machines mesurées, un
  // vingtième du débit réel. Rien ne signalait l'anomalie : le chiffre
  // était petit et plausible.
  //
  // On contrôle la FORME de la requête, faute de pouvoir la faire tourner
  // sans données : la somme des moyennes par équipement suppose un
  // sous-select groupé par id_equipement.
  {
    const src = lire("routes/scan.js");
    const aSousRequete =
      src && /SUM\(x\.moy_e\)/.test(src) && /GROUP BY r\.id_equipement/.test(src);
    if (!aSousRequete) {
      noter("corrections", "Total de bande passante", "ko",
        "le total est redevenu une moyenne globale : l'écran affichera la consommation d'UNE machine en l'appelant « total du parc »");
    } else {
      noter("corrections", "Total de bande passante (somme des moyennes par équipement)", "ok");
    }
  }

  // 7.10 — Le pic global est-il un pic SIMULTANÉ ?
  //
  // Additionner les pics individuels donne un maximum que le parc n'a
  // jamais atteint : deux machines qui saturent le lien à des heures
  // différentes ne l'ont jamais saturé ensemble. Le regroupement par
  // minute est ce qui rend le chiffre vrai.
  {
    const src = lire("routes/scan.js");
    if (src && /GROUP BY minute/.test(src) && /MAX\(y\.somme_e\)/.test(src)) {
      noter("corrections", "Pic de bande passante (simultané, par minute)", "ok");
    } else {
      noter("corrections", "Pic de bande passante", "ko",
        "le pic n'est plus calculé par minute : il annoncera un débit qui n'a jamais eu lieu");
    }
  }

  // 7.11 — La durée d'un scan.
  //
  // nmap représente 93 % du temps et ce nombre dit combien de machines
  // sont analysées à la fois. À 5, un parc de 44 machines demandait trois
  // minutes ; à 10, une minute quarante. Ce n'est pas un réglage de
  // confort : c'est ce que l'acheteur chronomètre pendant la démonstration.
  {
    const src = lire("services/discoveryService.js");
    const m = src && src.match(/Math\.min\((\d+),\s*Number\(process\.env\.SCAN_CONCURRENCE\)\)\s*:\s*(\d+)/);
    if (!m) {
      noter("corrections", "Concurrence du scan", "alerte",
        "réglage non reconnu — vérifiez CONCURRENCE_IDENTIFICATION à la main");
    } else {
      const plafond = Number(m[1]);
      const defaut = Number(m[2]);
      const effectif = Number(process.env.SCAN_CONCURRENCE) > 0
        ? Math.min(plafond, Number(process.env.SCAN_CONCURRENCE))
        : defaut;
      // Une valeur basse n'est pas forcément un oubli : scanner
      // discrètement le réseau d'un tiers est un choix légitime. Le
      // contrôle informe du coût, il ne réclame pas une correction.
      const regleDansEnv = Number(process.env.SCAN_CONCURRENCE) > 0;
      noter("corrections", `Concurrence du scan (${effectif} machines à la fois)`,
        effectif >= 10 ? "ok" : "alerte",
        effectif >= 10
          ? null
          : `un parc de 44 machines demandera environ ${Math.round((44 / effectif) * 20 / 60)} min` +
            (regleDansEnv
              ? " — valeur fixée par SCAN_CONCURRENCE dans .env, délibérée si le réseau scanné n'est pas le vôtre"
              : " — la valeur par défaut du code est 10, vérifiez qu'elle n'est pas écrasée"));
    }
  }

  // 7.12 — L'en-tête du tableau Équipements reste-t-il lisible ?
  //
  // Un tableau se rend avec `border-collapse: collapse`. Dans ce mode,
  // Firefox et Chrome antérieur à la v91 NE PEIGNENT PAS le fond déclaré
  // sur <thead>. Combiné à `position: sticky`, les lignes défilent
  // derrière les titres : l'en-tête devient illisible et on croit que les
  // colonnes ont disparu. Le fond doit donc vivre sur les <th>.
  {
    const chemin = path.join(
      __dirname, "..", "..", "frontend", "src", "Components", "EquipementsPage.jsx"
    );
    try {
      const jsx = fs.readFileSync(chemin, "utf8");
      const fondSurThead = /<thead[^>]*className="[^"]*sticky[^"]*bg-\[/.test(jsx);
      const fondSurTh = /<th\b[\s\S]{0,200}?bg-\[var\(--color-surface\)\]/.test(jsx);
      if (fondSurThead) {
        noter("corrections", "En-tête collant du tableau Équipements", "ko",
          "le fond est revenu sur <thead> : sous Firefox il ne sera pas peint et les lignes défileront derrière les titres");
      } else if (!fondSurTh) {
        noter("corrections", "En-tête collant du tableau Équipements", "alerte",
          "aucun fond trouvé sur les <th> — l'en-tête risque d'être transparent au défilement");
      } else {
        noter("corrections", "En-tête collant du tableau Équipements", "ok");
      }
    } catch {
      noter("corrections", "En-tête collant du tableau Équipements", "alerte",
        "EquipementsPage.jsx introuvable depuis le backend");
    }
  }

  // 7.13 — Un réglage inconnu ne peut plus être annoncé comme enregistré.
  //
  // `UPDATE ... WHERE cle = ?` sur une clé inexistante ne touche aucune
  // ligne et ne lève rien : l'interface affichait « Configuration mise à
  // jour » alors que rien n'existait. Une faute de frappe dans un nom de
  // réglage devenait indétectable.
  {
    const src = lire("routes/configuration.js");
    if (src && /affectedRows === 0/.test(src)) {
      noter("corrections", "Réglage inconnu refusé (404)", "ok");
    } else {
      noter("corrections", "Réglage inconnu refusé", "ko",
        "PATCH /api/configuration/:cle annonce un succès même quand la clé n'existe pas");
    }
  }

  // ── BILAN ──────────────────────────────────────────────────────────
  const ko = resultats.filter((r) => r.etat === "ko");
  const alertes = resultats.filter((r) => r.etat === "alerte");

  console.log("\n═══════════════════════════════════════════════════════");
  if (ko.length === 0 && alertes.length === 0) {
    console.log(`  ${V}Tout est conforme.${F}`);
    console.log("\n  Le contrôle automatique ne couvre pas le réseau :");
    console.log("  reprenez TESTER-LA-PLATEFORME.md pour le scan, les");
    console.log("  notifications et le blocage DNS.\n");
    process.exit(0);
  }

  if (ko.length > 0) {
    console.log(`  ${R}${ko.length} problème(s) bloquant(s) :${F}`);
    for (const r of ko) console.log(`    ✗ ${r.libelle}${r.detail ? ` — ${r.detail}` : ""}`);
  }
  if (alertes.length > 0) {
    console.log(`\n  ${J}${alertes.length} point(s) d'attention :${F}`);
    for (const r of alertes) console.log(`    ! ${r.libelle}${r.detail ? ` — ${r.detail}` : ""}`);
  }
  console.log("");
  process.exit(ko.length > 0 ? 1 : 0);
})().catch((err) => {
  console.error(`\n${R}Contrôle interrompu :${F}`, err.message);
  if (/ECONNREFUSED/.test(err.message)) console.error("MySQL ne répond pas.\n");
  process.exit(2);
});
