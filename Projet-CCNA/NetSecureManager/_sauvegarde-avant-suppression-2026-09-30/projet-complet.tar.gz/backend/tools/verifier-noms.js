/**
 * tools/verifier-noms.js
 * Ce que le scan a écrit est-il VRAI ?
 *
 *   node tools\verifier-noms.js
 *   node tools\verifier-noms.js 20        (re-vérifie 20 noms au lieu de 10)
 *
 * ═══════════════════════════════════════════════════════════════════════
 * CE QUE CET OUTIL CHERCHE, ET POURQUOI CHAQUE CONTRÔLE EXISTE
 *
 * `diagnostic-noms.js` demande « les méthodes de nommage répondent-elles
 * sur ce réseau ? ». Celui-ci pose la question d'après : « ce qui est
 * ENREGISTRÉ en base est-il exact ? ».
 *
 * Ce ne sont pas les mêmes. Une méthode peut très bien répondre et
 * répondre FAUX — c'est même le défaut le plus dangereux d'un
 * inventaire, parce qu'il ne se voit pas : une colonne remplie inspire
 * confiance, qu'elle soit juste ou non.
 *
 * Les six contrôles :
 *
 *   1. RÉPARTITION PAR SOURCE — d'où vient chaque nom. Une source qui
 *      domine à 100 % est suspecte : sur un vrai parc, elles se
 *      partagent le travail.
 *
 *   2. DOUBLONS — deux machines qui portent le même nom. C'est LE signal
 *      d'un nom faux : un résolveur qui répond la même chose à toutes
 *      les adresses (certaines box renvoient leur propre nom pour tout
 *      le sous-réseau) remplit la colonne d'un mensonge uniforme.
 *
 *   3. NOMS SUSPECTS — le nom vaut l'adresse IP, « localhost »,
 *      « unknown », un nom d'une seule lettre. Aucun de ces cas n'est
 *      un nom de machine.
 *
 *   4. PREUVE D'EXISTENCE — combien d'équipements figurent à
 *      l'inventaire SANS qu'aucune preuve n'ait été enregistrée. Ce sont
 *      les fantômes : des adresses vues dans un cache ARP, jamais
 *      confirmées.
 *
 *   5. ADRESSES MAC ALÉATOIRES — un téléphone qui change de MAC à chaque
 *      connexion crée une nouvelle ligne à chaque fois. Ce n'est pas un
 *      faux, mais ça gonfle l'inventaire et il faut le savoir.
 *
 *   6. RE-VÉRIFICATION EN DIRECT — on reprend un échantillon de noms
 *      enregistrés et on redemande à la machine, MAINTENANT, comment
 *      elle s'appelle. Si elle répond la même chose, le nom est vrai
 *      aujourd'hui, pas seulement le jour du scan. C'est le seul
 *      contrôle qui prouve quelque chose plutôt que de le déduire.
 *
 * L'outil ne modifie RIEN. Il lit, il interroge, il compte.
 */
require("dotenv").config({
  path: require("path").join(__dirname, "..", ".env"),
  quiet: true,
});
const db = require("../src/db");
const { resoudreNom } = require("../src/services/nomService");
const { snmpProbe } = require("../src/services/discoveryService");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

function titre(texte) {
  console.log(`\n${"─".repeat(63)}`);
  console.log(`  ${texte}`);
  console.log(`${"─".repeat(63)}\n`);
}

function absente(err) {
  return /Unknown column|doesn't exist|ER_BAD_FIELD_ERROR|ER_NO_SUCH_TABLE/i.test(
    err.message
  );
}

/** Exécute une requête, ou rend null si le schéma ne la permet pas. */
async function lire(sql, params = []) {
  try {
    const [lignes] = await db.query(sql, params);
    return lignes;
  } catch (err) {
    if (absente(err)) return null;
    throw err;
  }
}

(async () => {
  const echantillon = Math.min(50, Math.max(1, Number(process.argv[2]) || 10));

  console.log("\n═══════════════════════════════════════════════════════════════");
  console.log("  LES NOMS DU PARC SONT-ILS VRAIS ?");
  console.log("═══════════════════════════════════════════════════════════════");

  const [[parc]] = await db.query("SELECT COUNT(*) AS n FROM EQUIPEMENT");
  const total = Number(parc.n);
  console.log(`\n  Parc : ${total} équipement(s)`);

  /* ── 1. Répartition par source ── */
  titre("1. D'OÙ VIENNENT LES NOMS");

  const sources = await lire(
    `SELECT COALESCE(nom_source, 'aucun') AS source, COUNT(*) AS n
       FROM EQUIPEMENT
      GROUP BY COALESCE(nom_source, 'aucun')
      ORDER BY n DESC`
  );

  const LIBELLES = {
    snmp: "SNMP — le nom que la machine se donne",
    dns: "DNS inverse — posé par l'administrateur du réseau",
    netbios: "NetBIOS — annoncé par le poste Windows lui-même",
    mdns: "mDNS — annoncé par l'appareil (Apple, Android, imprimantes)",
    aucun: "aucune source n'a répondu — la colonne reste vide",
  };

  if (!sources) {
    console.log(`  ${G}Colonne nom_source absente : contrôle impossible.${F}`);
  } else {
    for (const s of sources) {
      const part = Math.round((Number(s.n) / total) * 100);
      const couleur = s.source === "aucun" ? G : V;
      console.log(
        `  ${couleur}${String(s.n).padStart(4)}  ${String(part).padStart(3)} %  ` +
          `${(LIBELLES[s.source] || s.source).padEnd(52)}${F}`
      );
    }
  }

  /* ── 2. Doublons ── */
  titre("2. DEUX MACHINES, LE MÊME NOM");

  const doublons = await lire(
    `SELECT nom, COUNT(*) AS n, GROUP_CONCAT(adresse_ip ORDER BY adresse_ip SEPARATOR ', ') AS adresses
       FROM EQUIPEMENT
      WHERE nom IS NOT NULL AND nom <> ''
      GROUP BY nom
     HAVING COUNT(*) > 1
      ORDER BY n DESC
      LIMIT 15`
  );

  let suspectDoublon = false;
  if (!doublons || doublons.length === 0) {
    console.log(`  ${V}Aucun doublon. Chaque nom désigne une seule machine.${F}`);
  } else {
    suspectDoublon = true;
    console.log(
      `  ${R}${doublons.length} nom(s) porté(s) par plusieurs machines :${F}\n`
    );
    for (const d of doublons) {
      console.log(`  ${R}${String(d.n).padStart(3)}×${F}  ${d.nom}`);
      console.log(`       ${G}${String(d.adresses).slice(0, 110)}${F}`);
    }
    console.log(
      `\n  ${J}Un même nom sur plusieurs adresses vient presque toujours d'un\n` +
        "  résolveur qui répond la même chose à tout le sous-réseau. Ces noms\n" +
        `  sont à considérer comme faux tant qu'ils ne sont pas confirmés.${F}`
    );
  }

  /* ── 3. Noms suspects ── */
  titre("3. NOMS QUI N'EN SONT PAS");

  const suspects = await lire(
    `SELECT adresse_ip, nom, nom_source
       FROM EQUIPEMENT
      WHERE nom IS NOT NULL AND nom <> ''
        AND ( nom = adresse_ip
           OR LOWER(nom) IN ('localhost', 'unknown', 'unknown-host', 'inconnu', 'null', 'none')
           OR CHAR_LENGTH(nom) < 2
           OR nom REGEXP '^[0-9]+([.-][0-9]+){3}$' )
      LIMIT 20`
  );

  if (!suspects || suspects.length === 0) {
    console.log(`  ${V}Aucun. Aucun nom ne recopie une adresse ni un mot creux.${F}`);
  } else {
    console.log(`  ${R}${suspects.length} nom(s) douteux :${F}\n`);
    for (const s of suspects) {
      console.log(
        `  ${s.adresse_ip.padEnd(16)} ${String(s.nom).padEnd(24)} ${G}${s.nom_source || "?"}${F}`
      );
    }
  }

  /* ── 4. Preuve d'existence ── */
  titre("4. CES MACHINES EXISTENT-ELLES VRAIMENT ?");

  const preuves = await lire(
    `SELECT COALESCE(preuve_existence, 'aucune') AS preuve, COUNT(*) AS n
       FROM EQUIPEMENT
      GROUP BY COALESCE(preuve_existence, 'aucune')
      ORDER BY n DESC`
  );

  const PREUVES = {
    ping: "a répondu au ping",
    port_ouvert: "un port TCP est ouvert",
    snmp: "a répondu en SNMP",
    nmap: "empreinte nmap",
    refus_tcp: "a refusé une connexion — donc une pile réseau répond",
    voisinage_arp: "a répondu en ARP sur le réseau local",
    pare_feu_probable: "un port TCP est ouvert (vu par la supervision)",
    aucune: "AUCUNE preuve enregistrée",
  };

  if (!preuves) {
    console.log(`  ${G}Colonne preuve_existence absente : contrôle impossible.${F}`);
  } else {
    for (const p of preuves) {
      const sansPreuve = p.preuve === "aucune";
      console.log(
        `  ${sansPreuve ? R : V}${String(p.n).padStart(4)}  ${
          PREUVES[p.preuve] || p.preuve
        }${F}`
      );
    }
    const fantomes = preuves.find((p) => p.preuve === "aucune");
    if (fantomes) {
      console.log(
        `\n  ${J}Ces ${fantomes.n} adresses figurent à l'inventaire sans qu'aucune\n` +
          "  preuve n'ait été retenue. Elles viennent d'un cache ARP ou d'un\n" +
          `  import. Ce sont les seules lignes dont l'existence est douteuse.${F}`
      );
    }
  }

  /* ── 5. Adresses MAC aléatoires ── */
  const [alea] = (await lire(
    "SELECT COUNT(*) AS n FROM EQUIPEMENT WHERE mac_aleatoire = 1"
  )) || [null];
  if (alea && Number(alea.n) > 0) {
    titre("5. ADRESSES MATÉRIELLES ALÉATOIRES");
    console.log(
      `  ${J}${alea.n} appareil(s) utilisent une adresse MAC aléatoire.${F}\n\n` +
        "  Ce n'est pas une erreur : téléphones et portables récents en\n" +
        "  changent à chaque connexion pour ne pas être suivis. Conséquence\n" +
        "  à connaître — le même appareil peut apparaître plusieurs fois\n" +
        "  dans l'inventaire au fil des jours, sous des lignes différentes."
    );
  }

  /* ── 6. Re-vérification en direct ── */
  titre(`6. RE-VÉRIFICATION EN DIRECT (${echantillon} machines)`);

  const aTester = await lire(
    `SELECT adresse_ip, nom, nom_source, sys_descr
       FROM EQUIPEMENT
      WHERE nom IS NOT NULL AND nom <> ''
      ORDER BY RAND()
      LIMIT ${echantillon}`
  );

  if (!aTester || aTester.length === 0) {
    console.log(`  ${G}Aucun nom en base à re-vérifier.${F}`);
  } else {
    console.log(
      `  ${G}On redemande son nom à chaque machine, maintenant.${F}\n`
    );
    console.log(
      `  ${G}adresse          nom en base           nom obtenu            verdict${F}`
    );

    let confirmes = 0;
    let muets = 0;
    let divergents = 0;

    for (const eq of aTester) {
      /* On réinterroge par la MÊME voie que celle qui a donné le nom.
         Redemander en DNS/NetBIOS/mDNS le nom d'un commutateur nommé par
         SNMP le ferait passer pour muet alors qu'il répond très bien —
         un faux négatif qui décrédibiliserait tout le contrôle. */
      let obtenu = null;
      if (eq.nom_source === "snmp") {
        const sonde = await snmpProbe(eq.adresse_ip).catch(() => null);
        obtenu = sonde && sonde.sysName ? String(sonde.sysName).trim() : null;
      } else {
        obtenu = (await resoudreNom(eq.adresse_ip, null)).nom;
      }
      const a = String(eq.nom || "").toLowerCase();
      const b = String(obtenu || "").toLowerCase();

      let verdict;
      let couleur;
      if (!obtenu) {
        verdict = "muette maintenant";
        couleur = G;
        muets++;
      } else if (a === b || b.startsWith(a) || a.startsWith(b)) {
        verdict = "CONFIRMÉ";
        couleur = V;
        confirmes++;
      } else {
        verdict = "DIFFÉRENT";
        couleur = R;
        divergents++;
      }

      console.log(
        `  ${couleur}${eq.adresse_ip.padEnd(16)} ${String(eq.nom).slice(0, 20).padEnd(21)} ` +
          `${String(obtenu || "—").slice(0, 20).padEnd(21)} ${verdict}${F}`
      );
    }

    console.log(
      `\n  ${V}${confirmes} confirmé(s)${F} · ${G}${muets} muette(s)${F} · ` +
        `${divergents > 0 ? R : G}${divergents} divergent(s)${F}`
    );
    console.log(
      `\n  ${G}« muette » n'est pas un échec : une machine éteinte, ou dont le\n` +
        "  pare-feu a changé, ne répond plus alors que son nom reste juste.\n" +
        `  Seuls les DIVERGENTS méritent qu'on regarde.${F}`
    );
  }

  /* ── Conclusion ── */
  titre("VERDICT");

  const problemes = [];
  if (suspectDoublon) problemes.push("des noms sont portés par plusieurs machines");
  if (suspects && suspects.length > 0) problemes.push("des noms recopient une adresse ou un mot creux");

  if (problemes.length === 0) {
    console.log(
      `  ${V}Aucun signe de nom inventé.${F} Chaque nom vient d'une source\n` +
        "  nommée, aucun n'est dupliqué, aucun ne recopie une adresse.\n"
    );
  } else {
    console.log(`  ${R}À regarder :${F}`);
    for (const p of problemes) console.log(`    • ${p}`);
    console.log("");
  }

  console.log("═══════════════════════════════════════════════════════════════\n");

  await db.end();
  process.exit(0);
})().catch((err) => {
  console.error("\nVérification interrompue :", err.message, "\n");
  process.exit(1);
});
