﻿<#
    tools\diagnostic-wmi.ps1

    LA PORTE WINDOWS EST-ELLE OUVERTE SUR CE RESEAU ?

    Le diagnostic SNMP a montre que 7 machines sur 105 repondent en SNMP,
    et qu'aucune ne publie ses programmes en cours. La seule porte qui
    reste pour les postes Windows est WMI.

    Avant d'ecrire une ligne de code, il faut savoir si elle s'ouvre. Elle
    demande trois choses, et il suffit qu'une manque pour que tout le
    travail soit inutile :

      1. le poste doit etre joignable ;
      2. WinRM (port 5985) ou DCOM (port 135) doit repondre ;
      3. le compte utilise doit avoir le droit d'interroger la machine.

    Ce script teste les trois, sur les machines que vous lui donnez, et
    dit laquelle des deux voies fonctionne. Il ne modifie RIEN : il pose
    des questions, il n'ecrit nulle part.

    USAGE

        .\tools\diagnostic-wmi.ps1 192.168.0.42
        .\tools\diagnostic-wmi.ps1 192.168.0.42, 192.168.0.51, 192.168.0.77

    Choisissez des POSTES WINDOWS, pas les imprimantes : ce sont eux
    qu'on cherche a observer. Prenez-en trois ou quatre, dont un que vous
    savez allume.

    Par defaut le script utilise VOTRE session Windows actuelle. Pour
    essayer avec un autre compte du domaine :

        .\tools\diagnostic-wmi.ps1 192.168.0.42 -DemanderIdentifiants
#>

param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string[]]$Machines,

    [switch]$DemanderIdentifiants
)

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"   # sinon Test-NetConnection affiche une barre inutile

$identifiants = $null
if ($DemanderIdentifiants) {
    $identifiants = Get-Credential -Message "Compte du domaine a utiliser (DOMAINE\utilisateur)"
}

Write-Host ""
Write-Host "═══════════════════════════════════════════════════════"
Write-Host "  LA PORTE WINDOWS (WMI) EST-ELLE OUVERTE ?"
Write-Host "═══════════════════════════════════════════════════════"
Write-Host ""
$compte = if ($identifiants) { $identifiants.UserName } else { "$env:USERDOMAIN\$env:USERNAME (votre session)" }
Write-Host "  Compte utilise : $compte"
Write-Host ""

$bilan = @()

foreach ($machine in $Machines) {

    Write-Host "───────────────────────────────────────────────────────"
    Write-Host "  $machine" -ForegroundColor Cyan

    $ligne = [ordered]@{
        Machine = $machine; Joignable = $false
        WinRM = $false; DCOM = $false
        Voie = "aucune"; Systeme = ""; Programmes = 0
    }

    # ── 1. La machine repond-elle ? ──
    $ping = Test-Connection -ComputerName $machine -Count 1 -Quiet -ErrorAction SilentlyContinue
    if ($ping) {
        Write-Host "    ping                 repond" -ForegroundColor Green
        $ligne.Joignable = $true
    } else {
        # Un poste Windows bloque le ping par defaut : ce n'est PAS
        # eliminatoire, on continue.
        Write-Host "    ping                 pas de reponse (normal sur un poste Windows)" -ForegroundColor DarkGray
    }

    # ── 2. Les deux portes ──
    $t5985 = Test-NetConnection -ComputerName $machine -Port 5985 -WarningAction SilentlyContinue -InformationLevel Quiet
    $t135  = Test-NetConnection -ComputerName $machine -Port 135  -WarningAction SilentlyContinue -InformationLevel Quiet

    if ($t5985) { Write-Host "    port 5985 (WinRM)    ouvert" -ForegroundColor Green; $ligne.WinRM = $true }
    else        { Write-Host "    port 5985 (WinRM)    ferme" -ForegroundColor DarkGray }

    if ($t135)  { Write-Host "    port 135 (DCOM)      ouvert" -ForegroundColor Green; $ligne.DCOM = $true }
    else        { Write-Host "    port 135 (DCOM)      ferme" -ForegroundColor DarkGray }

    if (-not $t5985 -and -not $t135) {
        Write-Host "    -> les deux portes sont fermees, rien a tenter ici" -ForegroundColor Yellow
        $bilan += [pscustomobject]$ligne
        continue
    }

    # ── 3. On interroge vraiment ──
    # Get-CimInstance -ComputerName passe par WinRM. Pour DCOM il faut une
    # session explicite : les deux sont essayees, la premiere qui repond
    # gagne, et on NOTE laquelle - c'est elle qui decidera du code.
    $session = $null
    $voie = $null

    if ($t5985) {
        try {
            $p = @{ ComputerName = $machine; OperationTimeoutSec = 10; ErrorAction = "Stop" }
            if ($identifiants) { $p.Credential = $identifiants }
            $session = New-CimSession @p
            $voie = "WinRM"
        } catch {
            Write-Host "    WinRM                refus : $($_.Exception.Message.Split([Environment]::NewLine)[0])" -ForegroundColor Yellow
        }
    }

    if (-not $session -and $t135) {
        try {
            $option = New-CimSessionOption -Protocol Dcom
            $p = @{ ComputerName = $machine; SessionOption = $option; OperationTimeoutSec = 10; ErrorAction = "Stop" }
            if ($identifiants) { $p.Credential = $identifiants }
            $session = New-CimSession @p
            $voie = "DCOM"
        } catch {
            Write-Host "    DCOM                 refus : $($_.Exception.Message.Split([Environment]::NewLine)[0])" -ForegroundColor Yellow
        }
    }

    if (-not $session) {
        Write-Host "    -> port ouvert mais acces refuse : c'est un probleme de DROITS" -ForegroundColor Yellow
        $bilan += [pscustomobject]$ligne
        continue
    }

    try {
        $os = Get-CimInstance -CimSession $session -ClassName Win32_OperatingSystem -ErrorAction Stop
        Write-Host "    systeme              $($os.Caption)" -ForegroundColor Green
        $ligne.Systeme = $os.Caption

        # Win32_Process, et SURTOUT PAS Win32_Product : cette classe-la
        # declenche une reparation MSI de chaque logiciel installe sur la
        # machine interrogee. C'est un piege connu, et il se paie sur le
        # parc du client.
        $procs = Get-CimInstance -CimSession $session -ClassName Win32_Process -ErrorAction Stop
        $distincts = ($procs | Select-Object -ExpandProperty Name -Unique)
        Write-Host "    programmes en cours  $($procs.Count) ($($distincts.Count) distincts)" -ForegroundColor Green
        $ligne.Programmes = $distincts.Count

        $apercu = ($distincts | Select-Object -First 5) -join ", "
        Write-Host "    exemples             $apercu" -ForegroundColor DarkGray

        $ligne.Voie = $voie
        Write-Host "    -> OK par $voie" -ForegroundColor Green
    } catch {
        Write-Host "    interrogation        echec : $($_.Exception.Message.Split([Environment]::NewLine)[0])" -ForegroundColor Yellow
    } finally {
        Remove-CimSession -CimSession $session -ErrorAction SilentlyContinue
    }

    $bilan += [pscustomobject]$ligne
}

# ── VERDICT ──
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════"
Write-Host ""

$ok = @($bilan | Where-Object { $_.Voie -ne "aucune" })
$portOuvert = @($bilan | Where-Object { $_.WinRM -or $_.DCOM })

if ($ok.Count -gt 0) {
    $voies = ($ok | Select-Object -ExpandProperty Voie -Unique) -join " et "
    Write-Host "  LA PORTE EST OUVERTE : $($ok.Count) machine(s) sur $($Machines.Count) ont repondu, par $voies." -ForegroundColor Green
    Write-Host ""
    Write-Host "  Renvoyez-moi ce tableau :" -ForegroundColor Gray
    $bilan | Format-Table Machine, WinRM, DCOM, Voie, Programmes, Systeme -AutoSize
}
elseif ($portOuvert.Count -gt 0) {
    Write-Host "  LES PORTS SONT OUVERTS, MAIS L'ACCES EST REFUSE." -ForegroundColor Yellow
    Write-Host "  C'est un probleme de DROITS, pas de reseau. Reessayez avec :" -ForegroundColor Gray
    Write-Host "      .\tools\diagnostic-wmi.ps1 $($Machines[0]) -DemanderIdentifiants" -ForegroundColor Gray
    Write-Host "  en donnant un compte du domaine ayant des droits d'administration" -ForegroundColor Gray
    Write-Host "  sur les postes." -ForegroundColor Gray
}
else {
    Write-Host "  LA PORTE EST FERMEE : ni WinRM ni DCOM ne repondent." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Deux causes possibles :" -ForegroundColor Gray
    Write-Host "    - le pare-feu des postes bloque ces ports (cas le plus frequent" -ForegroundColor Gray
    Write-Host "      hors domaine, et parfois dans le domaine) ;" -ForegroundColor Gray
    Write-Host "    - WinRM n'est pas active sur le parc." -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Les deux se debloquent par une GPO, c'est-a-dire une decision du" -ForegroundColor Gray
    Write-Host "  responsable informatique. Si elle n'est pas obtenable, il reste" -ForegroundColor Gray
    Write-Host "  l'agent de poste, deployable lui aussi par GPO." -ForegroundColor Gray
}
Write-Host ""
