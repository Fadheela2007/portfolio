/**
 * tools/mesurer-nmap-options.js
 * Quelle option de nmap fait gagner du temps, et laquelle coûte la détection.
 *
 *   node tools\mesurer-nmap-options.js
 *   node tools\mesurer-nmap-options.js 192.168.0.239 192.168.0.233
 *
 * ─────────────────────────────────────────────────────────────────────
 * POURQUOI CET OUTIL EXISTE — ET IL EXISTE À CAUSE D'UNE ERREUR
 *
 * Une première tentative appliquait CINQ options d'un coup :
 *
 *     -T4 -F -n --max-retries 2 --host-timeout 12s
 *
 * Mesurée sur cinq machines réelles, elle était 18 % plus rapide et
 * PERDAIT la détection sur trois d'entre elles. Les trois échecs
 * tombaient tous à 12,7 s — exactement la valeur de `--host-timeout`.
 * Ces machines demandent 14 s pour être identifiées : on coupait nmap
 * juste avant qu'il conclue.
 *
 * Le réglage censé faire gagner du temps transformait des succès en
 * échecs. Appliqué sans mesure, il aurait rendu le produit plus rapide
 * et moins juste — le pire des échanges pour un outil dont la valeur
 * tient à l'exactitude de ce qu'il affiche.
 *
 * D'où cet outil : chaque option est mesurée SEULE, avec un délai
 * volontairement large (40 s) pour que rien ne soit tronqué
 * artificiellement. On saura alors ce que chacune coûte et rapporte.
 *
 * CE QU'ON CHERCHE
 *
 *   • combien de temps nmap prend RÉELLEMENT quand on le laisse finir ;
 *   • quelles options accélèrent sans rien perdre ;
 *   • à partir de quelle valeur `--host-timeout` cesse de nuire.
 * ─────────────────────────────────────────────────────────────────────
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const { exec } = require("child_process");
const db = require("../src/db");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

/**
 * Délai TRÈS large : on veut connaître la durée naturelle de chaque
 * variante. Un délai serré fausserait la mesure — c'est précisément
 * l'erreur qu'on cherche à ne pas refaire.
 */
const DELAI_LARGE_MS = 40000;

const VARIANTES = [
  {
    nom: "actuelle (référence)",
    options: "-O --osscan-guess",
    note: "ce que fait le produit aujourd'hui",
  },
  {
    nom: "+ -T4",
    options: "-O --osscan-guess -T4",
    note: "rythme adapté à un réseau local au lieu d'Internet",
  },
  {
    nom: "+ -n",
    options: "-O --osscan-guess -n",
    note: "pas de résolution de nom : nous la faisons déjà",
  },
  {
    nom: "+ --max-retries 2",
    options: "-O --osscan-guess --max-retries 2",
    note: "défaut 10 ; sur un réseau local c'est excessif",
  },
  {
    nom: "+ -F",
    options: "-O --osscan-guess -F",
    note: "SUSPECT : moins de ports sondés, l'empreinte peut manquer",
  },
  {
    nom: "-T4 -n --max-retries 2",
    options: "-O --osscan-guess -T4 -n --max-retries 2",
    note: "les trois sûres ensemble, SANS -F ni host-timeout",
  },
];

function lancer(options, ip) {
  const debut = Date.now();
  return new Promise((resolve) => {
    exec(`nmap ${options} ${ip}`, { timeout: DELAI_LARGE_MS }, (error, stdout) => {
      const ms = Date.now() - debut;
      const m =
        (stdout && stdout.match(/OS details: (.+)/)) ||
        (stdout && stdout.match(/Aggressive OS guesses: (.+)/));
      resolve({
        ms,
        os: m ? m[1].split(",")[0].trim() : null,
        tue: !!error && ms >= DELAI_LARGE_MS - 500,
      });
    });
  });
}

(async () => {
  let cibles = process.argv.slice(2);
  if (cibles.length === 0) {
    const [rows] = await db
      .query(
        `SELECT adresse_ip FROM EQUIPEMENT WHERE statut = 'up'
         ORDER BY RAND() LIMIT 4`
      )
      .catch(() => [[]]);
    cibles = rows.map((r) => r.adresse_ip);
  }
  if (cibles.length === 0) {
    console.error("\nAucune cible trouvée. Passez des adresses en argument.\n");
    await db.end().catch(() => {});
    process.exitCode = 1;
    return;
  }

  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  NMAP — CHAQUE OPTION MESURÉE SÉPARÉMENT");
  console.log("═══════════════════════════════════════════════════════\n");
  console.log(`  ${G}${cibles.length} machine(s) × ${VARIANTES.length} variantes.${F}`);
  console.log(`  ${G}Délai large (40 s) pour ne rien tronquer : comptez plusieurs minutes.${F}\n`);

  // { nomVariante: { total, detectes } }
  const bilan = new Map(VARIANTES.map((v) => [v.nom, { total: 0, detectes: 0 }]));
  // Ce que la référence a détecté, pour repérer les PERTES.
  const referenceDetecte = new Map();

  for (const ip of cibles) {
    console.log(`  ${J}${ip}${F}`);
    for (const v of VARIANTES) {
      const r = await lancer(v.options, ip);
      const b = bilan.get(v.nom);
      b.total += r.ms;
      if (r.os) b.detectes++;

      let marque = r.os ? `${V}✓${F}` : `${G}—${F}`;
      let commentaire = r.os ? r.os.slice(0, 40) : r.tue ? `${R}tué à 40 s${F}` : "aucun résultat";

      if (v.nom === "actuelle (référence)") {
        referenceDetecte.set(ip, !!r.os);
      } else if (referenceDetecte.get(ip) && !r.os) {
        // La référence savait, cette variante ne sait plus : c'est une PERTE.
        marque = `${R}✗${F}`;
        commentaire = `${R}PERTE — la référence détectait${F}`;
      }

      console.log(
        `    ${marque} ${v.nom.padEnd(24)} ${String(r.ms).padStart(6)} ms   ${commentaire}`
      );
    }
    console.log("");
  }

  /* ── Synthèse ────────────────────────────────────────────────────── */
  const n = cibles.length;
  const ref = bilan.get("actuelle (référence)");

  console.log("───────────────────────────────────────────────────────");
  console.log(`  ${G}variante                  moyenne    détectés   verdict${F}`);

  for (const v of VARIANTES) {
    const b = bilan.get(v.nom);
    const moyenne = Math.round(b.total / n);
    const gain = ref.total > 0 ? Math.round(((ref.total - b.total) / ref.total) * 100) : 0;

    let verdict;
    if (v.nom === "actuelle (référence)") {
      verdict = `${G}référence${F}`;
    } else if (b.detectes < ref.detectes) {
      // Une option qui fait perdre des détections est écartée, quel que
      // soit son gain. Un outil plus rapide et moins juste est un recul.
      verdict = `${R}À ÉCARTER — ${ref.detectes - b.detectes} détection(s) perdue(s)${F}`;
    } else if (gain > 5) {
      verdict = `${V}${gain} % plus rapide, rien perdu${F}`;
    } else if (gain < -5) {
      verdict = `${J}${-gain} % plus LENT${F}`;
    } else {
      verdict = `${G}sans effet notable${F}`;
    }

    console.log(
      `    ${v.nom.padEnd(24)} ${String(moyenne).padStart(6)} ms   ` +
        `${String(b.detectes).padStart(2)}/${n}       ${verdict}`
    );
  }

  /* ── Quelle valeur de --host-timeout ? ───────────────────────────── */
  console.log(`\n  ${G}Sur le délai maximal par machine${F}`);
  console.log("    Une machine identifiée demande jusqu'à 14 s dans nos");
  console.log("    mesures. Un --host-timeout doit donc rester NETTEMENT");
  console.log("    au-dessus — 25 s par exemple — pour ne couper que les");
  console.log("    machines qui n'auraient de toute façon rien donné.");
  console.log("    Son intérêt n'est pas d'accélérer les succès, mais");
  console.log("    d'abréger les échecs.");
  console.log("───────────────────────────────────────────────────────\n");

  await db.end().catch(() => {});
})().catch(async (err) => {
  console.error(`\n${R}Erreur :${F} ${err.message}\n`);
  await db.end().catch(() => {});
  process.exitCode = 1;
});
