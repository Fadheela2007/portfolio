/**
 * tools/diagnostic-alertes.js
 *
 *   node tools\diagnostic-alertes.js
 *
 * « Ces alertes sont-elles vraies ? » — la question se tranche en
 * retestant les machines, pas en lisant l'écran.
 *
 * CE QU'IL FAIT
 *
 * Pour chaque équipement déclaré hors ligne, il refait exactement ce que
 * fait le cycle de supervision : un ping, puis — si le ping échoue — un
 * test des ports TCP courants. Une machine qui répond sur un port est
 * VIVANTE : elle bloque simplement le ping, ce que fait tout poste
 * Windows par défaut. L'alerte est alors fausse.
 *
 * Il ne modifie RIEN : ni les alertes, ni les statuts. Il constate.
 *
 * POURQUOI CET OUTIL EXISTE
 *
 * Une fausse alerte ne se voit pas : elle ressemble trait pour trait à
 * une vraie. Et un outil de supervision qui invente des pannes est pire
 * qu'aucun outil — au bout de deux semaines, plus personne ne lit ses
 * alertes, y compris les vraies.
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const db = require("../src/db");
const ping = require("ping");
const { diagnosePanne } = require("../src/services/discoveryService");

const V = "\x1b[32m", R = "\x1b[31m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";
const MAX_RETESTS = 20;

(async () => {
  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  LES ALERTES SONT-ELLES JUSTIFIÉES ?");
  console.log("═══════════════════════════════════════════════════════\n");

  // ── 1. LES RÉGLAGES QUI DÉCIDENT ──
  const [reglages] = await db.query(
    `SELECT cle, valeur FROM CONFIGURATION
     WHERE cle IN ('seuil_echecs_avant_alerte','intervalle_scan_minutes',
                   'seuil_cpu_pourcent','seuil_ram_pourcent','seuil_releves_consecutifs')`
  );
  console.log("  RÉGLAGES\n");
  for (const r of reglages) console.log(`    ${r.cle.padEnd(28)} ${r.valeur}`);
  const seuil = Number(
    reglages.find((r) => r.cle === "seuil_echecs_avant_alerte")?.valeur || 3
  );
  if (seuil < 3) {
    console.log(
      `\n    ${J}⚠ Un seuil de ${seuil} est bas : un seul paquet ICMP perdu suffit\n` +
      `      presque à déclencher une alerte. 3 est la valeur conseillée.${F}`
    );
  }

  // ── 2. CE QUI EST ACTIF, PAR TYPE ──
  const [parType] = await db.query(
    `SELECT type_alerte, niveau, COUNT(*) AS n
     FROM ALERTE WHERE statut = 'active'
     GROUP BY type_alerte, niveau ORDER BY n DESC`
  );
  console.log("\n  ALERTES ACTIVES\n");
  if (parType.length === 0) {
    console.log("    Aucune alerte active.\n");
    await db.end();
    return;
  }
  for (const t of parType) {
    console.log(`    ${String(t.n).padStart(4)}  ${t.type_alerte} (${t.niveau})`);
  }

  // ── 3. LE CONTRÔLE QUI TRANCHE ──
  //
  // On ne reteste que les alertes d'indisponibilité : ce sont les seules
  // dont la vérité se vérifie en une seconde, avec un paquet.
  const [aTester] = await db.query(
    `SELECT a.id_alerte, e.id_equipement, e.adresse_ip,
            COALESCE(e.nom_personnalise, e.nom) AS nom,
            e.fabricant, e.statut, e.echecs_consecutifs,
            t.libelle AS type_equipement,
            TIMESTAMPDIFF(MINUTE, COALESCE(a.premiere_detection, a.date_creation), NOW()) AS age_min,
            a.occurrences,
            /* A-T-ELLE DÉJÀ RÉPONDU, UNE SEULE FOIS ?
               Un relevé n'est écrit que lorsque le ping aboutit. Zéro relevé
               signifie donc : cette machine n'a JAMAIS répondu depuis qu'elle
               est en base. Elle a été découverte par la table ARP du poste,
               qui garde en mémoire des machines parties depuis plusieurs
               minutes — on l'a enregistrée « en ligne » sans preuve. */
            (SELECT COUNT(*) FROM RELEVE r WHERE r.id_equipement = e.id_equipement) AS releves
     FROM ALERTE a
     JOIN EQUIPEMENT e ON e.id_equipement = a.id_equipement
     LEFT JOIN TYPE_EQUIPEMENT t ON t.id_type = e.id_type
     WHERE a.statut = 'active' AND a.type_alerte = 'equipement_down'
     ORDER BY a.date_creation DESC
     LIMIT ${MAX_RETESTS}`
  );

  if (aTester.length === 0) {
    console.log("\n  Aucune alerte d'indisponibilité à retester.\n");
    await db.end();
    return;
  }

  console.log(`\n  RETEST DE ${aTester.length} MACHINE(S) EN ALERTE — en direct\n`);

  let fausses = 0, vraies = 0, fantomes = 0;
  for (const eq of aTester) {
    const r = await ping.promise.probe(eq.adresse_ip, { timeout: 2 }).catch(() => ({ alive: false }));
    const etiquette = `${eq.adresse_ip.padEnd(16)} ${(eq.nom || "Appareil " + (eq.fabricant || "?")).slice(0, 22).padEnd(23)}`;

    if (r.alive) {
      fausses++;
      console.log(`    ${R}FAUSSE${F}  ${etiquette} répond au ping (${Math.round(r.time)} ms)`);
      continue;
    }
    const d = await diagnosePanne(eq.adresse_ip);
    if (d.code === "pare_feu_probable") {
      fausses++;
      console.log(`    ${R}FAUSSE${F}  ${etiquette} ${d.detail.match(/port (\d+)/)?.[0] || "port TCP"} ouvert — la machine tourne`);
    } else {
      vraies++;
      const jamais = Number(eq.releves) === 0;
      if (jamais) fantomes++;
      console.log(
        `    ${jamais ? `${J}FANTÔME${F}` : `${V}vraie  ${F}`} ${etiquette} ` +
          (jamais
            ? `${J}n'a JAMAIS répondu depuis sa découverte${F}`
            : `${G}${eq.releves} relevé(s) avant de disparaître — alerte depuis ${eq.age_min} min${F}`)
      );
    }
  }

  // ── 4. CE QUE ÇA VEUT DIRE ──
  console.log("\n  ─────────────────────────────────────────────────────\n");
  console.log(
    `    ${vraies - fantomes} machine(s) réellement tombée(s) après avoir répondu.\n` +
    `    ${fantomes} fantôme(s) : jamais aucune réponse depuis la découverte.\n` +
    `    ${fausses} fausse(s) alerte(s).\n`
  );

  if (fantomes > 0) {
    console.log(
      `  ${J}Un « fantôme » n'est pas une machine en panne : c'est une entrée de\n` +
      `  la table ARP du poste qui a servi au scan. Cette table garde en\n` +
      `  mémoire les machines vues récemment, plusieurs minutes après leur\n` +
      `  départ. Le scan les enregistre « en ligne » sans qu'elles aient\n` +
      `  jamais répondu, puis la supervision les déclare hors ligne.${F}\n\n` +
      `    Dire « ne répond plus » d'une machine qui n'a jamais répondu est\n` +
      `    faux, et c'est ce qui remplit le tableau de bord après chaque scan.\n`
    );
  }

  if (fausses > 0) {
    console.log(
      `  ${J}Une alerte fausse signifie que la machine répondait au moment du\n` +
      `  retest. Deux lectures possibles, et elles n'appellent pas la même\n` +
      `  correction :${F}\n\n` +
      `    • La machine est revenue entre-temps. C'est le cas d'un portable\n` +
      `      ou d'un téléphone qui quitte le réseau puis y revient. L'alerte\n` +
      `      était vraie quand elle est partie. Le cycle suivant la fermera\n` +
      `      tout seul — vérifiez d'abord que la supervision tourne.\n\n` +
      `    • La machine n'est jamais partie et bloque simplement le ping.\n` +
      `      Le contrôle qui cherche un port TCP ouvert avant d'alerter n'a\n` +
      `      alors pas joué. C'est un vrai défaut, à signaler.\n`
    );
  }

  const mobiles = aTester.filter((e) =>
    /portable|laptop|phone|mobile|android|apple/i.test(
      `${e.nom || ""} ${e.fabricant || ""} ${e.type_equipement || ""}`
    )
  ).length;
  if (mobiles > 0) {
    console.log(
      `  ${G}${mobiles} de ces machines ressemblent à des appareils mobiles.\n` +
      `  Un parc où portables et téléphones vont et viennent produit des\n` +
      `  alertes d'indisponibilité légitimes mais sans intérêt : la machine\n` +
      `  n'est pas en panne, elle est partie. C'est une limite connue du\n` +
      `  produit, pas un défaut de mesure.${F}\n`
    );
  }

  await db.end();
})().catch((err) => {
  console.error("\nDiagnostic interrompu :", err.message, "\n");
  process.exit(2);
});
