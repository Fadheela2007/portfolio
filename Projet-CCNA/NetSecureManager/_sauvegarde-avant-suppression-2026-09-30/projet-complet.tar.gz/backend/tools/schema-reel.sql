-- Schéma RÉEL de la base NetSecureManager
-- Généré le 2026-08-11T07:48:12.329Z par tools/introspecter-base.js
-- Source de vérité : sortie brute de SHOW CREATE TABLE.

-- Tables présentes en base (11) : ALERTE, EQUIPEMENT, INCIDENT, INTERFACE_RESEAU, LOG_ACTIVITE, NOTIFICATION, PLAGE_SCAN, RELEVE, SITE, TYPE_EQUIPEMENT, UTILISATEUR

-- ============================== SITE ==============================
CREATE TABLE `site` (
  `id_site` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `agent_token` varchar(255) NOT NULL,
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_site`),
  UNIQUE KEY `agent_token` (`agent_token`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de SITE :
--   id_site                    int                                            null=NO defaut=NULL auto_increment
--   nom                        varchar(100)                                   null=NO defaut=NULL 
--   ville                      varchar(100)                                   null=NO defaut=NULL 
--   adresse                    varchar(255)                                   null=YES defaut=NULL 
--   agent_token                varchar(255)                                   null=NO defaut=NULL 
--   date_creation              datetime                                       null=YES defaut=CURRENT_TIMESTAMP DEFAULT_GENERATED

-- ============================== TYPE_EQUIPEMENT ==============================
CREATE TABLE `type_equipement` (
  `id_type` int NOT NULL AUTO_INCREMENT,
  `libelle` varchar(50) NOT NULL,
  PRIMARY KEY (`id_type`),
  UNIQUE KEY `libelle` (`libelle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de TYPE_EQUIPEMENT :
--   id_type                    int                                            null=NO defaut=NULL auto_increment
--   libelle                    varchar(50)                                    null=NO defaut=NULL 

-- ============================== UTILISATEUR ==============================
CREATE TABLE `utilisateur` (
  `id_utilisateur` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telephone_whatsapp` varchar(20) DEFAULT NULL,
  `mot_de_passe_hash` varchar(255) NOT NULL,
  `role` enum('admin','operateur','lecteur') DEFAULT 'lecteur',
  `id_site` int DEFAULT NULL,
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_utilisateur`),
  UNIQUE KEY `email` (`email`),
  KEY `id_site` (`id_site`),
  CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`id_site`) REFERENCES `site` (`id_site`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de UTILISATEUR :
--   id_utilisateur             int                                            null=NO defaut=NULL auto_increment
--   nom                        varchar(100)                                   null=NO defaut=NULL 
--   email                      varchar(150)                                   null=NO defaut=NULL 
--   telephone_whatsapp         varchar(20)                                    null=YES defaut=NULL 
--   mot_de_passe_hash          varchar(255)                                   null=NO defaut=NULL 
--   role                       enum('admin','operateur','lecteur')            null=YES defaut=lecteur 
--   id_site                    int                                            null=YES defaut=NULL 
--   date_creation              datetime                                       null=YES defaut=CURRENT_TIMESTAMP DEFAULT_GENERATED

-- ============================== EQUIPEMENT ==============================
CREATE TABLE `equipement` (
  `id_equipement` int NOT NULL AUTO_INCREMENT,
  `id_site` int NOT NULL,
  `id_type` int DEFAULT NULL,
  `nom` varchar(150) DEFAULT NULL,
  `adresse_ip` varchar(45) NOT NULL,
  `adresse_mac` varchar(17) DEFAULT NULL,
  `fabricant` varchar(100) DEFAULT NULL,
  `modele` varchar(150) DEFAULT NULL,
  `sys_descr` text,
  `os_detecte` varchar(150) DEFAULT NULL,
  `statut` enum('up','down','inconnu') DEFAULT 'inconnu',
  `derniere_decouverte` datetime DEFAULT NULL,
  `date_ajout` datetime DEFAULT CURRENT_TIMESTAMP,
  `echecs_consecutifs` int DEFAULT '0',
  PRIMARY KEY (`id_equipement`),
  UNIQUE KEY `uniq_ip_site` (`id_site`,`adresse_ip`),
  KEY `id_type` (`id_type`),
  CONSTRAINT `equipement_ibfk_1` FOREIGN KEY (`id_site`) REFERENCES `site` (`id_site`) ON DELETE CASCADE,
  CONSTRAINT `equipement_ibfk_2` FOREIGN KEY (`id_type`) REFERENCES `type_equipement` (`id_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de EQUIPEMENT :
--   id_equipement              int                                            null=NO defaut=NULL auto_increment
--   id_site                    int                                            null=NO defaut=NULL 
--   id_type                    int                                            null=YES defaut=NULL 
--   nom                        varchar(150)                                   null=YES defaut=NULL 
--   adresse_ip                 varchar(45)                                    null=NO defaut=NULL 
--   adresse_mac                varchar(17)                                    null=YES defaut=NULL 
--   fabricant                  varchar(100)                                   null=YES defaut=NULL 
--   modele                     varchar(150)                                   null=YES defaut=NULL 
--   sys_descr                  text                                           null=YES defaut=NULL 
--   os_detecte                 varchar(150)                                   null=YES defaut=NULL 
--   statut                     enum('up','down','inconnu')                    null=YES defaut=inconnu 
--   derniere_decouverte        datetime                                       null=YES defaut=NULL 
--   date_ajout                 datetime                                       null=YES defaut=CURRENT_TIMESTAMP DEFAULT_GENERATED
--   echecs_consecutifs         int                                            null=YES defaut=0 

-- ============================== INTERFACE_RESEAU ==============================
CREATE TABLE `interface_reseau` (
  `id_interface` int NOT NULL AUTO_INCREMENT,
  `id_equipement` int NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `adresse_mac` varchar(17) DEFAULT NULL,
  `vlan` int DEFAULT NULL,
  `etat_admin` enum('up','down') DEFAULT 'up',
  `etat_operationnel` enum('up','down') DEFAULT 'down',
  PRIMARY KEY (`id_interface`),
  KEY `id_equipement` (`id_equipement`),
  CONSTRAINT `interface_reseau_ibfk_1` FOREIGN KEY (`id_equipement`) REFERENCES `equipement` (`id_equipement`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de INTERFACE_RESEAU :
--   id_interface               int                                            null=NO defaut=NULL auto_increment
--   id_equipement              int                                            null=NO defaut=NULL 
--   nom                        varchar(100)                                   null=YES defaut=NULL 
--   adresse_mac                varchar(17)                                    null=YES defaut=NULL 
--   vlan                       int                                            null=YES defaut=NULL 
--   etat_admin                 enum('up','down')                              null=YES defaut=up 
--   etat_operationnel          enum('up','down')                              null=YES defaut=down 

-- ============ SERVICE_DETECTE : TABLE ABSENTE DE LA BASE ============

-- ============================== RELEVE ==============================
CREATE TABLE `releve` (
  `id_releve` bigint NOT NULL AUTO_INCREMENT,
  `id_equipement` int NOT NULL,
  `date_releve` datetime DEFAULT CURRENT_TIMESTAMP,
  `cpu_pourcent` decimal(5,2) DEFAULT NULL,
  `ram_pourcent` decimal(5,2) DEFAULT NULL,
  `trafic_entrant_kbps` decimal(12,2) DEFAULT NULL,
  `trafic_sortant_kbps` decimal(12,2) DEFAULT NULL,
  `temperature_c` decimal(5,2) DEFAULT NULL,
  `latence_ms` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id_releve`),
  KEY `idx_equip_date` (`id_equipement`,`date_releve`),
  CONSTRAINT `releve_ibfk_1` FOREIGN KEY (`id_equipement`) REFERENCES `equipement` (`id_equipement`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de RELEVE :
--   id_releve                  bigint                                         null=NO defaut=NULL auto_increment
--   id_equipement              int                                            null=NO defaut=NULL 
--   date_releve                datetime                                       null=YES defaut=CURRENT_TIMESTAMP DEFAULT_GENERATED
--   cpu_pourcent               decimal(5,2)                                   null=YES defaut=NULL 
--   ram_pourcent               decimal(5,2)                                   null=YES defaut=NULL 
--   trafic_entrant_kbps        decimal(12,2)                                  null=YES defaut=NULL 
--   trafic_sortant_kbps        decimal(12,2)                                  null=YES defaut=NULL 
--   temperature_c              decimal(5,2)                                   null=YES defaut=NULL 
--   latence_ms                 decimal(8,2)                                   null=YES defaut=NULL 

-- ============================== ALERTE ==============================
CREATE TABLE `alerte` (
  `id_alerte` int NOT NULL AUTO_INCREMENT,
  `id_equipement` int NOT NULL,
  `type_alerte` varchar(100) NOT NULL,
  `niveau` enum('info','warning','critical') DEFAULT 'warning',
  `message` text,
  `statut` enum('active','resolue') DEFAULT 'active',
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_resolution` datetime DEFAULT NULL,
  `cause_code` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_alerte`),
  KEY `id_equipement` (`id_equipement`),
  CONSTRAINT `alerte_ibfk_1` FOREIGN KEY (`id_equipement`) REFERENCES `equipement` (`id_equipement`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de ALERTE :
--   id_alerte                  int                                            null=NO defaut=NULL auto_increment
--   id_equipement              int                                            null=NO defaut=NULL 
--   type_alerte                varchar(100)                                   null=NO defaut=NULL 
--   niveau                     enum('info','warning','critical')              null=YES defaut=warning 
--   message                    text                                           null=YES defaut=NULL 
--   statut                     enum('active','resolue')                       null=YES defaut=active 
--   date_creation              datetime                                       null=YES defaut=CURRENT_TIMESTAMP DEFAULT_GENERATED
--   date_resolution            datetime                                       null=YES defaut=NULL 
--   cause_code                 varchar(50)                                    null=YES defaut=NULL 

-- ============================== INCIDENT ==============================
CREATE TABLE `incident` (
  `id_incident` int NOT NULL AUTO_INCREMENT,
  `id_alerte` int NOT NULL,
  `titre` varchar(200) DEFAULT NULL,
  `description` text,
  `statut` enum('ouvert','en_cours','ferme') DEFAULT 'ouvert',
  `id_utilisateur_assigne` int DEFAULT NULL,
  `date_ouverture` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_fermeture` datetime DEFAULT NULL,
  PRIMARY KEY (`id_incident`),
  KEY `id_alerte` (`id_alerte`),
  CONSTRAINT `incident_ibfk_1` FOREIGN KEY (`id_alerte`) REFERENCES `alerte` (`id_alerte`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de INCIDENT :
--   id_incident                int                                            null=NO defaut=NULL auto_increment
--   id_alerte                  int                                            null=NO defaut=NULL 
--   titre                      varchar(200)                                   null=YES defaut=NULL 
--   description                text                                           null=YES defaut=NULL 
--   statut                     enum('ouvert','en_cours','ferme')              null=YES defaut=ouvert 
--   id_utilisateur_assigne     int                                            null=YES defaut=NULL 
--   date_ouverture             datetime                                       null=YES defaut=CURRENT_TIMESTAMP DEFAULT_GENERATED
--   date_fermeture             datetime                                       null=YES defaut=NULL 

-- ============================== LOG_ACTIVITE ==============================
CREATE TABLE `log_activite` (
  `id_log` bigint NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int DEFAULT NULL,
  `action` varchar(200) DEFAULT NULL,
  `description` text,
  `adresse_ip_utilisateur` varchar(45) DEFAULT NULL,
  `date_log` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_utilisateur` (`id_utilisateur`),
  CONSTRAINT `log_activite_ibfk_1` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de LOG_ACTIVITE :
--   id_log                     bigint                                         null=NO defaut=NULL auto_increment
--   id_utilisateur             int                                            null=YES defaut=NULL 
--   action                     varchar(200)                                   null=YES defaut=NULL 
--   description                text                                           null=YES defaut=NULL 
--   adresse_ip_utilisateur     varchar(45)                                    null=YES defaut=NULL 
--   date_log                   datetime                                       null=YES defaut=CURRENT_TIMESTAMP DEFAULT_GENERATED

-- ============ VULNERABILITE_CONNUE : TABLE ABSENTE DE LA BASE ============

-- ============ CONFIGURATION : TABLE ABSENTE DE LA BASE ============

-- ============================== PLAGE_SCAN ==============================
CREATE TABLE `plage_scan` (
  `id_plage` int NOT NULL AUTO_INCREMENT,
  `id_site` int NOT NULL,
  `cidr` varchar(50) NOT NULL,
  `snmp_community` varchar(100) DEFAULT 'public',
  `snmp_version` enum('v1','v2c','v3') DEFAULT 'v2c',
  `actif` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_plage`),
  KEY `id_site` (`id_site`),
  CONSTRAINT `plage_scan_ibfk_1` FOREIGN KEY (`id_site`) REFERENCES `site` (`id_site`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de PLAGE_SCAN :
--   id_plage                   int                                            null=NO defaut=NULL auto_increment
--   id_site                    int                                            null=NO defaut=NULL 
--   cidr                       varchar(50)                                    null=NO defaut=NULL 
--   snmp_community             varchar(100)                                   null=YES defaut=public 
--   snmp_version               enum('v1','v2c','v3')                          null=YES defaut=v2c 
--   actif                      tinyint(1)                                     null=YES defaut=1 

-- ============================== NOTIFICATION ==============================
CREATE TABLE `notification` (
  `id_notification` int NOT NULL AUTO_INCREMENT,
  `id_alerte` int DEFAULT NULL,
  `id_utilisateur` int DEFAULT NULL,
  `canal` enum('email','whatsapp') NOT NULL,
  `statut` enum('envoye','echec') DEFAULT 'envoye',
  `date_envoi` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_notification`),
  KEY `id_alerte` (`id_alerte`),
  KEY `id_utilisateur` (`id_utilisateur`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`id_alerte`) REFERENCES `alerte` (`id_alerte`) ON DELETE CASCADE,
  CONSTRAINT `notification_ibfk_2` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Colonnes de NOTIFICATION :
--   id_notification            int                                            null=NO defaut=NULL auto_increment
--   id_alerte                  int                                            null=YES defaut=NULL 
--   id_utilisateur             int                                            null=YES defaut=NULL 
--   canal                      enum('email','whatsapp')                       null=NO defaut=NULL 
--   statut                     enum('envoye','echec')                         null=YES defaut=envoye 
--   date_envoi                 datetime                                       null=YES defaut=CURRENT_TIMESTAMP DEFAULT_GENERATED

-- ---------- Contenu actuel de TYPE_EQUIPEMENT (0 ligne(s)) ----------
