/**
 * tools/couverture.js
 *
 *   node tools\couverture.js
 *
 * Combien d'équipements portent un nom, un fabricant, un type — et QUELLE
 * méthode l'a trouvé. Ne modifie rien, ne lit que la base.
 *
 * POURQUOI CET OUTIL
 *
 * « Il y a des cases vides » n'est pas une mesure. Sans chiffre, on ne
 * sait pas si la plateforme couvre 30 % ou 95 % du parc, et on ne peut
 * rien défendre devant quelqu'un qui pose la question.
 *
 * La colonne `nom_source` enregistre la méthode qui a répondu. C'est elle
 * qui transforme « ça n'affiche rien » en « le DNS de ce réseau
 * n'enregistre pas ses baux, et le mDNS a nommé 40 machines que rien
 * d'autre n'aurait identifiées ».
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const db = require("../src/db");

const V = "\x1b[32m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

const pourcent = (n, total) => (total === 0 ? 0 : Math.round((n / total) * 100));

/** Barre de proportion, pour lire un pourcentage sans le calculer. */
const barre = (p) => "█".repeat(Math.round(p / 5)) + "·".repeat(20 - Math.round(p / 5));

const LIBELLE_NOM = {
  snmp: "SNMP (l'appareil se nomme lui-même)",
  dns: "DNS inverse (le serveur DHCP enregistre ses baux)",
  netbios: "NetBIOS (postes Windows)",
  mdns: "mDNS (Apple, Android, imprimantes, caméras)",
  aucune: "aucune méthode n'a répondu",
};

const LIBELLE_TYPE = {
  snmp: "texte SNMP de l'appareil",
  port: "port révélateur ouvert (9100 → imprimante…)",
  banniere_web: "titre de la page d'administration",
  nmap_device: "catégorie annoncée par nmap",
  nmap_os: "système d'exploitation deviné par nmap",
  fabricant: "marque de la carte réseau",
  aucune: "aucun signal exploitable → « inconnu »",
};

(async () => {
  const [[t]] = await db.query(
    `SELECT COUNT(*) AS total,
            SUM(e.nom IS NOT NULL AND e.nom <> '') AS avec_nom,
            SUM(e.nom_personnalise IS NOT NULL AND e.nom_personnalise <> '') AS renommes,
            SUM(e.fabricant IS NOT NULL AND e.fabricant <> '') AS avec_fabricant,
            /* UN TYPE « inconnu » N'EST PAS UN TYPE.
               La première version comptait toute ligne ayant un id_type,
               y compris celles pointant sur « inconnu » : elle annonçait
               donc 100 % de types identifiés alors que les trois quarts
               étaient inconnus. Un chiffre faux et flatteur est exactement
               ce qui se retourne contre celui qui le présente. */
            SUM(ty.libelle IS NOT NULL AND ty.libelle <> 'inconnu') AS avec_type
     FROM EQUIPEMENT e
     LEFT JOIN TYPE_EQUIPEMENT ty ON ty.id_type = e.id_type`
  );

  const total = Number(t.total || 0);
  if (total === 0) {
    console.log("\nAucun équipement en base. Lancez un scan d'abord.\n");
    await db.end();
    return;
  }

  console.log("\n═══════════════════════════════════════════════════════");
  console.log(`  COUVERTURE DE L'IDENTIFICATION — ${total} équipements`);
  console.log("═══════════════════════════════════════════════════════\n");

  const lignes = [
    ["Fabricant", Number(t.avec_fabricant || 0)],
    ["Nom", Number(t.avec_nom || 0)],
    ["Type connu", Number(t.avec_type || 0)],
  ];
  for (const [libelle, n] of lignes) {
    const p = pourcent(n, total);
    const couleur = p >= 80 ? V : p >= 40 ? J : G;
    console.log(`  ${libelle.padEnd(11)} ${couleur}${barre(p)}${F} ${String(p).padStart(3)} %   ${n}/${total}`);
  }

  if (Number(t.renommes) > 0) {
    console.log(`\n  ${G}Dont ${t.renommes} renommé(s) à la main par un utilisateur.${F}`);
  }

  // ── PAR QUELLE MÉTHODE ──
  for (const [colonne, titre, libelles] of [
    ["nom_source", "D'OÙ VIENNENT LES NOMS", LIBELLE_NOM],
    ["type_source", "QUI A DÉCIDÉ DU TYPE", LIBELLE_TYPE],
  ]) {
    let rows;
    try {
      [rows] = await db.query(
        `SELECT COALESCE(${colonne}, 'aucune') AS source, COUNT(*) AS n
         FROM EQUIPEMENT GROUP BY source ORDER BY n DESC`
      );
    } catch {
      continue; // colonne absente sur une base non migrée
    }

    console.log(`\n  ${titre}\n`);
    for (const r of rows) {
      const p = pourcent(Number(r.n), total);
      const texte = libelles[r.source] || r.source;
      console.log(`    ${String(r.n).padStart(4)}  ${String(p).padStart(3)} %  ${texte}`);
    }
  }

  // ── CE QUE ÇA VEUT DIRE ──
  //
  // Un chiffre sans lecture se retourne contre celui qui le présente.
  console.log("\n  ─────────────────────────────────────────────────────");
  const sansNom = total - Number(t.avec_nom || 0);
  const sansType = total - Number(t.avec_type || 0);

  if (sansNom > 0) {
    console.log(
      `\n  ${sansNom} équipement(s) sans nom. Ce n'est un défaut que si le réseau\n` +
      `  dispose d'un DNS qui enregistre ses baux, ou de postes Windows.\n` +
      `  Un téléphone, une caméra ou un capteur n'a pas de nom de machine :\n` +
      `  sa case reste vide, et c'est correct. L'interface affiche alors\n` +
      `  « Appareil <marque> » à partir de l'adresse matérielle.`
    );
  }
  if (sansType > 0) {
    console.log(
      `\n  ${sansType} équipement(s) sans type. « inconnu » est un choix du produit :\n` +
      `  mieux vaut une case honnête qu'une catégorie fausse. Un appareil qui\n` +
      `  n'expose ni SNMP, ni port révélateur, ni signature nmap ne donne\n` +
      `  aucun signal — le deviner d'après sa marque produirait des erreurs\n` +
      `  qu'un client repérerait immédiatement.`
    );
  }
  console.log("");
  await db.end();
})().catch((err) => {
  console.error("\nLecture impossible :", err.message, "\n");
  process.exit(2);
});
