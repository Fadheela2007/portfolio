/**
 * tools/diagnostic-snmp-couverture.js
 *
 *   node tools\diagnostic-snmp-couverture.js
 *
 * Combien d'équipements du parc peuvent RÉELLEMENT produire une mesure de
 * bande passante ?
 *
 * POURQUOI CETTE QUESTION MÉRITE UN OUTIL
 *
 * L'écran Bande passante peut rester vide pour trois raisons très
 * différentes, et rien ne les distingue à l'affichage :
 *
 *   1. la supervision vient de démarrer — il faut DEUX cycles, le débit
 *      étant une différence entre deux relevés SNMP ;
 *   2. le parc n'expose pas SNMP — sur un parc bureautique, c'est une
 *      machine sur dix, et l'écran restera vide quoi qu'on attende ;
 *   3. un défaut réel.
 *
 * Confondre 1 et 2 fait attendre des heures un chiffre qui ne viendra
 * jamais. Cet outil tranche en une commande.
 */
require("dotenv").config({ path: require("path").join(__dirname, "..", ".env"), quiet: true });
const db = require("../src/db");
const V = "\x1b[32m", J = "\x1b[33m", G = "\x1b[90m", F = "\x1b[0m";

(async () => {
  const [[e]] = await db.query(
    `SELECT COUNT(*) AS total,
            SUM(sys_descr IS NOT NULL) AS snmp
     FROM EQUIPEMENT`
  );
  const [[r]] = await db.query(
    `SELECT COUNT(*) AS total,
            COUNT(DISTINCT id_equipement) AS machines,
            SUM(trafic_entrant_kbps IS NOT NULL) AS avec_trafic,
            COUNT(DISTINCT CASE WHEN trafic_entrant_kbps IS NOT NULL THEN id_equipement END) AS machines_trafic
     FROM RELEVE WHERE date_releve >= NOW() - INTERVAL 24 HOUR`
  );

  console.log("\n═══════════════════════════════════════════════════════");
  console.log("  LA BANDE PASSANTE PEUT-ELLE S'AFFICHER ?");
  console.log("═══════════════════════════════════════════════════════\n");
  console.log(`  Parc                        ${e.total} équipement(s)`);
  console.log(`  Répondent en SNMP           ${e.snmp || 0}`);
  console.log(`  Relevés (24 h)              ${r.total || 0}, sur ${r.machines || 0} machine(s)`);
  console.log(`  Relevés AVEC un débit       ${r.avec_trafic || 0}, sur ${r.machines_trafic || 0} machine(s)\n`);

  if (Number(e.snmp || 0) === 0) {
    console.log(`  ${J}Aucun équipement n'expose SNMP.${F}`);
    console.log(`  ${G}L'écran Bande passante restera vide quel que soit le temps d'attente.`);
    console.log(`  Ce n'est pas un défaut : c'est la couverture réelle du parc. La voie`);
    console.log(`  prévue pour ce cas est la mesure PAR PORT DE SWITCH — elle demande un`);
    console.log(`  switch administrable interrogé en SNMP, pas les postes eux-mêmes.${F}\n`);
  } else if (Number(r.machines_trafic || 0) === 0) {
    console.log(`  ${J}${e.snmp} équipement(s) parlent SNMP, mais aucun débit n'est encore calculé.${F}`);
    console.log(`  ${G}Le débit est une DIFFÉRENCE entre deux relevés : il faut deux cycles`);
    console.log(`  complets. Patientez le double de votre intervalle, puis relancez.${F}\n`);
  } else {
    console.log(`  ${V}${r.machines_trafic} machine(s) produisent un débit — l'écran a de quoi afficher.${F}\n`);
  }
  await db.end();
})().catch((err) => { console.error("Erreur :", err.message); process.exit(2); });
