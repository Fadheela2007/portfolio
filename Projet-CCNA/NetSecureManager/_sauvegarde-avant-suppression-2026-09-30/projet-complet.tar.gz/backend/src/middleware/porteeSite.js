/**
 * middleware/porteeSite.js
 *
 * Cloisonnement des données par site.
 *
 * CONVENTION (identique à celle de notificationService.getDestinataires) :
 *   - UTILISATEUR.id_site = NULL  -> utilisateur GLOBAL, voit tous les sites
 *   - UTILISATEUR.id_site = <n>   -> utilisateur RATTACHÉ, ne voit que le site n
 *
 * La portée vient du JWT (`req.user.id_site`), signé par le serveur : elle ne
 * peut pas être manipulée par le client. Tout le filtrage se fait donc côté
 * serveur, jamais côté frontend.
 *
 * Le rôle et la portée sont deux axes indépendants : un admin rattaché au
 * site 2 est administrateur DU SITE 2, pas de la plateforme. Pour un
 * administrateur de plateforme, laisser id_site à NULL.
 */

const db = require("../db");

/**
 * ═══════════════════════════════════════════════════════════════════════
 * DEUX NIVEAUX DE CLOISONNEMENT, ET ILS NE FONT PAS LA MÊME CHOSE
 *
 *   ORGANISATION — l'entreprise. Sépare des clients qui ne se connaissent
 *     pas. Personne ne franchit cette frontière, jamais, quel que soit son
 *     rôle. Un « administrateur global » est global DANS SON ORGANISATION.
 *
 *   SITE — l'agence. Sépare les équipes d'une même entreprise. Un
 *     administrateur global la franchit ; c'est normal, il administre son
 *     entreprise.
 *
 * Les confondre serait la faute la plus grave de la plateforme : un
 * inscrit du jour verrait l'inventaire réseau d'une autre société —
 * machines, adresses, ports ouverts, failles connues. C'est-à-dire
 * exactement ce qu'on cherche avant une intrusion.
 *
 * ── COMMENT LA FRONTIÈRE EST TENUE ──
 *
 * Par une sous-requête sur SITE, ajoutée à la condition de site que TOUTES
 * les routes appliquent déjà. Une seule modification ici couvre donc
 * l'ensemble du code : il n'y a pas de route à ne pas oublier, et c'est
 * précisément ce qu'on veut d'un cloisonnement — qu'il ne dépende pas de
 * la vigilance de celui qui écrira la prochaine route.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** L'organisation du compte, lue dans le jeton signé. */
function organisationDe(req) {
  const valeur = req.user?.id_organisation;
  return valeur === undefined || valeur === null ? null : Number(valeur);
}

/**
 * Fragment SQL limitant une colonne de site aux sites de l'organisation.
 *
 * `(? IS NULL OR ...)` : une installation d'avant la migration, ou un
 * jeton émis avant elle, n'a pas d'organisation. La condition est alors
 * toujours vraie et le comportement reste celui d'avant — un jeton de huit
 * heures survit à une mise à jour, et il ne doit pas déconnecter tout le
 * monde ni, pire, vider les écrans sans explication.
 */
function clauseOrganisation(req, colonneSite) {
  const org = organisationDe(req);
  return {
    clause: `(? IS NULL OR ${colonneSite} IN (SELECT id_site FROM SITE WHERE id_organisation = ?))`,
    params: [org, org],
  };
}

/** Renvoie l'id_site auquel l'utilisateur est limité, ou null s'il est global. */
function porteeDe(req) {
  const valeur = req.user?.id_site;
  return valeur === undefined || valeur === null ? null : Number(valeur);
}

/**
 * Fragment SQL à injecter dans un WHERE, avec ses paramètres.
 *
 * Le motif `(? IS NULL OR colonne = ?)` évite de construire deux requêtes
 * distinctes : quand la portée est NULL (utilisateur global), la condition est
 * toujours vraie.
 *
 * @param {string} colonne - colonne qualifiée, ex. "e.id_site"
 * @returns {{ clause: string, params: [number|null, number|null] }}
 */
function clauseSite(req, colonne = "e.id_site") {
  const portee = porteeDe(req);
  const org = clauseOrganisation(req, colonne);
  return {
    clause: `(? IS NULL OR ${colonne} = ?) AND ${org.clause}`,
    params: [portee, portee, ...org.params],
  };
}

/**
 * Le filtre complet : le PÉRIMÈTRE de l'utilisateur, ET le site qu'il a
 * choisi à l'écran.
 *
 * ── LE DÉFAUT QUE ÇA CORRIGE ──
 *
 * `clauseSite` ne lit que le jeton. Les routes qui s'en contentaient
 * ignoraient donc le `id_site` passé en paramètre : pour un administrateur
 * global, le tableau de bord affichait « 44 équipements » pour le site
 * choisi, et juste à côté les alertes et les courbes de TOUS les sites.
 * Le trait de référence « parc : 180 » surplombait une carte annonçant 44
 * équipements — deux chiffres contradictoires sur le même écran, sans un
 * mot pour dire qu'ils ne comptaient pas la même chose.
 *
 * ── LES DEUX CONDITIONS SE CUMULENT, ELLES NE SE REMPLACENT PAS ──
 *
 * Le périmètre du jeton reste appliqué en plus du site demandé. Un
 * utilisateur rattaché au site 2 qui réclame le site 1 obtient donc un
 * résultat VIDE, jamais les données du site 1 : le choix d'écran peut
 * seulement RESTREINDRE ce que le jeton autorise. C'est la règle qui
 * empêche un paramètre d'URL de devenir une élévation de privilège.
 *
 * @param {string} colonne - colonne qualifiée, ex. "e.id_site"
 */
function filtreSite(req, colonne = "e.id_site") {
  const portee = porteeDe(req);

  const demande = Number(req.query?.id_site);
  const choisi = Number.isInteger(demande) && demande > 0 ? demande : null;

  const org = clauseOrganisation(req, colonne);

  return {
    clause:
      `(? IS NULL OR ${colonne} = ?) AND (? IS NULL OR ${colonne} = ?) AND ${org.clause}`,
    params: [portee, portee, choisi, choisi, ...org.params],
  };
}

/** L'utilisateur a-t-il le droit d'agir sur ce site ? */
function siteAutorise(req, idSite) {
  const portee = porteeDe(req);
  if (portee === null) return true;
  return Number(idSite) === portee;
}

/**
 * Le site appartient-il bien à l'organisation du demandeur ?
 *
 * SÉPARÉE de `siteAutorise`, et asynchrone, parce qu'elle doit interroger
 * la base : l'appartenance d'un site à une organisation n'est pas dans le
 * jeton, et ne doit surtout pas l'être — sinon le demandeur la choisirait.
 */
async function siteDansOrganisation(req, idSite) {
  const org = organisationDe(req);
  if (org === null) return true; // installation d'avant la migration
  const [rows] = await db.query(
    "SELECT 1 AS n FROM SITE WHERE id_site = ? AND id_organisation = ? LIMIT 1",
    [idSite, org]
  );
  return rows.length > 0;
}

/**
 * Vérifie qu'un équipement appartient au périmètre de l'utilisateur.
 * Renvoie { ok: true } ou { ok: false, statut, erreur }.
 *
 * On répond 404 et non 403 quand l'équipement existe mais hors périmètre :
 * un 403 confirmerait son existence à quelqu'un qui n'a pas à le savoir.
 */
async function verifierAccesEquipement(req, idEquipement) {
  const portee = porteeDe(req);
  const org = organisationDe(req);

  /* La jointure rapporte l'organisation PROPRIÉTAIRE du site, et non celle
     que le demandeur prétend avoir : c'est la base qui tranche. */
  const [rows] = await db.query(
    `SELECT e.id_site, s.id_organisation
       FROM EQUIPEMENT e
       LEFT JOIN SITE s ON s.id_site = e.id_site
      WHERE e.id_equipement = ?`,
    [idEquipement]
  );
  if (rows.length === 0) {
    return { ok: false, statut: 404, erreur: "Équipement introuvable" };
  }
  // Toujours 404 hors périmètre : un 403 confirmerait l'existence.
  if (org !== null && Number(rows[0].id_organisation) !== org) {
    return { ok: false, statut: 404, erreur: "Équipement introuvable" };
  }
  if (portee !== null && rows[0].id_site !== portee) {
    return { ok: false, statut: 404, erreur: "Équipement introuvable" };
  }
  return { ok: true, idSite: rows[0].id_site };
}

/**
 * Vérifie qu'une alerte est dans le périmètre.
 * Une alerte peut être rattachée à un équipement OU directement à un site
 * (alertes d'agent muet) : on retient le premier des deux renseigné.
 */
async function verifierAccesAlerte(req, idAlerte) {
  const portee = porteeDe(req);
  const org = organisationDe(req);
  const [rows] = await db.query(
    `SELECT COALESCE(a.id_site, e.id_site) AS id_site,
            COALESCE(sa.id_organisation, se.id_organisation) AS id_organisation
     FROM ALERTE a
     LEFT JOIN EQUIPEMENT e ON e.id_equipement = a.id_equipement
     LEFT JOIN SITE sa ON sa.id_site = a.id_site
     LEFT JOIN SITE se ON se.id_site = e.id_site
     WHERE a.id_alerte = ?`,
    [idAlerte]
  );
  if (rows.length === 0) {
    return { ok: false, statut: 404, erreur: "Alerte introuvable" };
  }
  /* La frontière d'organisation se vérifie AVANT celle de site : elle
     est plus large et ne se franchit jamais. Le site du propriétaire est
     lu en base, jamais pris dans le jeton. */
  if (org !== null && Number(rows[0].id_organisation) !== org) {
    return { ok: false, statut: 404, erreur: "Alerte introuvable" };
  }
  if (portee !== null && rows[0].id_site !== portee) {
    return { ok: false, statut: 404, erreur: "Alerte introuvable" };
  }
  return { ok: true };
}

/** Idem pour un incident, via l'alerte dont il découle. */
async function verifierAccesIncident(req, idIncident) {
  const portee = porteeDe(req);
  const org = organisationDe(req);
  const [rows] = await db.query(
    `SELECT COALESCE(a.id_site, e.id_site) AS id_site,
            COALESCE(sa.id_organisation, se.id_organisation) AS id_organisation
     FROM INCIDENT i
     JOIN ALERTE a ON a.id_alerte = i.id_alerte
     LEFT JOIN EQUIPEMENT e ON e.id_equipement = a.id_equipement
     LEFT JOIN SITE sa ON sa.id_site = a.id_site
     LEFT JOIN SITE se ON se.id_site = e.id_site
     WHERE i.id_incident = ?`,
    [idIncident]
  );
  if (rows.length === 0) {
    return { ok: false, statut: 404, erreur: "Incident introuvable" };
  }
  /* La frontière d'organisation se vérifie AVANT celle de site : elle
     est plus large et ne se franchit jamais. Le site du propriétaire est
     lu en base, jamais pris dans le jeton. */
  if (org !== null && Number(rows[0].id_organisation) !== org) {
    return { ok: false, statut: 404, erreur: "Incident introuvable" };
  }
  if (portee !== null && rows[0].id_site !== portee) {
    return { ok: false, statut: 404, erreur: "Incident introuvable" };
  }
  return { ok: true };
}

module.exports = {
  porteeDe,
  organisationDe,
  clauseSite,
  clauseOrganisation,
  filtreSite,
  siteDansOrganisation,
  siteAutorise,
  verifierAccesEquipement,
  verifierAccesAlerte,
  verifierAccesIncident,
};
