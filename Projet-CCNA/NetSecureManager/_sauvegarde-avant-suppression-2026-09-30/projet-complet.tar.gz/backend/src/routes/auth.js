/**
 * routes/auth.js
 * Authentification par e-mail/mot de passe (JWT). Table UTILISATEUR (voir schema.sql).
 */

const express = require("express");
const bcrypt = require("bcryptjs");
const crypto = require("node:crypto");
const jwt = require("jsonwebtoken");
const router = express.Router();
const db = require("../db");
const limiteur = require("../services/limiteurConnexion");

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error("JWT_SECRET est absent de backend/.env — démarrage refusé.");
}
const JWT_EXPIRES_IN = "8h";

/**
 * Empreinte factice, comparée quand le compte n'existe pas.
 *
 * POURQUOI. La version précédente renvoyait immédiatement si l'e-mail
 * était inconnu, mais prenait ~100 ms à vérifier le mot de passe si le
 * compte existait. Cet écart est mesurable : en chronométrant les
 * réponses, on distingue un e-mail enregistré d'un e-mail inconnu, et on
 * peut ainsi dresser la liste des comptes réels avant même d'essayer un
 * seul mot de passe.
 *
 * Comparer contre une empreinte factice fait passer les deux chemins par
 * le même calcul coûteux. Le temps de réponse cesse de renseigner.
 */
const EMPREINTE_FACTICE = bcrypt.hashSync("empreinte-de-comparaison-constante", 10);

/** Attente non bloquante, pour le ralentissement progressif. */
const attendre = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * POST /api/auth/login
 * body: { email, mot_de_passe }
 */
router.post("/login", async (req, res) => {
  const { email, mot_de_passe } = req.body;
  if (!email || !mot_de_passe) {
    return res.status(400).json({ error: "Email et mot de passe requis" });
  }

  const limite = limiteur.verifier(req.ip, email);
  if (!limite.autorise) {
    const minutes = Math.ceil(limite.resteMs / 60000);
    // 429 et non 401 : le client doit pouvoir distinguer « mauvais mot de
    // passe » de « trop de tentatives », sinon l'utilisateur légitime
    // ressaisit indéfiniment un mot de passe pourtant correct.
    return res.status(429).json({
      error: `Trop de tentatives de connexion. Réessayez dans ${minutes} minute(s).`,
    });
  }

  // Ralentissement progressif après plusieurs échecs sur ce compte.
  if (limite.delaiMs > 0) await attendre(limite.delaiMs);

  try {
    const [rows] = await db.query("SELECT * FROM UTILISATEUR WHERE email = ?", [email]);
    const user = rows[0];

    // La comparaison a lieu DANS TOUS LES CAS, y compris quand le compte
    // n'existe pas : voir EMPREINTE_FACTICE ci-dessus.
    const valide = await bcrypt.compare(
      mot_de_passe,
      user ? user.mot_de_passe_hash : EMPREINTE_FACTICE
    );

    if (!user || !valide) {
      limiteur.enregistrerEchec(req.ip, email);

      // Journalisé, mais SANS le mot de passe essayé ni distinction
      // entre compte inconnu et mot de passe faux : un journal ne doit
      // pas devenir lui-même la source de la fuite qu'il documente.
      db.query(
        `INSERT INTO LOG_ACTIVITE (action, description, adresse_ip_utilisateur)
         VALUES ('connexion_echouee', ?, ?)`,
        [`Tentative de connexion échouée pour ${email}`, req.ip]
      ).catch(() => {});

      // Message identique dans les deux cas, pour la même raison que
      // l'empreinte factice : ne rien dire de l'existence du compte.
      return res.status(401).json({ error: "Identifiants invalides" });
    }

    limiteur.enregistrerSucces(req.ip, email);

    /* ── L'ORGANISATION EST DANS LE JETON, SIGNÉE ──

       Elle ne peut donc pas être choisie par l'appelant, ni changée en
       cours de route : c'est la frontière entre deux entreprises qui ne
       se connaissent pas, et elle ne doit dépendre d'aucun paramètre.

       Les jetons émis AVANT cette migration ne la portent pas. Le
       cloisonnement les traite alors comme « pas d'organisation », donc
       sans restriction — le comportement d'avant. Ils expirent d'eux-mêmes
       en huit heures au plus. Déconnecter tout le monde à la mise à jour
       aurait été plus brutal que nécessaire. */
    const token = jwt.sign(
      {
        id: user.id_utilisateur,
        role: user.role,
        id_site: user.id_site,
        id_organisation: user.id_organisation ?? null,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    // La journalisation ne doit jamais faire échouer une connexion valide.
    try {
      await db.query(
        "INSERT INTO LOG_ACTIVITE (id_utilisateur, action, description, adresse_ip_utilisateur) VALUES (?, 'connexion', ?, ?)",
        [user.id_utilisateur, `Connexion de ${user.email}`, req.ip]
      );
    } catch (errLog) {
      console.error("Erreur journalisation connexion:", errLog.message);
    }

    // id_site est nécessaire au frontend pour n'afficher que les options
    // cohérentes avec le périmètre de l'utilisateur (page Utilisateurs).
    // Ce n'est qu'un confort d'affichage : le serveur revalide tout.
    res.json({
      token,
      utilisateur: {
        id: user.id_utilisateur,
        nom: user.nom,
        email: user.email,
        role: user.role,
        id_site: user.id_site ?? null,
      },
    });
  } catch (err) {
    console.error("Erreur login:", err);
    res.status(500).json({ error: "Erreur serveur pendant la connexion" });
  }
});

/**
 * POST /api/auth/register — création du tout premier compte, et rien d'autre.
 * body: { nom, email, mot_de_passe }
 *
 * Cette route était accessible sans authentification — elle est montée
 * avant le requireAuth global, comme /login — et créait un compte de rôle
 * « admin », le rôle étant lu depuis le corps de la requête. N'importe qui
 * pouvant joindre le serveur obtenait donc un accès administrateur en une
 * requête, et avec lui la cartographie complète du réseau du client.
 * Corrigé le 21/08/2026.
 *
 * L'amorçage est conservé, car une installation neuve n'a aucun compte et
 * personne ne pourrait créer le premier. Mais la route ne répond que tant
 * que la table est vide ; ensuite elle refuse et renvoie vers l'écran
 * Utilisateurs. Le rôle n'est plus lu depuis la requête : le premier
 * compte est administrateur par construction.
 */
router.post("/register", async (req, res) => {
  const { nom, email, mot_de_passe } = req.body;
  if (!nom || !email || !mot_de_passe) {
    return res.status(400).json({ error: "nom, email et mot_de_passe sont requis" });
  }

  try {
    const [[{ n }]] = await db.query("SELECT COUNT(*) AS n FROM UTILISATEUR");

    if (n > 0) {
      // On ne dit pas combien de comptes existent : ce serait renseigner
      // un attaquant sur la taille de l'installation.
      return res.status(403).json({
        error: "La création de compte est réservée aux administrateurs",
        aide: "Connectez-vous, puis utilisez l'écran Utilisateurs.",
      });
    }

    if (String(mot_de_passe).length < 8) {
      return res.status(400).json({
        error: "Mot de passe trop court",
        aide: "Le premier compte administrateur exige au moins 8 caractères.",
      });
    }

    const hash = await bcrypt.hash(mot_de_passe, 10);
    await db.query(
      "INSERT INTO UTILISATEUR (nom, email, mot_de_passe_hash, role, id_site) VALUES (?, ?, ?, 'admin', NULL)",
      [nom, email, hash]
    );

    // Trace explicite : la création du premier administrateur est
    // l'événement le plus sensible du cycle de vie de la plateforme.
    await db
      .query(
        `INSERT INTO LOG_ACTIVITE (action, description, adresse_ip_utilisateur)
         VALUES ('amorcage', ?, ?)`,
        [`Création du premier compte administrateur (${email})`, req.ip]
      )
      .catch(() => {});

    res.status(201).json({ message: "Premier compte administrateur créé" });
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ error: "Cet e-mail est déjà utilisé" });
    }
    console.error("Erreur amorçage:", err);
    res.status(500).json({ error: "Erreur lors de la création du compte" });
  }
});

/* ═══════════════════════════════════════════════════════════════════════
   DEMANDER UN ACCÈS

   Deux routes publiques, et elles sont publiques par nécessité : elles
   servent à quelqu'un qui n'a pas encore de compte. Tout ce qui suit
   existe pour qu'être public ne veuille pas dire être une porte ouverte.
   ═══════════════════════════════════════════════════════════════════════ */

const MOTIF_EMAIL_DEMANDE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const LONGUEUR_MIN = 8;

/**
 * Limiteur propre aux demandes d'accès.
 *
 * SÉPARÉ DE CELUI DE LA CONNEXION, ET CE N'EST PAS UN OUBLI DE
 * FACTORISATION. Partager le compteur ferait qu'une rafale de demandes
 * bloquerait la CONNEXION des utilisateurs légitimes : la protection
 * deviendrait le moyen de fermer la plateforme.
 *
 * Le plafond d'entrées et la purge ne sont pas décoratifs non plus. Une
 * carte qui grandit à chaque adresse vue, sur une route que personne
 * n'authentifie, est exactement ce qu'il faut pour faire tomber un
 * serveur par la mémoire — le défaut que `limiteurConnexion` traite
 * explicitement, et qu'il ne faut pas réintroduire ici.
 */
const FENETRE_DEMANDES_MS = 60 * 60 * 1000;
const MAX_DEMANDES_PAR_ADRESSE = 3;
const MAX_ADRESSES_SUIVIES = 5000;
const demandesParAdresse = new Map();

function purgerCompteurs(maintenant) {
  for (const [adresse, entree] of demandesParAdresse) {
    if (maintenant - entree.depuis > FENETRE_DEMANDES_MS) demandesParAdresse.delete(adresse);
  }
  // Dernier recours si la purge par ancienneté n'a pas suffi : mieux vaut
  // perdre le comptage que la mémoire du processus.
  if (demandesParAdresse.size >= MAX_ADRESSES_SUIVIES) demandesParAdresse.clear();
}

function tropDeDemandes(adresse) {
  const maintenant = Date.now();
  purgerCompteurs(maintenant);

  const entree = demandesParAdresse.get(adresse);
  if (!entree || maintenant - entree.depuis > FENETRE_DEMANDES_MS) {
    demandesParAdresse.set(adresse, { nombre: 1, depuis: maintenant });
    return false;
  }
  entree.nombre += 1;
  return entree.nombre > MAX_DEMANDES_PAR_ADRESSE;
}

/**
 * POST /api/inscription
 *
 * ═══════════════════════════════════════════════════════════════════════
 * S'INSCRIRE ET ENTRER. Pas de demande, pas de validation, pas d'attente.
 *
 * On remplit le formulaire, on valide, et on est dans la plateforme — avec
 * son organisation, son premier site, et le rôle d'administrateur dessus.
 *
 * ── POURQUOI C'EST SÛR, ALORS QUE LA PLATEFORME SERT UN INVENTAIRE RÉSEAU ──
 *
 * Parce que l'inscrit n'entre nulle part : il CRÉE son espace. Son
 * organisation est neuve et vide. Il ne voit aucune machine, aucune
 * alerte, aucun parc — il n'y en a pas encore. Il déclare son réseau,
 * lance son scan, et supervise ce qui lui appartient.
 *
 * La frontière d'organisation, posée dans middleware/porteeSite.js,
 * garantit le reste : aucune requête de cette plateforme ne franchit
 * cette limite, quel que soit le rôle. C'est ce travail-là qui rend
 * l'inscription libre possible, et c'est pour ça qu'il fallait le faire
 * d'abord.
 *
 * ── UN PREMIER SITE EST CRÉÉ AVEC L'ORGANISATION ──
 *
 * Sans site, tous les écrans affichent « aucun site accessible » et la
 * plateforme paraît cassée dès la première seconde. Le formulaire demande
 * donc la ville, et le site est prêt : on peut lancer un scan
 * immédiatement.
 *
 * ── TOUT OU RIEN ──
 *
 * Organisation, site et compte sont écrits dans une TRANSACTION. Une
 * coupure en plein milieu laisserait sinon une organisation sans compte —
 * donc une entreprise que personne ne peut plus atteindre, et une adresse
 * e-mail désormais prise pour rien.
 * ═══════════════════════════════════════════════════════════════════════
 */
router.post("/inscription", async (req, res) => {
  const { nom, organisation, ville, email, mot_de_passe } = req.body || {};

  if (!nom || !organisation || !ville || !email || !mot_de_passe) {
    return res.status(400).json({
      error: "Tous les champs sont requis",
      aide: "Votre nom, celui de votre entreprise, votre ville, votre e-mail et un mot de passe.",
    });
  }
  if (!MOTIF_EMAIL_DEMANDE.test(String(email).trim())) {
    return res.status(400).json({ error: "Format d'e-mail invalide" });
  }
  if (String(mot_de_passe).length < LONGUEUR_MIN) {
    return res.status(400).json({
      error: "Mot de passe trop court",
      aide: `Au moins ${LONGUEUR_MIN} caractères.`,
    });
  }

  // Le même limiteur borné que les autres routes publiques : une route
  // qui crée des lignes en base sans authentification doit avoir un
  // plafond, sinon elle est l'outil parfait pour remplir un disque.
  if (tropDeDemandes(req.ip)) {
    return res.status(429).json({
      error: "Trop d'inscriptions depuis cette adresse",
      aide: "Réessayez dans une heure.",
    });
  }

  const adresse = String(email).trim().toLowerCase();
  let connexion;

  try {
    const [[existant]] = await db.query(
      "SELECT 1 AS n FROM UTILISATEUR WHERE email = ? LIMIT 1",
      [adresse]
    );
    if (existant) {
      /* L'adresse est prise. On le dit — c'est une information que la
         personne a besoin d'avoir pour agir, et la taire lui ferait
         croire à une panne. Le message ne révèle RIEN d'autre : ni dans
         quelle organisation, ni depuis quand. */
      return res.status(409).json({
        error: "Cette adresse a déjà un compte",
        aide: "Connectez-vous, ou utilisez une autre adresse.",
      });
    }

    const hash = await bcrypt.hash(String(mot_de_passe), 10);

    connexion = await db.getConnection();
    await connexion.beginTransaction();

    const [org] = await connexion.query(
      "INSERT INTO ORGANISATION (nom) VALUES (?)",
      [String(organisation).trim().slice(0, 150)]
    );
    const idOrganisation = org.insertId;

    const jetonAgent = crypto.randomBytes(24).toString("hex");

    /* ── `supervision_par_agent = TRUE` DÈS LA CRÉATION ──

       Sur une plateforme hébergée, le cycle central ne peut atteindre
       aucun réseau client : un ping ne traverse pas Internet. Laissé au
       défaut (supervision centrale), il aurait essayé de joindre chaque
       machine, échoué à chaque fois, et déclaré TOUT LE PARC hors ligne —
       une panne inventée, dès la première minute, sur un produit dont le
       principe est de ne jamais affirmer plus qu'il ne sait.

       C'est l'agent installé chez le client qui observe et qui rapporte. */
    const [site] = await connexion.query(
      `INSERT INTO SITE (nom, ville, agent_token, id_organisation, supervision_par_agent)
       VALUES (?, ?, ?, ?, TRUE)`,
      [
        String(organisation).trim().slice(0, 100),
        String(ville).trim().slice(0, 100),
        jetonAgent,
        idOrganisation,
      ]
    );

    /* `id_site` à NULL et non le site créé : cette personne administre son
       ORGANISATION, pas une agence. Elle doit pouvoir en ajouter d'autres
       et les voir toutes. */
    const [compte] = await connexion.query(
      `INSERT INTO UTILISATEUR (nom, email, mot_de_passe_hash, role, id_site, id_organisation)
       VALUES (?, ?, ?, 'admin', NULL, ?)`,
      [String(nom).trim().slice(0, 100), adresse, hash, idOrganisation]
    );

    await connexion.commit();

    // Libérée AVANT d'écrire au journal : `tracer` tire une seconde
    // connexion du pool, et garder la première pendant ce temps est le
    // motif qui conduit à un interblocage sous charge.
    connexion.release();
    connexion = null;

    await db
      .query(
        `INSERT INTO LOG_ACTIVITE (action, description, adresse_ip_utilisateur)
         VALUES ('inscription', ?, ?)`,
        [`Inscription de ${adresse} — organisation « ${organisation} »`, req.ip || null]
      )
      .catch(() => {});

    const utilisateur = {
      id: compte.insertId,
      nom: String(nom).trim(),
      email: adresse,
      role: "admin",
      id_site: null,
      id_organisation: idOrganisation,
    };

    const token = jwt.sign(
      { id: utilisateur.id, role: "admin", id_site: null, id_organisation: idOrganisation },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    // On entre directement : redemander de se connecter juste après avoir
    // saisi son mot de passe serait une friction sans aucune raison.
    res.status(201).json({ token, utilisateur, id_site: site.insertId });
  } catch (err) {
    if (connexion) {
      await connexion.rollback().catch(() => {});
      connexion.release();
    }
    if (err && (err.code === "ER_NO_SUCH_TABLE" || err.errno === 1146)) {
      return res.status(503).json({
        error: "L'inscription n'est pas disponible sur cette installation",
        aide: "Appliquez backend/migrations/2026-09-28-organisations.sql, puis redémarrez le serveur.",
      });
    }
    console.error("Inscription impossible:", err.message);
    res.status(500).json({ error: "Inscription impossible pour le moment" });
  }
});

/**
 * GET /api/auth/amorcage
 *
 * « Cette installation a-t-elle son premier administrateur ? »
 *
 * La page de connexion a besoin de le savoir pour afficher, sur une base
 * vierge, le formulaire de création du compte initial plutôt qu'un
 * formulaire de connexion qui ne peut réussir pour personne. Sans cette
 * route, POST /auth/register existait sans qu'aucun écran ne puisse
 * l'appeler : l'installation d'un client exigeait Postman.
 *
 * CE QUE ÇA RÉVÈLE, ET POURQUOI C'EST ACCEPTABLE. La réponse dit
 * seulement si la base est vide. Sur une installation vierge il n'y a
 * rien à protéger ; sur une installation en service, la réponse est
 * toujours « non » et n'apprend rien — ni le nombre de comptes, ni leur
 * nom. C'est le strict minimum dont l'écran a besoin.
 */
router.get("/amorcage", async (req, res) => {
  try {
    const [[{ n }]] = await db.query("SELECT COUNT(*) AS n FROM UTILISATEUR");
    res.json({ requis: Number(n) === 0 });
  } catch (err) {
    // Base injoignable : on ne propose surtout pas l'amorçage, qui
    // créerait un administrateur sur une base qu'on n'a pas su lire.
    console.error("Vérification d'amorçage impossible:", err.message);
    res.json({ requis: false });
  }
});

/**
 * POST /api/auth/demande-acces
 *
 * Enregistre une demande. Ne crée AUCUN compte et n'accorde AUCUN droit.
 *
 * ── LA RÉPONSE EST TOUJOURS LA MÊME ──
 *
 * Adresse déjà titulaire d'un compte, demande déjà déposée, ou première
 * venue : le message rendu est identique. Répondre « cette adresse a
 * déjà un compte » transformerait ce formulaire en annuaire — on y
 * essaierait les adresses de l'entreprise une par une pour dresser la
 * liste des employés qui ont accès à la supervision. C'est le même
 * raisonnement que l'empreinte factice de la connexion, appliqué à
 * l'autre porte.
 *
 * Les erreurs de FORME, elles, sont dites franchement : un e-mail mal
 * écrit ou un mot de passe trop court ne renseignent sur personne, et se
 * taire ferait échouer des demandes légitimes sans explication.
 */
router.post("/demande-acces", async (req, res) => {
  const { nom, email, mot_de_passe, motif } = req.body || {};

  if (!nom || !email || !mot_de_passe || !motif) {
    return res.status(400).json({
      error: "Tous les champs sont requis",
      aide: "Nom, e-mail, mot de passe et motif de la demande.",
    });
  }
  if (!MOTIF_EMAIL_DEMANDE.test(String(email).trim())) {
    return res.status(400).json({ error: "Format d'e-mail invalide" });
  }
  if (String(mot_de_passe).length < LONGUEUR_MIN) {
    return res.status(400).json({
      error: "Mot de passe trop court",
      aide: `Au moins ${LONGUEUR_MIN} caractères.`,
    });
  }

  if (tropDeDemandes(req.ip)) {
    return res.status(429).json({
      error: "Trop de demandes",
      aide: "Réessayez dans une heure, ou contactez directement votre administrateur.",
    });
  }

  const REPONSE = {
    enregistree: true,
    message:
      "Votre demande a été transmise. Un administrateur la traitera ; vous pourrez vous connecter une fois qu'elle aura été acceptée.",
  };

  try {
    const adresse = String(email).trim().toLowerCase();

    // Compte déjà existant, ou demande déjà en attente : on n'écrit rien
    // et on répond comme si de rien n'était. Voir l'en-tête.
    const [[compte]] = await db.query(
      "SELECT 1 AS n FROM UTILISATEUR WHERE email = ? LIMIT 1",
      [adresse]
    );
    if (compte) return res.json(REPONSE);

    const [[enAttente]] = await db.query(
      "SELECT 1 AS n FROM DEMANDE_ACCES WHERE email = ? AND statut = 'en_attente' LIMIT 1",
      [adresse]
    );
    if (enAttente) return res.json(REPONSE);

    const hash = await bcrypt.hash(String(mot_de_passe), 10);

    await db.query(
      `INSERT INTO DEMANDE_ACCES (nom, email, mot_de_passe_hash, motif, adresse_ip)
       VALUES (?, ?, ?, ?, ?)`,
      [
        String(nom).trim().slice(0, 120),
        adresse.slice(0, 190),
        hash,
        String(motif).trim().slice(0, 255),
        req.ip || null,
      ]
    );

    await db
      .query(
        `INSERT INTO LOG_ACTIVITE (action, description, adresse_ip_utilisateur)
         VALUES ('demande_acces', ?, ?)`,
        [`Demande d'accès déposée pour ${adresse}`, req.ip || null]
      )
      .catch(() => {
        /* Le journal est un confort ; son échec ne doit pas perdre la
           demande, qui est déjà écrite. */
      });

    res.json(REPONSE);
  } catch (err) {
    if (err && (err.code === "ER_NO_SUCH_TABLE" || err.errno === 1146)) {
      return res.status(503).json({
        error: "Les demandes d'accès ne sont pas disponibles sur cette installation",
        aide: "Appliquez backend/migrations/2026-09-28-demandes-acces.sql, puis redémarrez le serveur.",
      });
    }
    console.error("Demande d'accès impossible:", err.message);
    res.status(500).json({ error: "Demande impossible pour le moment" });
  }
});

module.exports = router;
