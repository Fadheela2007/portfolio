-- ---------------------------------------------------------------------
-- 2026-09-28 — L'ORGANISATION : une plateforme, plusieurs entreprises.
--
-- POURQUOI CETTE TABLE EXISTE
--
-- La plateforme doit pouvoir accueillir n'importe qui : on s'inscrit
-- depuis la page de connexion, et on repart avec son propre outil de
-- supervision. Mais cette plateforme sert l'inventaire complet d'un
-- réseau — machines, adresses, ports ouverts, services exposés, failles
-- connues. Deux entreprises inscrites le même jour ne doivent JAMAIS
-- apercevoir la moindre ligne l'une de l'autre.
--
-- Le cloisonnement par SITE, déjà en place, ne suffit pas : il sépare les
-- agences d'une même entreprise, pas les entreprises entre elles. Un
-- administrateur global — celui dont `id_site` vaut NULL — voit tous les
-- sites, ce qui est juste à l'intérieur d'une entreprise et catastrophique
-- entre plusieurs.
--
-- L'ORGANISATION est donc le niveau au-dessus. Un site appartient à une
-- organisation ; un compte appartient à une organisation ; et « voir tous
-- les sites » signifie désormais « tous les sites DE SON organisation ».
--
-- ── CE QUI NE CHANGE RIEN AUJOURD'HUI ────────────────────────────────
--
-- Toute installation existante est rattachée à UNE organisation unique,
-- créée ici. Chaque site, chaque compte y entre. Après cette migration,
-- la plateforme se comporte exactement comme avant : mêmes écrans, mêmes
-- chiffres, mêmes droits. Le cloisonnement existe mais n'a rien à
-- séparer — c'est précisément ce qu'on veut d'une fondation.
--
-- ── L'ADRESSE E-MAIL RESTE UNIQUE SUR TOUTE LA PLATEFORME ────────────
--
-- Et c'est un choix, pas un oubli. Une même personne appartient à une
-- seule organisation ; permettre la même adresse dans deux organisations
-- obligerait à demander « laquelle ? » à chaque connexion, pour un cas
-- qui ne se présente presque jamais. Le message d'erreur à l'inscription
-- doit donc rester neutre — il ne faut pas qu'il révèle qu'une adresse
-- est déjà inscrite ailleurs.
--
-- REJOUABLE SANS RISQUE : la table n'est créée que si elle manque, les
-- colonnes ne sont ajoutées que si elles manquent, et le rattachement ne
-- touche que les lignes encore orphelines.
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ORGANISATION (
  id_organisation  INT AUTO_INCREMENT PRIMARY KEY,

  -- Le nom que la personne a donné à son entreprise en s'inscrivant.
  nom              VARCHAR(150) NOT NULL,

  date_creation    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- Prévu pour la suite : une organisation pourra porter sa propre
  -- édition quand la plateforme sera hébergée pour plusieurs clients.
  -- Tant que la licence vit dans le .env, cette colonne n'est pas lue —
  -- et une colonne qu'on n'interroge pas ne ment jamais.
  edition          VARCHAR(20) NOT NULL DEFAULT 'ouverte'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- L'organisation d'accueil de l'installation existante. `id = 1` par
-- construction : c'est la première insérée dans une table neuve.
INSERT INTO ORGANISATION (nom)
SELECT 'Organisation principale'
 WHERE NOT EXISTS (SELECT 1 FROM ORGANISATION);


-- ── SITE.id_organisation ────────────────────────────────────────────
SET @existe := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'SITE' AND COLUMN_NAME = 'id_organisation'
);
SET @sql := IF(
  @existe = 0,
  'ALTER TABLE SITE ADD COLUMN id_organisation INT DEFAULT NULL
     COMMENT ''Entreprise propriétaire de ce site.''',
  'SELECT ''SITE.id_organisation deja presente'' AS info'
);
PREPARE requete FROM @sql; EXECUTE requete; DEALLOCATE PREPARE requete;


-- ── UTILISATEUR.id_organisation ─────────────────────────────────────
--
-- Sur le compte ET sur le site, volontairement. Un administrateur global
-- a `id_site` à NULL : son organisation ne peut donc pas se déduire de
-- son site. Sans cette colonne, le compte le plus puissant serait
-- justement celui qu'on ne saurait pas rattacher.
SET @existe := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'UTILISATEUR' AND COLUMN_NAME = 'id_organisation'
);
SET @sql := IF(
  @existe = 0,
  'ALTER TABLE UTILISATEUR ADD COLUMN id_organisation INT DEFAULT NULL
     COMMENT ''Entreprise a laquelle ce compte appartient.''',
  'SELECT ''UTILISATEUR.id_organisation deja presente'' AS info'
);
PREPARE requete FROM @sql; EXECUTE requete; DEALLOCATE PREPARE requete;


-- ── RATTACHEMENT DE L'EXISTANT ──────────────────────────────────────
-- Seulement les lignes orphelines : rejouer la migration ne déplace
-- jamais un site ou un compte déjà rattaché à une autre organisation.
UPDATE SITE
   SET id_organisation = (SELECT MIN(id_organisation) FROM ORGANISATION)
 WHERE id_organisation IS NULL;

UPDATE UTILISATEUR
   SET id_organisation = (SELECT MIN(id_organisation) FROM ORGANISATION)
 WHERE id_organisation IS NULL;


-- ── CLÉS ÉTRANGÈRES ─────────────────────────────────────────────────
--
-- ON DELETE RESTRICT et non CASCADE : supprimer une organisation
-- effacerait d'un coup tous ses sites, donc tout son parc, tout son
-- historique et tous ses comptes. Ce geste existe peut-être un jour,
-- mais il devra être écrit explicitement, avec ses confirmations — pas
-- arriver en effet de bord d'un DELETE.
SET @existe := (
  SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'SITE' AND CONSTRAINT_NAME = 'fk_site_organisation'
);
SET @sql := IF(
  @existe = 0,
  'ALTER TABLE SITE ADD CONSTRAINT fk_site_organisation
     FOREIGN KEY (id_organisation) REFERENCES ORGANISATION (id_organisation)
     ON DELETE RESTRICT',
  'SELECT ''fk_site_organisation deja presente'' AS info'
);
PREPARE requete FROM @sql; EXECUTE requete; DEALLOCATE PREPARE requete;

SET @existe := (
  SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'UTILISATEUR' AND CONSTRAINT_NAME = 'fk_utilisateur_organisation'
);
SET @sql := IF(
  @existe = 0,
  'ALTER TABLE UTILISATEUR ADD CONSTRAINT fk_utilisateur_organisation
     FOREIGN KEY (id_organisation) REFERENCES ORGANISATION (id_organisation)
     ON DELETE RESTRICT',
  'SELECT ''fk_utilisateur_organisation deja presente'' AS info'
);
PREPARE requete FROM @sql; EXECUTE requete; DEALLOCATE PREPARE requete;


-- ── INDEX ───────────────────────────────────────────────────────────
-- La liste des sites d'une organisation est relue dans CHAQUE requête
-- cloisonnée, en sous-requête. C'est l'index le plus sollicité de la
-- plateforme après ceux de RELEVE.
SET @existe := (
  SELECT COUNT(*) FROM information_schema.STATISTICS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'SITE' AND INDEX_NAME = 'idx_site_organisation'
);
SET @sql := IF(
  @existe = 0,
  'CREATE INDEX idx_site_organisation ON SITE (id_organisation)',
  'SELECT ''idx_site_organisation deja present'' AS info'
);
PREPARE requete FROM @sql; EXECUTE requete; DEALLOCATE PREPARE requete;

SET @existe := (
  SELECT COUNT(*) FROM information_schema.STATISTICS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'UTILISATEUR' AND INDEX_NAME = 'idx_utilisateur_organisation'
);
SET @sql := IF(
  @existe = 0,
  'CREATE INDEX idx_utilisateur_organisation ON UTILISATEUR (id_organisation)',
  'SELECT ''idx_utilisateur_organisation deja present'' AS info'
);
PREPARE requete FROM @sql; EXECUTE requete; DEALLOCATE PREPARE requete;
